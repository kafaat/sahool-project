# Sahool Farmonaut — Production Deployment (Phase 9)

## 1) إعداد البيئة
انسخ ملف البيئة:
```bash
cp .env.prod.example .env
```

## 2) تشغيل نسخة الإنتاج
```bash
docker-compose -f docker-compose.prod.yml up --build
```

الخدمات:
- Nginx: http://localhost
- API: http://localhost/api
- Metrics: http://localhost/metrics
- DB: PostGIS 16
- Redis

## 3) ملاحظات مهمة
- مجلد `storage/` موصول بـ nginx للـ tiles والملفات الثابتة.
- يمكنك زيادة workers عبر `deploy.replicas`.
- لتفعيل SSL:
  - غيّر nginx.conf إلى listen 443
  - أضف certs كـ volume.

## 4) فحص سريع
- افتح الويب
- احسب NDVI
- تأكد أن tiles تظهر وأن `/metrics` يعمل.
