# Phase 44 — Heatmap + Timelapse Player + Blending

## Backend
- Heatmap tiles:
  `/api/ndvi/heatmap/tiles/{result_id}/{z}/{x}/{y}.png`
- Uses caching + optional `?fmt=webp`.

## Web
- طبقة Heatmap جديدة في LayersPanel.
- TimelapsePlayer: Play/Pause/Speed + Slider.
- Blend modes عبر mix-blend-mode.
