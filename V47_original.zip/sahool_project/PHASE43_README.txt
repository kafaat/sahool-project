Phase 43 placeholder for advanced heatmaps/timelapse/GIF.
