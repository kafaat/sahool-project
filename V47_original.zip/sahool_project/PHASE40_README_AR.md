# Phase 40 — Advanced Agro PDF Reporting

Endpoint:
- `/api/reports/agro.pdf?field_id=&crop=&stage=`

Features:
- 4 صفحات:
  1) Overview + NDVI stress + zones yield
  2) Soil suitability + analysis + depth sample (center)
  3) Weather + pests + diseases
  4) Irrigation plan 7d
- زر تحميل PDF داخل AgroIntelDashboard
