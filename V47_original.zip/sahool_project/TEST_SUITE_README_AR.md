# Test Suite — كاملة (Backend + E2E)

## Backend (Pytest)
تشغيل:
```bash
pip install -r requirements.txt
pip install pytest
pytest
```

التغطية:
- system health smoke
- auth/admin smoke + pagination
- weather live/history/irrigation (مع mock)
- weather tiles + ndvi stress tiles
- soil CRUD
- fields CRUD smoke
- satellite/compare/alerts/reports smoke
- usage history smoke
- worker import smoke

## Frontend (Playwright)
تشغيل:
```bash
cd frontend
npm install
npx playwright install
npm run test:e2e
```

التغطية:
- تحميل التطبيق
- التنقل بين التبويبات
- الخريطة و LayersControl
- weather dashboard مع mock
- login mock → soil save flow
- toggle weather layers
- admin users page smoke
