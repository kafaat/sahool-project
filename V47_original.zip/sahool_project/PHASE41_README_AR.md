# Phase 41 — Advanced Layers Panel + Multi-Index Timeline (Farmonaut Style)

## Backend
- Generic timeline for indices:
  - /api/timeline/{index}/timeseries
  - /api/timeline/{index}/anomaly
  - /api/timeline/{index}/frames
Supported indices: ndvi, ndre, gndvi, evi, savi, ndwi, vari, gci, nbr.

## Web
- LayersPanel (يمين الشاشة)
- TimelineSlider أسفل الخريطة
- دعم تفعيل طبقات متعددة + شفافية + اختيار عمق التربة
