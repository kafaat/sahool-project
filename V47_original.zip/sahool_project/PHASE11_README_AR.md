# Phase 11 — Real SentinelHub + S3/MinIO

## متطلبات البيئة
أضف في `.env`:

```env
SENTINELHUB_CLIENT_ID=...
SENTINELHUB_CLIENT_SECRET=...

S3_ENDPOINT_URL=http://minio:9000        # اتركه فارغًا لو AWS
S3_ACCESS_KEY=...
S3_SECRET_KEY=...
S3_BUCKET=sahool
S3_REGION=us-east-1
S3_PUBLIC_BASE=http://minio:9000/sahool  # اختياري (CDN)
```

## السحب الحقيقي
```
POST /api/satellite/sentinelhub/pull?field_id=1&date_from=2025-01-01T00:00:00Z&date_to=2025-01-10T00:00:00Z
```

## رفع النتائج
بعد حساب المؤشرات يتم رفع ملفات TIF إلى S3
وإضافة روابطها داخل stats:
`ndvi_url`, `ndre_url`, ...
