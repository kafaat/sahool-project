def test_timeline_multi_index_smoke(client):
    r=client.get("/timeline/ndre/timeseries?field_id=1&days=30")
    assert r.status_code in (200,404)
    r=client.get("/timeline/gci/frames?field_id=1&days=120")
    assert r.status_code in (200,404)
