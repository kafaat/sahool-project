from app.core.permissions import has_perm

def test_has_perm_basic():
    assert has_perm("admin", "admin.users.read") in (True, False)
    assert has_perm("superadmin", "anything.at.all") is True
    assert has_perm("user", "admin.users.read") is False
