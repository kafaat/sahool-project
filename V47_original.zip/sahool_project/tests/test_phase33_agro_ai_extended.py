import pytest

@pytest.mark.asyncio
async def test_agro_ai_extended_keys(client):
    r = client.get("/agro/ai?field_id=1&crop=wheat&stage=mid")
    assert r.status_code in (200,404)
    if r.status_code==200:
        j=r.json()
        assert "pest_risk" in j
        assert "yield_prediction" in j
        assert "zone_polygons" in j
