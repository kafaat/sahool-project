import pytest

@pytest.mark.phase25
@pytest.mark.asyncio
async def test_irrigation_zones_fallback(client):
    # if no stress tile available, should still return base zone
    r = client.get("/weather/irrigation-zones?field_id=999&crop=wheat&stage=mid")
    assert r.status_code == 200
    data=r.json()
    assert "zones" in data
