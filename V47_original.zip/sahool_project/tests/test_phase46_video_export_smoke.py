def test_gif_export_smoke(client):
    r=client.get("/video/timelapse.gif?field_id=1&index=ndvi&days=30")
    assert r.status_code in (200,404)

def test_mp4_export_smoke(client):
    r=client.get("/video/timelapse.mp4?field_id=1&index=ndvi&days=30")
    assert r.status_code in (200,404,500)
