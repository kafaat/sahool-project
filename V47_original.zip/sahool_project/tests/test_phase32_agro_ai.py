import pytest

@pytest.mark.asyncio
async def test_agro_ai_endpoint_smoke(client):
    # may 404 if field doesn't exist in test DB; accept 200/404
    r = client.get("/agro/ai?field_id=1&crop=wheat&stage=mid")
    assert r.status_code in (200,404)
