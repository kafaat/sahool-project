def test_weather_tiles_png(client):
    r = client.get("/weather/tiles/solar/1/0/0.png")
    assert r.status_code in (200, 500)  # may 500 if external blocked
    if r.status_code == 200:
        assert r.headers["content-type"].startswith("image/png")

def test_ndvi_stress_tile_png(client):
    r = client.get("/ndvi/tiles/stress/1/0/0.png")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("image/png")
