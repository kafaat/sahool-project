def test_ndvi_endpoints_smoke(client):
    # Try a few likely NDVI endpoints and accept 200/404
    endpoints = [
        "/satellite/ndvi/latest",
        "/satellite/ndvi/history",
        "/ndvi/latest",
        "/ndvi/history"
    ]
    for ep in endpoints:
        r = client.get(ep)
        assert r.status_code in (200, 400, 404)
