import pytest

@pytest.mark.asyncio
async def test_agro_ai_vector_and_zones_yield(client):
    r = client.get('/agro/ai?field_id=1&crop=wheat&stage=mid')
    assert r.status_code in (200,404)
    if r.status_code==200:
        j=r.json()
        assert "zones_geojson" in j
        assert "zones_yield" in j

def test_pdf_endpoint_smoke(client):
    r = client.get('/agro/report.pdf?field_id=1&crop=wheat&stage=mid')
    assert r.status_code in (200,404)
