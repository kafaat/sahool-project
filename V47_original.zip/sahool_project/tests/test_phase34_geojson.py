import pytest

@pytest.mark.asyncio
async def test_agro_ai_geojson_shape(client):
    r = client.get('/agro/ai?field_id=1&crop=wheat&stage=mid')
    assert r.status_code in (200,404)
    if r.status_code==200:
        j=r.json()
        gj=j.get('zones_geojson')
        assert gj and gj.get('type')=='FeatureCollection'
        for f in gj['features']:
            assert f['geometry']['type']=='Polygon'
