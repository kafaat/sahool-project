import numpy as np
import pytest

@pytest.mark.phase25
def test_ndvi_to_stress_thresholds():
    from app.modules.ndvi.stress_pipeline import ndvi_to_stress
    delta = np.array([
        [-0.2, -0.08, -0.01],
        [0.0, -0.05, -0.15],
    ])
    stress = ndvi_to_stress(delta)
    assert stress.shape == delta.shape
    # high
    assert stress[0,0] == 3
    assert stress[1,2] == 3
    # moderate
    assert stress[0,1] == 2
    assert stress[1,1] == 2
    # low
    assert stress[0,2] == 1
    assert stress[1,0] == 1

@pytest.mark.phase25
@pytest.mark.asyncio
async def test_generate_stress_tiles_for_field(tmp_path, monkeypatch):
    from app.modules.ndvi import stress_worker
    from app.core import config

    # point storage to temp dir
    monkeypatch.setattr(config.settings, "storage_root", str(tmp_path))
    monkeypatch.setattr(stress_worker.settings, "storage_root", str(tmp_path))

    delta = np.random.uniform(-0.2, 0.1, (20, 20))
    bbox = (30.0, 30.01, 31.0, 31.01)
    await stress_worker.generate_stress_tiles_for_field(bbox, delta, z_min=8, z_max=8)

    # ensure some tiles written
    root_dir = tmp_path/"ndvi_stress"/"8"
    assert root_dir.exists()
    # some file inside
    files = list(root_dir.rglob("*.png"))
    assert len(files) >= 1
