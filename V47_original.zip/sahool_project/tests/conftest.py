import os
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Set test DB before importing app
os.environ["DATABASE_URL"] = "sqlite+pysqlite:///./test.db"
os.environ["JWT_SECRET"] = "test-secret"

from app.core import db as core_db  # noqa
from app.core.db import Base
from app.main import app
from fastapi.testclient import TestClient

# Recreate engine/session with sqlite thread-safe
engine = create_engine(os.environ["DATABASE_URL"], connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

core_db.engine = engine
core_db.SessionLocal = TestingSessionLocal

# Create tables
Base.metadata.create_all(bind=engine)

# Dependency overrides
from app.modules.auth import deps as auth_deps  # noqa

def fake_tenant():
    return {"tenant_id": 1}

def fake_require_role(_perm: str = "user"):
    def dep():
        return True
    return dep

app.dependency_overrides[auth_deps.require_tenant] = fake_tenant
app.dependency_overrides[auth_deps.require_role] = fake_require_role

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[core_db.get_db] = override_get_db

@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c
