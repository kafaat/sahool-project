def test_alerts_list_smoke(client):
    for ep in ["/alerts", "/api/alerts"]:
        r=client.get(ep)
        if r.status_code in (200,404):
            break
    assert True
