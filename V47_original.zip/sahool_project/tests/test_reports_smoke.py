def test_reports_generate_smoke(client):
    for ep in ["/reports/pdf", "/api/reports/pdf", "/reports/generate"]:
        r=client.post(ep, json={"field_id":1})
        assert r.status_code in (200,202,400,404)
        break
