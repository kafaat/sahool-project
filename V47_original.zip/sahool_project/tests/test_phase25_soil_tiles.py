import pytest
from fastapi.testclient import TestClient

@pytest.mark.phase25
@pytest.mark.asyncio
async def test_soil_tiles_render_blank_when_no_profiles(client):
    r = client.get("/soil/tiles/ph/8/0/0.png")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("image/png")

@pytest.mark.phase25
@pytest.mark.asyncio
async def test_soil_tiles_render_with_profile(monkeypatch, client):
    from app.core.db import SessionLocal
    from app.modules.fields.models import Field
    from app.modules.soil.models import SoilProfile
    db=SessionLocal()
    f=Field(tenant_id=1, name="F1", latitude=30.0, longitude=31.0)
    db.add(f); db.commit(); db.refresh(f)
    sp=SoilProfile(tenant_id=1, field_id=f.id, ph=7.1, ec_ds_m=1.2, som_pct=2.0)
    db.add(sp); db.commit()
    db.close()

    r = client.get("/soil/tiles/ec/8/0/0.png")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("image/png")
