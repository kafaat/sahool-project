def test_weather_new_endpoints_smoke(client):
    r1=client.get("/weather/vpd?lat=30&lon=31")
    assert r1.status_code in (200,404)
    r2=client.get("/weather/alerts?lat=30&lon=31&crop=wheat&stage=mid")
    assert r2.status_code in (200,404)
    r3=client.get("/weather/plan?lat=30&lon=31&crop=wheat&stage=mid&days=3")
    assert r3.status_code in (200,404)

def test_soil_new_endpoints_smoke(client):
    r1=client.get("/soil/analysis?field_id=1")
    assert r1.status_code in (200,404)
    r2=client.get("/soil/recommendations?field_id=1")
    assert r2.status_code in (200,404)
