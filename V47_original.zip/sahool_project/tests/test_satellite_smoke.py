def test_satellite_quota_and_tasks_smoke(client):
    # quota endpoint
    for ep in ["/satellite/quota", "/api/satellite/quota"]:
        r=client.get(ep)
        if r.status_code in (200,404):
            break
    # run sentinel task endpoint (should be protected / may 404)
    for ep in ["/satellite/run-sentinel", "/api/satellite/run-sentinel", "/satellite/sentinel/run"]:
        r=client.post(ep, json={"field_id":1})
        assert r.status_code in (200,202,400,404)
        break
