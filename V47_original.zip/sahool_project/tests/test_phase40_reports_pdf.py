def test_agro_report_pdf_smoke(client):
    r = client.get("/reports/agro.pdf?field_id=1&crop=wheat&stage=mid")
    assert r.status_code in (200,404)
