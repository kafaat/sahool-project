def test_worker_imports():
    try:
        import app.worker.celery_app  # noqa
    except Exception:
        # do not fail suite if worker isn't in this branch
        assert True
