import pytest

@pytest.mark.asyncio
async def test_weather_live_summary(monkeypatch, client):
    from app.modules.weather import providers

    async def fake_fetch(lat, lon):
        return {
            "latitude": lat, "longitude": lon, "hourly": {
                "time": ["2025-01-01T00:00"],
                "temperature_2m": [25.0],
                "relativehumidity_2m": [60.0],
                "windspeed_10m": [3.0],
                "shortwave_radiation": [800.0],
                "precipitation": [0.0],
                "cloudcover": [10.0]
            }
        }
    monkeypatch.setattr(providers.open_meteo, "fetch_open_meteo", fake_fetch)

    r = client.get("/weather/live?lat=30&lon=31")
    assert r.status_code == 200
    data = r.json()
    assert "summary" in data and data["summary"]["solar_radiation"] == 800.0
