import pytest

@pytest.mark.phase25
def test_suitability_scoring_ranges():
    from app.modules.soil.suitability import suitability_score, crop_score, best_crops
    class P:
        ph=7.0; ec_ds_m=1.0; som_pct=3.5; clay_pct=20; sand_pct=40
    p=P()
    s=suitability_score(p)
    assert 70 <= s <= 100
    assert crop_score(p,"tomato") >= 60
    top=best_crops(p)
    assert isinstance(top,list) and len(top)>0

@pytest.mark.phase25
def test_suitability_warnings():
    from app.modules.soil.suitability import suitability_report
    class P:
        ph=9.0; ec_ds_m=5.0; som_pct=0.5; clay_pct=50; sand_pct=10
    rep=suitability_report(P())
    assert rep["score"] <= 60
    assert "warnings" in rep and len(rep["warnings"])>=1
