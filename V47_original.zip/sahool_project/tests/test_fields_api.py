def test_fields_crud_smoke(client):
    # create field if endpoint exists
    endpoints_create = ["/fields", "/api/fields"]
    payload = {"name":"Test Field","latitude":30.0,"longitude":31.0,"area_ha":1.2}
    created_id=None
    for ep in endpoints_create:
        r = client.post(ep, json=payload)
        if r.status_code in (200,201):
            j=r.json()
            created_id = j.get("id") or j.get("item",{}).get("id")
            break
    # list
    for ep in endpoints_create:
        r = client.get(ep)
        if r.status_code==200:
            assert isinstance(r.json(), (dict,list))
            break
    assert True
