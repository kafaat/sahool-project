import pytest

@pytest.mark.phase25
def test_celery_tasks_importable():
    from app.worker import tasks
    assert hasattr(tasks, "ndvi_stress_daily")
    assert hasattr(tasks, "weekly_irrigation")
