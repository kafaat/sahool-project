def test_compare_before_after_smoke(client):
    endpoints=[
        "/compare/before-after",
        "/api/compare/before-after",
        "/satellite/compare"
    ]
    for ep in endpoints:
        r=client.get(ep)
        assert r.status_code in (200,400,404)
