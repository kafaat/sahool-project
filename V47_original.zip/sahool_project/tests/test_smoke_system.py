def test_health(client):
    r = client.get("/system/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"
