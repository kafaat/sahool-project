def test_usage_history_endpoint(client):
    r=client.get("/admin/usage/sentinel/history?days=3")
    assert r.status_code in (200,404)
