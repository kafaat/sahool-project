import pytest

@pytest.mark.asyncio
async def test_soil_depth_tiles_smoke(client):
    r = client.get("/soil/tiles/ph/0-30/8/0/0.png")
    assert r.status_code == 200
