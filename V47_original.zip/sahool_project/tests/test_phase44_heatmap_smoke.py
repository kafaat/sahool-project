import pytest
@pytest.mark.asyncio
async def test_heatmap_tile_smoke(client):
    r = client.get("/ndvi/heatmap/tiles/1/8/0/0.png")
    assert r.status_code in (200,404)
