def test_tile_cache_webp_param(client):
    r=client.get("/satellite/ndvi/tiles/1/8/0/0.png?fmt=webp")
    assert r.status_code in (200,404)
