import pytest

@pytest.mark.asyncio
async def test_disease_risk_endpoint_smoke(client):
    r = client.get("/disease/risk?field_id=1&crop=wheat&days=60")
    assert r.status_code in (200,404)
