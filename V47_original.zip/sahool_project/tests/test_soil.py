def test_soil_upsert_and_list(client):
    # create a dummy field if Field model exists
    from app.core.db import SessionLocal
    from app.modules.fields.models import Field
    db = SessionLocal()
    f = Field(tenant_id=1, name="Field A", latitude=30.0, longitude=31.0)
    db.add(f); db.commit(); db.refresh(f)

    payload = {"field_id": f.id, "sand_pct": 50, "silt_pct": 30, "clay_pct": 20, "ph": 7.0}
    r = client.post("/soil", json=payload)
    assert r.status_code == 200

    r2 = client.get("/soil")
    assert r2.status_code == 200
    items = r2.json()["items"]
    assert len(items) >= 1
    assert items[0]["ph"] == 7.0
