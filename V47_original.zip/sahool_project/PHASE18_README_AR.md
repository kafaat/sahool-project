# Phase 18 — Email/SMS MFA + Admin UI Forms + Granular RBAC + APIKey Tracking

## ما تم
1. MFA إضافي عبر البريد الإلكتروني:
   - /auth/mfa-email/send
   - /auth/mfa-email/confirm
   - /auth/mfa-email/disable
2. إعداد SMTP في Settings.
3. Admin UI مطوّرة:
   - إنشاء users / tenants / api keys من الواجهة
   - Usage bar
4. RBAC granular عبر permission matrix في app/core/permissions.py
   و require_role أصبح يقبل perm string.
5. API Key last_used_at يتم تحديثه تلقائيًا في كل طلب.

## متغيرات بيئة جديدة
```env
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=...
SMTP_PASS=...
SMTP_FROM=no-reply@example.com
MFA_EMAIL_TTL_SEC=300
```

## تفعيل MFA Email
1) إرسال كود:
POST /api/auth/mfa-email/send?user_id=2
2) تأكيد:
POST /api/auth/mfa-email/confirm?user_id=2&code=123456
3) login:
POST /api/auth/login?...&email_otp_code=123456
