# دليل استخدام المنصة -- الإصدار Markdown

## 1) اختيار الـ Tenant

كل طلب يحتاج `tenant_id` إمّا من: - الهيدر: `X-Tenant-Id: 1` - أو
الكويري: `?tenant_id=1`

## 2) إضافة حقل زراعي

### Endpoint

`POST /fields/`

### مثال:

``` bash
curl -X POST http://localhost:8000/fields/?tenant_id=1   -H "Content-Type: application/json"   -d '{
        "name": "My First Field",
        "shape": "circle",
        "data": {
          "center_lat": 24.5,
          "center_lon": 46.7,
          "radius_m": 1200,
          "num_points": 64
        },
        "area_ha": 45
      }'
```

## 3) جلب تفاصيل الحقل

`GET /fields/{field_id}?tenant_id=1`

## 4) بدء جلب الصورة الفضائية

`POST /satellite/images/fetch?field_id=10&tenant_id=1`

## 5) الحصول على الصور الفضائية

`GET /satellite/images/?field_id=10&tenant_id=1`

## 6) بدء تحليل NDVI

`POST /satellite/ndvi/process?image_id=5&tenant_id=1`

## 7) عرض نتائج NDVI

`GET /satellite/ndvi/?field_id=10&tenant_id=1`

## 8) عرض Timeline

`GET /satellite/ndvi/timeline?field_id=10&tenant_id=1`

## 9) عرض Tiles

    /satellite/ndvi/tiles/{ndvi_id}/{z}/{x}/{y}.png

## 10) عرض Legend

`GET /satellite/ndvi/legend.png`

## 11) عرض التنبيهات

`GET /alerts/?field_id=10&tenant_id=1`

## 12) التقرير الأسبوعي

`GET /reports/weekly?field_id=10&tenant_id=1`
