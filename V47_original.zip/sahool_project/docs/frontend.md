# Frontend (React + Tailwind) Dashboard

## Run locally
1. Start backend:
```bash
docker compose up --build -d
```

2. Start frontend:
```bash
cd frontend
npm install
npm run dev
```

Open:
http://localhost:5173

The dev server proxies /api/* to backend.


## Hotspots (Stress areas)
When a field is selected, the dashboard automatically overlays red hotspots derived from low NDVI pixels.


## Heatmap
The map shows low-NDVI heatmap circles derived from hotspots. Use the toggle to show/hide.


## Reports tab
Open the "التقارير" tab to see weekly report JSON per selected field.


## Compare tab
Use "المقارنة" لتحديد عدة حقول ومقارنة منحنيات NDVI.


## LST support
If NDVI stats include lst_mean, dashboard reports WSI_LST.
