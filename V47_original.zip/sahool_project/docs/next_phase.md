

## Exports
- CSV: GET /reports/weekly/export/csv?field_id=ID&tenant_id=T
- XLSX: GET /reports/weekly/export/xlsx?field_id=ID&tenant_id=T


## Monthly email reports
Configure SMTP_* and REPORT_RECIPIENTS env vars, then run celery beat.
