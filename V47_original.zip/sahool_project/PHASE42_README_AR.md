# Phase 42 — Tiles Caching + WebP + Prerender

## Caching
- Memory + Disk cache for:
  - satellite index tiles
  - NDVI tiles
  - soil tiles
- disk path: `/mnt/data/tile_cache/...`

## WebP
Optional query:
`?fmt=webp`
returns `image/webp` for lighter bandwidth.

## Prerender
Script:
`python -m app.scripts.prerender_tiles --result_id <id> --index ndvi --z 12`
