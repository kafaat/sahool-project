# Phase 16 — Full Admin Panel + JWT Refresh + DB RBAC

## ما تم
1. Refresh tokens + endpoints:
   - POST /auth/refresh
   - POST /auth/logout
2. RBAC من قاعدة البيانات تلقائياً (roles من users).
3. Admin endpoints:
   - /admin/tenants
   - /admin/users
   - /admin/apikeys
   - /admin/audit
   - /admin/usage/sentinel
4. Admin Panel في الويب مع Login/Refresh/Logout وتبويبات عرض JSON.

## ملاحظة
الـ Admin Panel MVP يعرض البيانات JSON.
يمكن لاحقًا تحويله إلى UI كاملة بدون تغيير API.
