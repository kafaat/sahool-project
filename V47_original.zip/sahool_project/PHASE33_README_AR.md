# Phase 33 — Stress Zones Polygons + Soil Spatial + Pest Risk + Yield

## الجديد
1. Zone polygons (coarse) من NDVI stress tile:
   - app/modules/agro_intel/zones.py
   - يخرج zone_polygons في /agro/ai

2. Soil spatial sampling من Soil tiles عند مركز الحقل:
   - app/modules/agro_intel/soil_spatial.py
   - يخرج soil.spatial_sample_center

3. Pest/Disease risk heuristic:
   - app/modules/agro_intel/pest_risk.py
   - يخرج pest_risk (level + notes)

4. Yield prediction mini-model:
   - app/modules/agro_intel/yield_model.py
   - يخرج yield_prediction

## Endpoint
GET /api/agro/ai?field_id=&crop=&stage=
