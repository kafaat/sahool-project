# CI via Docker (Backend + E2E)

- Backend tests:
  - docker compose up -d api
  - docker compose run tests

- E2E tests:
  - docker compose up -d api
  - docker compose run e2e

GitHub Actions uses the same flow.
