# Phase 46 — GIF/MP4 Export (Real)

## Backend
- GIF:
  `/api/video/timelapse.gif?field_id=&index=&days=&fps=&z=&x=&y=`
- MP4:
  `/api/video/timelapse.mp4?field_id=&index=&days=&fps=&z=&x=&y=`

> ملاحظة: النسخة الحالية ترندر Tile واحدة لكل فريم (XYZ). يمكن توسيعها لاحقًا لدعم bbox كامل للحقل.

## Frontend
- TimelapsePlayer يحتوي زر Export GIF و Export MP4 ويحمّل الملف مباشرة.

## Dependencies
- Pillow
- imageio + imageio-ffmpeg
- ffmpeg-python
