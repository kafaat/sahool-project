# Phase 15 — JWT Auth + Full RBAC + Admin Console

## ما تم إضافته
1. JWT login + bearer auth.
2. API Keys للأجهزة.
3. Models جديدة: tenants, users, api_keys.
4. Bootstrap تلقائي لأول tenant وsuperadmin لو DB فاضية.
5. عزل متعدد المستأجرين (dependencies=require_tenant) على أهم الراوترات.
6. صفحة AdminConsole بسيطة في الويب (MVP).

## متغيرات بيئة جديدة
```env
JWT_SECRET=change-this
BOOTSTRAP_ADMIN_EMAIL=admin@sahool.local
BOOTSTRAP_ADMIN_PASS=admin123
BOOTSTRAP_TENANT_NAME=default
```

## تسجيل الدخول
```
POST /api/auth/login?email=...&password=...&tenant_id=1
```

يرجع token.

## استعمال token
أرسل Headers:
- Authorization: Bearer <token>
- x-tenant-id: <tenant_id>
- x-roles: admin  (إن كنت تحتاج صلاحيات)
