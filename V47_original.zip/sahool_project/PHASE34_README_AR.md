# Phase 34 — GeoJSON Zones + Soil stats per Zone + Map Overlay

## الجديد
1. تحويل مناطق الإجهاد إلى GeoJSON:
   - app/modules/agro_intel/geojson.py
   - يخرج zones_geojson في /agro/ai

2. إحصائيات التربة لكل Zone:
   - app/modules/agro_intel/soil_zone_stats.py
   - يخرج zone_polygons_stats

3. عرض Polygons على الخريطة:
   - AgroIntelDashboard يضع geojson في window.__agroZones
   - MapView يعرض AgroZonesLayer

## Endpoint
GET /api/agro/ai?field_id=&crop=&stage=
