# Phase 39 — Crop Disease Risk Engine

## Backend
- قواعد أمراض حسب المحصول (wheat/corn/tomato) قابلة للتوسعة:
  `app/modules/disease/rules.py`
- خدمة حساب المخاطر:
  `app/modules/disease/service.py`
- Endpoint:
  `GET /api/disease/risk?field_id=&crop=&days=`

## دمج Agro AI
- تم إضافة disease_risk داخل /agro/ai (إن كان module agro_intel موجوداً)

## Web
- يظهر Disease Risk في Agro Dashboard
