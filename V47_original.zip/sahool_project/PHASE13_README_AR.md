# Phase 13 — Auto COG + Tenant Buckets + Cleanup

## ماذا تغير؟
1. كل ملفات المؤشرات يتم تحويلها إلى COG تلقائياً ثم رفعها إلى S3/MinIO.
2. يتم حذف الملفات المحلية بعد نجاح الرفع لتقليل المساحة.
3. مسارات التخزين أصبحت تدعم multi-tenant عبر prefix:
   `tenants/{tenant_id}/...`
4. Tiles بعد precompute يتم رفعها للسحابة ثم حذفها محلياً.
5. SentinelHub process صار فيه retries/backoff.

## مثال مسار في S3
```
tenants/3/indices/ndvi/120.tif
tenants/3/tiles/ndvi/120/14/8765/5512.png
```
