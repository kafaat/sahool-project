#!/usr/bin/env bash
set -euo pipefail
TS=$(date +"%Y%m%d_%H%M%S")
mkdir -p backups
docker-compose -f docker-compose.prod.yml exec -T db pg_dump -U sahool sahool > backups/sahool_${TS}.sql
echo "Backup created: backups/sahool_${TS}.sql"
