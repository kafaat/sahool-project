#!/usr/bin/env bash
set -euo pipefail
FILE=${1:-}
if [ -z "$FILE" ]; then
  echo "Usage: restore.sh backups/file.sql"
  exit 1
fi
cat "$FILE" | docker-compose -f docker-compose.prod.yml exec -T db psql -U sahool sahool
echo "Restored from $FILE"
