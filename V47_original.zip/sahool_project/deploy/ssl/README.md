# SSL (Phase 10)

## Option A: Let's Encrypt with certbot (recommended)
Run certbot on host and mount certs into nginx:

```bash
sudo certbot certonly --standalone -d YOUR_DOMAIN
```

Then set volumes in docker-compose.prod.yml:

```yaml
nginx:
  volumes:
    - /etc/letsencrypt/live/YOUR_DOMAIN:/etc/nginx/certs:ro
```

Uncomment ssl lines in `deploy/nginx/nginx.conf` and restart.

## Option B: Cloud provider managed certs
If you use AWS ALB / Cloudflare, keep nginx on port 80 behind TLS terminator.
