# Phase 37 — Soil Multi-Layer Engine

## الجديد
- إضافة قيم التربة لثلاث أعماق: 0-30 / 30-60 / 60-100 سم
- Tiles depth-aware:
  `/api/soil/tiles/{metric}/{depth}/{z}/{x}/{y}.png`
- Endpoint:
  `/api/soil/profile-depth?field_id=&depth=`

## الواجهة
- selector لاختيار العمق في SoilDashboard
- Tiles overlays تستخدم depth تلقائيًا
