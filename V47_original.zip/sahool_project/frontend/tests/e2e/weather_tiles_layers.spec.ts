import { test, expect } from '@playwright/test';

test('toggle weather layers (mock tiles)', async ({ page }) => {
  await page.route('**/api/weather/tiles/**', route => {
    route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.from([]) });
  });

  await page.goto('/');
  const map = page.locator('.leaflet-container');
  if (!(await map.count())) test.skip();

  const layers = page.locator('.leaflet-control-layers');
  await expect(layers.first()).toBeVisible();
  await layers.first().click();

  const solar = page.getByText(/solar radiation/i);
  if (await solar.count()) await solar.first().click();

  const et0 = page.getByText(/ET₀|ET0/i);
  if (await et0.count()) await et0.first().click();
});
