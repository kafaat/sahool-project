import { test, expect } from '@playwright/test';

test('navigate between tabs', async ({ page }) => {
  await page.goto('/');
  // Try to click some tab buttons if present
  const weatherTab = page.getByText(/weather/i);
  if (await weatherTab.count()) {
    await weatherTab.first().click();
    await expect(page.getByText(/weather dashboard/i)).toBeVisible();
  }

  const soilTab = page.getByText(/soil/i);
  if (await soilTab.count()) {
    await soilTab.first().click();
    await expect(page.getByText(/soil dashboard/i)).toBeVisible();
  }
});
