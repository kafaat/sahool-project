import { test, expect } from '@playwright/test';

test('irrigation zones loads', async ({ page }) => {
  await page.route('**/api/weather/irrigation-zones**', route => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        field_id: 1,
        base: { net_irrigation_mm: 10 },
        zones: [{level:'high',net_mm:12.5},{level:'moderate',net_mm:11},{level:'low',net_mm:10}]
      })
    });
  });

  await page.goto('/');
  const weatherTab = page.getByText(/weather/i);
  if (await weatherTab.count()) {
    await weatherTab.first().click();
    // doesn't require specific UI, just ensures no crash
    await expect(page.locator('body')).toBeVisible();
  }
});
