import { test, expect } from '@playwright/test';

test('login (mock) then save soil profile', async ({ page }) => {
  // Mock login endpoint if UI uses it
  await page.route('**/auth/login**', route => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ access_token: 'testtoken' })
    });
  });
  await page.route('**/api/soil**', route => {
    if (route.request().method() === 'POST') {
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ item: { id: 1 }})});
    } else {
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ items: [] })});
    }
  });

  await page.goto('/');
  // Try to locate login form if present
  const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  const passInput  = page.locator('input[type="password"]');
  if (await emailInput.count() && await passInput.count()) {
    await emailInput.first().fill('admin@test.com');
    await passInput.first().fill('admin123');
    const btn = page.getByRole('button', { name: /login|sign in/i });
    if (await btn.count()) await btn.first().click();
  }

  const soilTab = page.getByText(/soil/i);
  if (await soilTab.count()) {
    await soilTab.first().click();
    await expect(page.getByText(/soil dashboard/i)).toBeVisible();
    await page.getByPlaceholder(/field id/i).fill('1');
    await page.getByPlaceholder(/sand/i).fill('50');
    await page.getByPlaceholder(/silt/i).fill('30');
    await page.getByPlaceholder(/clay/i).fill('20');
    await page.getByPlaceholder(/ph/i).fill('7');
    await page.getByRole('button', { name: /save profile/i }).click();
  }
});
