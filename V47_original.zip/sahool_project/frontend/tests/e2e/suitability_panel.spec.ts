import { test, expect } from '@playwright/test';

test('suitability panel shows', async ({ page }) => {
  await page.route('**/api/soil/suitability**', route => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ score: 80, best_crops: ['wheat','tomato'], warnings: [] })
    });
  });

  await page.goto('/');
  const soilTab = page.getByText(/soil/i);
  if (await soilTab.count()) {
    await soilTab.first().click();
    await expect(page.getByText(/suitability score/i)).toBeVisible();
  }
});
