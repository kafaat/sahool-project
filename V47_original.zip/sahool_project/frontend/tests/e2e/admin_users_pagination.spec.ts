import { test, expect } from '@playwright/test';

test('admin users page opens (if exists)', async ({ page }) => {
  await page.route('**/api/admin/users**', route => {
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ items: [] })});
  });
  await page.goto('/');
  const adminTab = page.getByText(/admin/i);
  if (await adminTab.count()) {
    await adminTab.first().click();
    await expect(page.getByText(/users/i)).toBeVisible();
  }
});
