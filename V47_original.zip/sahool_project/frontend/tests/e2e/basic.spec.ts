import { test, expect } from '@playwright/test';

test('app loads', async ({ page }) => {
  await page.goto('/');
  // Expect main app container or login text
  await expect(page.locator('body')).toBeVisible();
});
