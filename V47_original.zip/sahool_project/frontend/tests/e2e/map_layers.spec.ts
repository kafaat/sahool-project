import { test, expect } from '@playwright/test';

test('map renders and layers control exists', async ({ page }) => {
  await page.goto('/');
  const map = page.locator('.leaflet-container');
  if (await map.count()) {
    await expect(map.first()).toBeVisible();
    const layersBtn = page.locator('.leaflet-control-layers');
    await expect(layersBtn.first()).toBeVisible();
  } else {
    test.skip();
  }
});
