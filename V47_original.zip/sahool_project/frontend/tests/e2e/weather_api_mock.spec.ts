import { test, expect } from '@playwright/test';

test('weather dashboard loads cards (mockable)', async ({ page }) => {
  await page.route('**/api/weather/live**', route => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        summary: {
          temperature: 25.0,
          humidity: 60,
          wind_speed: 2.5,
          solar_radiation: 800,
          et0: 4.2,
          sunshine_hours: 8,
          time: "2025-01-01T00:00"
        },
        raw: {}
      })
    });
  });

  await page.goto('/');
  const weatherTab = page.getByText(/weather/i);
  if (await weatherTab.count()) {
    await weatherTab.first().click();
    await expect(page.getByText(/temperature/i)).toBeVisible();
    await expect(page.getByText(/ET₀|ET0/i)).toBeVisible();
  }
});
