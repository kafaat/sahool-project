import { test, expect } from '@playwright/test';

test('soil tiles overlays toggle', async ({ page }) => {
  await page.route('**/api/soil/tiles/**', route => {
    route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.from([]) });
  });

  await page.goto('/');
  const map = page.locator('.leaflet-container');
  if (!(await map.count())) test.skip();

  const layers = page.locator('.leaflet-control-layers');
  await expect(layers.first()).toBeVisible();
  await layers.first().click();

  const ph = page.getByText(/soil pH/i);
  if (await ph.count()) await ph.first().click();

  const ec = page.getByText(/soil ec/i);
  if (await ec.count()) await ec.first().click();

  const som = page.getByText(/soil som/i);
  if (await som.count()) await som.first().click();
});
