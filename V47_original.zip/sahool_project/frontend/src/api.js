export async function fetchDashboardData(tenantId=1){
  const res = await fetch(`/api/dashboard/data?tenant_id=${tenantId}`);
  if(!res.ok) throw new Error("Failed to load dashboard data");
  return res.json();
}

export async function fetchTimeline(fieldId, tenantId=1){
  const res = await fetch(`/api/satellite/ndvi/timeline?field_id=${fieldId}&tenant_id=${tenantId}`);
  if(!res.ok) throw new Error("Failed to load timeline");
  return res.json();
}

export async function fetchAlerts(tenantId=1){
  const res = await fetch(`/api/alerts/dashboard?tenant_id=${tenantId}`);
  if(!res.ok) throw new Error("Failed to load alerts");
  return res.json();
}

export async function fetchWeather(fieldId, tenantId=1){
  const res = await fetch(`/api/weather/current?field_id=${fieldId}&tenant_id=${tenantId}`);
  if(!res.ok) throw new Error("Failed to load weather");
  return res.json();
}


export async function listNdviResults(fieldId, tenantId=1){
  const res = await fetch(`/api/satellite/ndvi/results?field_id=${fieldId}&tenant_id=${tenantId}`);
  if(!res.ok) throw new Error("Failed to load NDVI results");
  const data = await res.json();
  return data.items || data.results || data;
}

export async function fetchLatestNdviResult(fieldId, tenantId=1){
  const rows = await listNdviResults(fieldId, tenantId);
  return rows?.[0] || null;
}


export async function fetchLegendJson(indexName="ndvi"){
  const res = await fetch(`/api/satellite/legend/${indexName}.json`);
  if(!res.ok) throw new Error("Legend load failed");
  return res.json();
}


export async function fetchCloudTimeline(fieldId){
  const res = await fetch(`/api/satellite/qa/cloud-timeline?field_id=${fieldId}`);
  if(!res.ok) throw new Error("Cloud QA load failed");
  return res.json();
}
