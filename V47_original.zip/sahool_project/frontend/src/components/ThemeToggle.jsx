import { Moon, Sun } from "lucide-react";

export default function ThemeToggle({theme, onToggle}){
  const isDark = theme==="dark";
  return (
    <button
      onClick={onToggle}
      className="p-2 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition"
      title="Toggle theme"
    >
      {isDark ? <Sun size={18}/> : <Moon size={18}/>}
    </button>
  );
}
