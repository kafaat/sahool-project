export default function Panel({title, children, right}){
  return (
    <section className="bg-white dark:bg-slate-950 border dark:border-slate-800 rounded-2xl shadow-sm">
      <div className="px-4 py-3 border-b dark:border-slate-800 flex items-center justify-between">
        <div className="font-bold text-slate-900 dark:text-white">{title}</div>
        {right}
      </div>
      <div className="p-4">
        {children}
      </div>
    </section>
  );
}
