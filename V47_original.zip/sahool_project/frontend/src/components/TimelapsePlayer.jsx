import React, {useEffect, useRef, useState} from "react";
import { API, headers } from "../services/api";

export default function TimelapsePlayer({fieldId, indexName, onFrame}){
  const [frames,setFrames]=useState([]);
  const [idx,setIdx]=useState(0);
  const [playing,setPlaying]=useState(false);
  const [speed,setSpeed]=useState(1);
  const timerRef=useRef(null);

  useEffect(()=>{
    async function load(){
      if(!fieldId || !indexName) return;
      const r=await fetch(API(`/timeline/${indexName}/frames?field_id=${fieldId}&days=365`),{headers});
      if(!r.ok){ setFrames([]); return; }
      const j=await r.json();
      setFrames(j.frames||[]);
      setIdx(0);
    }
    load();
  },[fieldId,indexName]);

  useEffect(()=>{
    if(!playing || frames.length===0) return;
    timerRef.current=setInterval(()=>{
      setIdx(i=>{
        const ni=(i+1)%frames.length;
        return ni;
      });
    }, 1200/speed);
    return ()=> clearInterval(timerRef.current);
  },[playing,speed,frames]);

  useEffect(()=>{
    const f=frames[idx];
    if(f) onFrame(f);
  },[idx,frames]);

  async function exportMp4(){
    if(!fieldId) return;
    const url = API(`/video/timelapse.mp4?field_id=${fieldId}&index=${indexName}&days=365&fps=${speed*2}`);
    const a=document.createElement('a');
    a.href=url; a.download=`${indexName}_timelapse.mp4`;
    document.body.appendChild(a); a.click(); a.remove();
  }

  async function exportGif(){
    if(!fieldId) return;
    const url = API(`/video/timelapse.gif?field_id=${fieldId}&index=${indexName}&days=365&fps=${speed*2}`);
    const a=document.createElement('a');
    a.href=url;
    a.download=`${indexName}_timelapse.gif`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  return (
    <div className="fixed bottom-28 left-3 bg-white border rounded shadow-lg p-2 z-[9999] text-xs space-y-2">
      <div className="font-semibold">Timelapse Player</div>
      <div className="flex items-center gap-2">
        <button className="border px-2 py-1 rounded" onClick={()=>setPlaying(p=>!p)}>{playing?"Pause":"Play"}</button>
        <label>Speed</label>
        <select className="border rounded px-1 py-1" value={speed} onChange={e=>setSpeed(parseFloat(e.target.value))}>
          <option value="1">x1</option>
          <option value="2">x2</option>
          <option value="4">x4</option>
        </select>
        <button className="border px-2 py-1 rounded ml-auto" onClick={exportGif}>Export GIF</button>
        <button className="border px-2 py-1 rounded" onClick={exportMp4}>Export MP4</button>
      </div>
      {frames[idx] && <div>Date: {frames[idx].date}</div>}
      <input type="range" min="0" max={frames.length-1} value={idx} onChange={e=>setIdx(parseInt(e.target.value))}
        className="w-full"/>
    </div>
  );
}
