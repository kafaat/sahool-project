export default function WeatherWidget({weather}){
  const cur = weather?.current;
  if(!cur) return null;
  return (
    <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-md rounded-2xl shadow-lg p-3 text-xs space-y-1">
      <div className="font-semibold text-slate-900 dark:text-white text-sm">Weather Now</div>
      <div className="text-slate-700 dark:text-slate-300">
        🌡 {cur.temperature_c ?? "—"}°C
        <span className="ml-2">💧 {cur.humidity_pct ?? "—"}%</span>
      </div>
      <div className="text-slate-700 dark:text-slate-300">
        🌬 {cur.wind_kmh ?? "—"} km/h
        <span className="ml-2">☔ {cur.precip_mm ?? "—"} mm</span>
      </div>
    </div>
  );
}
