import React from "react";

const INDEX_LAYERS = [
  {id:"heatmap", label:"NDVI Stress Heatmap"},
  {id:"ndvi", label:"NDVI"},
  {id:"ndre", label:"NDRE"},
  {id:"gndvi", label:"GNDVI"},
  {id:"evi", label:"EVI"},
  {id:"savi", label:"SAVI"},
  {id:"ndwi", label:"NDWI"},
  {id:"vari", label:"VARI"},
  {id:"gci", label:"GCI"},
  {id:"nbr", label:"NBR"},
];

const SOIL_LAYERS = [
  {id:"ph", label:"Soil pH"},
  {id:"ec_ds_m", label:"Soil EC"},
  {id:"som_pct", label:"Soil SOM"},
];

export default function LayersPanel({layers,setLayers, soilDepth,setSoilDepth, opacity,setOpacity}){
  function toggle(id){
    setLayers(prev=> ({...prev, [id]: !prev[id]}));
  }
  return (
    <div className="fixed right-3 top-16 w-72 bg-white border rounded shadow-lg p-3 space-y-3 z-[9999]">
      <div className="font-bold text-lg">Layers</div>

      <div>
        <div className="font-semibold text-sm mb-1">Vegetation Indices</div>
        <div className="space-y-1">
          {INDEX_LAYERS.map(l=>(
            <label key={l.id} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={!!layers[l.id]} onChange={()=>toggle(l.id)} />
              <span>{l.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <div className="font-semibold text-sm mb-1">Soil Tiles</div>
        <div className="flex gap-1 mb-2">
          <select className="border rounded px-2 py-1 text-sm" value={soilDepth} onChange={e=>setSoilDepth(e.target.value)}>
            <option value="surface">surface</option>
            <option value="0-30">0-30cm</option>
            <option value="30-60">30-60cm</option>
            <option value="60-100">60-100cm</option>
          </select>
        </div>
        <div className="space-y-1">
          {SOIL_LAYERS.map(l=>(
            <label key={l.id} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={!!layers[`soil_${l.id}`]} onChange={()=>toggle(`soil_${l.id}`)} />
              <span>{l.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <div className="font-semibold text-sm mb-1">Blend Mode</div>
        <select className="border rounded px-2 py-1 text-sm w-full" value={layers.__blend||'normal'} onChange={e=>setLayers(prev=>({...prev,__blend:e.target.value}))}>
          <option value="normal">normal</option>
          <option value="multiply">multiply</option>
          <option value="overlay">overlay</option>
          <option value="soft-light">soft-light</option>
        </select>
      </div>

      <div>
        <div className="font-semibold text-sm mb-1">Opacity</div>
        <input type="range" min="0" max="1" step="0.05" value={opacity}
          onChange={e=>setOpacity(parseFloat(e.target.value))} className="w-full"/>
        <div className="text-xs text-gray-600">{Math.round(opacity*100)}%</div>
      </div>
    </div>
  );
}
