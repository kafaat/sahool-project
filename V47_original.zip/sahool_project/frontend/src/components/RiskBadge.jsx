const COLORS = {
  0: "bg-gray-400 text-white",
  1: "bg-green-600 text-white",
  2: "bg-yellow-400 text-black",
  3: "bg-orange-500 text-white",
  4: "bg-red-600 text-white",
  5: "bg-black text-white",
};

const LABELS = {
  0: "لا بيانات",
  1: "طبيعي",
  2: "مراقبة",
  3: "خطر متوسط",
  4: "خطر عالي",
  5: "حرج",
};

export default function RiskBadge({level=0}){
  return (
    <span className={`px-2 py-1 rounded text-xs font-bold ${COLORS[level] || COLORS[0]}`}>
      {LABELS[level] || LABELS[0]}
    </span>
  );
}
