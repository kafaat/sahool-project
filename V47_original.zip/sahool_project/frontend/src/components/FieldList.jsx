import RiskBadge from "./RiskBadge.jsx";

export default function FieldList({fields, selectedId, onSelect}){
  return (
    <div className="space-y-2">
      {fields.map(f => (
        <button
          key={f.id}
          onClick={()=>onSelect(f.id)}
          className={`w-full text-left p-3 rounded border hover:bg-slate-50 transition ${selectedId===f.id?"border-blue-500 bg-blue-50":"border-slate-200 bg-white"}`}
        >
          <div className="flex items-center justify-between">
            <div className="font-semibold">{f.name}</div>
            <RiskBadge level={f.risk_level} />
          </div>
          <div className="text-xs text-slate-600 mt-1">
            المساحة: {f.area_ha ?? 0} هـ | NDVI: {f.latest_ndvi?.toFixed?.(2) ?? "N/A"} | VSI: {f.vsi?.toFixed?.(0) ?? "N/A"}
            {f.delta_ndvi!=null && (
              <span className="ml-2">Δ {f.delta_ndvi.toFixed(2)}</span>
            )}
          </div>
        </button>
      ))}
    </div>
  );
}
