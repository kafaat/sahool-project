import { Bell, Leaf, LayoutDashboard, Settings } from "lucide-react";
import ThemeToggle from "./ThemeToggle.jsx";

export default function TopBar({tenantId, onTenantChange, activeTab, onTabChange, theme, onToggleTheme}){
  const tabs = [
    {id:"map", label:"Dashboard", icon: LayoutDashboard},
    {id:"timeline", label:"Timeline", icon: Leaf},
    {id:"weather", label:"Weather", icon: Leaf},
    {id:"alerts", label:"Alerts", icon: Bell},
    {id:"reports", label:"Reports", icon: Leaf},
    {id:"compare", label:"Compare", icon: Settings},
  ];
  return (
    <header className="h-14 bg-white dark:bg-slate-950 border-b dark:border-slate-800 flex items-center px-4 justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">S</div>
        <div className="font-extrabold tracking-tight">Sahool</div>
        <div className="text-xs text-slate-500 ml-1">Agri Intelligence</div>
      </div>

      <nav className="hidden md:flex items-center gap-1 bg-slate-50 dark:bg-slate-900 rounded-lg p-1">
        {tabs.map(t=>{
          const Icon=t.icon;
          const active = activeTab===t.id;
          return (
            <button
              key={t.id}
              onClick={()=>onTabChange(t.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-semibold transition
                ${active?"bg-white dark:bg-slate-950 shadow text-slate-900 dark:text-white":"text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"}`}
            >
              <Icon size={16}/>
              {t.label}
            </button>
          );
        })}
      </nav>

      <div className="flex items-center gap-2">
        <select
          className="border rounded-md px-2 py-1 text-sm bg-white"
          value={tenantId}
          onChange={(e)=>onTenantChange(Number(e.target.value))}
        >
          {[1,2,3,4,5].map(t=>(
            <option key={t} value={t}>Tenant {t}</option>
          ))}
        </select>
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            <button className="p-2 rounded-md hover:bg-slate-50 dark:hover:bg-slate-800"><Bell size={18}/></button>
      </div>
    </header>
  );
}
