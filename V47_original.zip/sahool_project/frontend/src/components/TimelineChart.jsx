import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale, LinearScale,
  PointElement, LineElement,
  Tooltip, Legend
} from "chart.js";
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

export default function TimelineChart({timeline}){
  if(!timeline?.items?.length){
    return <div className="text-slate-500 text-sm">لا يوجد بيانات NDVI بعد.</div>;
  }
  const labels = timeline.items.map(x => (x.processed_at || x.date || "").slice(0,10));
  const values = timeline.items.map(x => x.mean_ndvi);

  const data = {
    labels,
    datasets: [{
      label: "NDVI",
      data: values,
      tension: 0.35
    }]
  };
  const options = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: { y: { min: 0, max: 1 } }
  };
  return <Line data={data} options={options} />;
}
