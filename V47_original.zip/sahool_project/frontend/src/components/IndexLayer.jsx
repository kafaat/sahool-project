import { useEffect, useState } from "react";
import { TileLayer } from "react-leaflet";
import { fetchLatestNdviResult } from "../api.js";

/** Overlay tiles for selected index using latest NDVIResult as holder. */
export default function IndexLayer({ fieldId, indexName="ndvi", opacity=0.7 }) {
  const [latest, setLatest] = useState(null);

  useEffect(()=>{
    if(!fieldId) return;
    fetchLatestNdviResult(fieldId).then(setLatest).catch(()=>setLatest(null));
  },[fieldId]);

  if(!latest) return null;
  const url = `/api/satellite/${indexName}/tiles/${latest.id}/{z}/{x}/{y}.png`;
  return <TileLayer url={url} opacity={opacity} />;
}
