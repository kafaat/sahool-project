import React, {useEffect, useState} from "react";
import { Line } from "react-chartjs-2";
import { API, headers } from "../services/api";

export default function TimelineSlider({fieldId, indexName, onFrameChange}){
  const [days,setDays]=useState(365);
  const [ts,setTs]=useState(null);
  const [idx,setIdx]=useState(0);

  useEffect(()=>{
    async function load(){
      if(!fieldId || !indexName) return;
      const r=await fetch(API(`/timeline/${indexName}/timeseries?field_id=${fieldId}&days=${days}`),{headers});
      if(!r.ok){ setTs(null); return;}
      const j=await r.json();
      setTs(j);
      setIdx(0);
      if(j.points?.length) onFrameChange(j.points[0]);
    }
    load();
  },[fieldId,indexName,days]);

  const points=ts?.points||[];
  const current=points[idx];

  const chartData = ts ? {
    labels: points.map(p=>p.date),
    datasets: [{label:`${indexName.toUpperCase()} mean`, data: points.map(p=>p.mean)}]
  } : null;

  function change(i){
    setIdx(i);
    const p=points[i];
    if(p) onFrameChange(p);
  }

  return (
    <div className="fixed bottom-3 left-3 right-80 bg-white border rounded shadow-lg p-3 z-[9999] space-y-2">
      <div className="flex items-center gap-2">
        <div className="font-semibold text-sm">Timeline: {indexName.toUpperCase()}</div>
        <div className="ml-auto flex items-center gap-2">
          <label className="text-xs">Days</label>
          <input type="number" className="border rounded px-2 py-1 w-20 text-xs" value={days} onChange={e=>setDays(e.target.value)} />
        </div>
      </div>

      {chartData && <div className="h-24"><Line data={chartData} options={{responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}}}/></div>}

      {current && (
        <div className="space-y-1">
          <div className="text-xs">Date: {current.date}</div>
          <input type="range" min="0" max={points.length-1} value={idx}
            onChange={e=>change(parseInt(e.target.value))} className="w-full"/>
        </div>
      )}
    </div>
  );
}
