import RiskBadge from "./RiskBadge.jsx";

export default function Sidebar({fields, selectedId, onSelect, indexName="ndvi", onIndexChange=()=>{}}){
  return (
    <aside className="w-80 bg-white dark:bg-slate-950 border-r dark:border-slate-800 h-full flex flex-col">
      <div className="p-4 border-b dark:border-slate-800">
        <div className="font-bold text-slate-900 dark:text-white">Fields</div>
        <div className="text-xs text-slate-500 dark:text-slate-400">Select a field to view NDVI layer</div>
      </div>


      <div className="p-3 border-b dark:border-slate-800 space-y-2">
        <div className="text-xs text-slate-500 dark:text-slate-400">Index Layer</div>
        <div className="flex items-center gap-2 my-2">
  <input id="anomToggle" type="checkbox" checked={showAnomalyIndex} onChange={e=>setShowAnomalyIndex(e.target.checked)} />
  <label htmlFor="anomToggle" className="text-xs text-slate-600 dark:text-slate-300">Show anomaly for selected index</label>
</div>
<select value={indexName} onChange={e=>onIndexChange(e.target.value)}
          className="w-full p-2 rounded border dark:border-slate-800 bg-white dark:bg-slate-950 text-sm">
          {["ndvi","ndre","gndvi","savi","evi","ndwi"].map(i=>(
            <option key={i} value={i}>{i.toUpperCase()}</option>
          ))}
        </select>
      </div>

      <div className="p-3 overflow-y-auto space-y-2">
        {fields.map(f=>(
          <button
            key={f.id}
            onClick={()=>onSelect(f.id)}
            className={`w-full text-left p-3 rounded-xl border transition hover:bg-slate-50 dark:hover:bg-slate-900
              ${selectedId===f.id?"border-emerald-500 bg-emerald-50/60 dark:bg-emerald-900/20":"border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950"}`}
          >
            <div className="flex items-center justify-between">
              <div className="font-semibold text-slate-900 dark:text-white">{f.name}</div>
              <RiskBadge level={f.risk_level}/>
            </div>
            <div className="mt-1 text-xs text-slate-600 flex flex-wrap gap-x-2 gap-y-1">
              <span>NDVI: {f.latest_ndvi?.toFixed?.(2) ?? "N/A"}</span>
              {f.delta_ndvi!=null && <span>Δ {f.delta_ndvi.toFixed(2)}</span>}
              <span>VSI: {f.vsi?.toFixed?.(0) ?? "N/A"}</span>
              {f.fui!=null && <span>FUI: {f.fui.toFixed(2)}</span>}
            </div>
          </button>
        ))}
        {fields.length===0 && (
          <div className="text-sm text-slate-500 dark:text-slate-400 p-3">No fields yet.</div>
        )}
      </div>
    </aside>
  );
}


  useEffect(() => {
    let alive=true;
    (async ()=>{
      try{
        const lg=await fetchLegendJson(indexName);
        if(alive) setLegend(lg);
      }catch(e){
        if(alive) setLegend(null);
      }
    })();
    return ()=>{alive=false};
  }, [indexName]);
