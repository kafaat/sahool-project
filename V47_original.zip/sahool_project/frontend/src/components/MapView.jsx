import React, {useState} from "react";

import { GeoJSON } from "react-leaflet";

function AgroZonesLayer({geojson}){
  if(!geojson) return null;
  return (
    <>
      <LayersPanel layers={layers} setLayers={setLayers} soilDepth={soilDepth} setSoilDepth={setSoilDepth} opacity={opacity} setOpacity={setOpacity} />
      <TimelapsePlayer fieldId={window.__selectedFieldId} indexName={timelineIndex} onFrame={(f)=>{setFrame(f); window.__currentResultId=f.result_id;}} />
      <TimelineSlider fieldId={window.__selectedFieldId} indexName={timelineIndex} onFrameChange={(p)=>{setFrame(p); window.__currentResultId=p.result_id;}} />

    <GeoJSON data={geojson} style={(feat)=>({
      color: feat.properties.level==="high" ? "#ff0000" :
             feat.properties.level==="moderate" ? "#ffcc00" : "#00aa00",
      weight: 2,
      fillOpacity: 0.15
    })}/>
      </>
  );
}

import { MapContainer, TileLayer, GeoJSON } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { useEffect, useMemo, useRef, useState } from "react";
import WeatherWidget from "./WeatherWidget.jsx";
import { fetchWeather } from "../api.js";

import LayersPanel from "../components/LayersPanel";
import TimelineSlider from "../components/TimelineSlider";
import TimelapsePlayer from "../components/TimelapsePlayer";

export default function MapView({ fields, selectedId, onSelect, timelineItems = [], animateNdvi=false, animationSpeed=1200 }) {
  const [layers,setLayers]=useState({ndvi:true});
  const [soilDepth,setSoilDepth]=useState('surface');
  const [opacity,setOpacity]=useState(0.65);
  const [frame,setFrame]=useState(null);
  const [timelineIndex,setTimelineIndex]=useState('ndvi');

  function tileUrl(index){
    const rid = frame?.result_id || window.__currentResultId;
    if(!rid) return null;
    return API(`/satellite/${index}/tiles/${rid}/{z}/{x}/{y}.png`);
  }

  function soilUrl(metric){
    return API(`/soil/tiles/${metric}/${soilDepth}/{z}/{x}/{y}.png`);
  }

  const indexLayers = ['ndvi','ndre','gndvi','evi','savi','ndwi','vari','gci','nbr'];
 selectedField = useMemo(()=>fields.find(f=>f.id===selectedId), [fields, selectedId]);

  const [hotspots, setHotspots] = useState([]);
  const [heatmapPoints, setHeatmapPoints] = useState([]);
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [activeLayer, setActiveLayer] = useState("ndvi");
  const [weather, setWeather] = useState(null);

  const mapRef = useRef(null);
  const ndviLayerRef = useRef(null);

  // Fetch hotspots/heatmap + weather on field change
  useEffect(()=>{
    (async ()=>{
      if(!selectedField?.latest_ndvi_id){
        setHotspots([]); setHeatmapPoints([]); setWeather(null); return;
      }
      try{
        const res = await fetch(`/api/satellite/ndvi/hotspots?ndvi_id=${selectedField.latest_ndvi_id}&dynamic=true`);
        const data = await res.json();
        setHotspots(data.polygons || []);
        setHeatmapPoints(data.heatmap_points || []);
      }catch{
        setHotspots([]); setHeatmapPoints([]);
      }
      try{
        const w = await fetchWeather(selectedField.id, selectedField.tenant_id || 1);
        setWeather(w.weather);
      }catch{ setWeather(null); }
    })();
  },[selectedField?.latest_ndvi_id, selectedField?.id]);

  // Init measurement tools once
  useEffect(()=>{
    const map = mapRef.current;
    if(!map || map._drawInited) return;
    map._drawInited = True = true;
    const drawControl = new L.Control.Draw({
      draw: { polygon:true, polyline:true, rectangle:true, circle:true, marker:true },
      edit: false
    });
    map.addControl(drawControl);
    map.on(L.Draw.Event.CREATED, function (e) {
      const layer = e.layer;
      layer.addTo(map);
    });
  },[]);

  // NDVI animation: cycle through timelineItems (expect items with tile_url)
  useEffect(()=>{
    if(!animateNdvi || !timelineItems?.length) return;
    const ndviLayer = ndviLayerRef.current;
    if(!ndviLayer) return;
    let idx = 0;
    const handle = setInterval(()=>{
      idx = (idx+1) % timelineItems.length;
      const t = timelineItems[idx];
      if(t?.tile_url){
        ndviLayer.setUrl(t.tile_url);
      }
    }, animationSpeed);
    return (
    <>
      <LayersPanel layers={layers} setLayers={setLayers} soilDepth={soilDepth} setSoilDepth={setSoilDepth} opacity={opacity} setOpacity={setOpacity} />
      <TimelapsePlayer fieldId={window.__selectedFieldId} indexName={timelineIndex} onFrame={(f)=>{setFrame(f); window.__currentResultId=f.result_id;}} />
      <TimelineSlider fieldId={window.__selectedFieldId} indexName={timelineIndex} onFrameChange={(p)=>{setFrame(p); window.__currentResultId=p.result_id;}} />
)=>clearInterval(handle);
  },[animateNdvi, animationSpeed, timelineItems]);

  const riskColor = (level)=>{
    if(level>=5) return "#dc2626";
    if(level>=4) return "#f97316";
    if(level>=3) return "#f59e0b";
    if(level>=2) return "#84cc16";
    return "#22c55e";
  };

  const onEachField = (feature, layer)=>{
    const id = feature.properties?.id ?? feature.properties?.field_id;
    layer.on("click", ()=>onSelect?.(id));
  };

  return (
    <>
      <LayersPanel layers={layers} setLayers={setLayers} soilDepth={soilDepth} setSoilDepth={setSoilDepth} opacity={opacity} setOpacity={setOpacity} />
      <TimelapsePlayer fieldId={window.__selectedFieldId} indexName={timelineIndex} onFrame={(f)=>{setFrame(f); window.__currentResultId=f.result_id;}} />
      <TimelineSlider fieldId={window.__selectedFieldId} indexName={timelineIndex} onFrameChange={(p)=>{setFrame(p); window.__currentResultId=p.result_id;}} />

    <div style={{height:'100%', width:'100%', position:'relative'}}>
      {/* Improved Overlay: KPI + Layer Selector + Weather + Legend */}
      <div className="absolute top-4 right-4 z-[9999] flex flex-col gap-3 pointer-events-auto">
        {/* KPI Panel */}
        <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-md rounded-2xl shadow-xl p-4 text-xs space-y-2">
          {selectedField && (
            <>
              <div className="font-semibold text-slate-900 dark:text-white text-sm">{selectedField.name}</div>
              <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-slate-700 dark:text-slate-300">
                <span>NDVI: {selectedField.latest_ndvi?.toFixed?.(2) ?? "N/A"}</span>
                {selectedField.delta_ndvi != null && <span>Δ {selectedField.delta_ndvi.toFixed(2)}</span>}
                <span>VSI: {selectedField.vsi?.toFixed?.(0) ?? "N/A"}</span>
                <span>WSI: {selectedField.wsi_lst!=null ? selectedField.wsi_lst.toFixed(2) : (selectedField.wsi?.toFixed?.(2) ?? "N/A")}</span>
                <span>FUI: {selectedField.fui?.toFixed?.(2) ?? "N/A"}</span>
                <span>GM: {selectedField.gm?.toFixed?.(2) ?? "N/A"}</span>
                <span className="col-span-2">Risk: {selectedField.risk_label}</span>
              </div>
            </>
          )}
        </div>

        {/* Layer Selector */}
        <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-md rounded-2xl shadow-lg p-3 text-xs space-y-2">
          <div className="font-semibold text-slate-900 dark:text-white text-sm">Layers</div>
          <select
            value={activeLayer}
            onChange={(e)=>setActiveLayer(e.target.value)}
            className="w-full px-2 py-1 rounded-md bg-white dark:bg-slate-900 border dark:border-slate-700"
          >
            <option value="ndvi">NDVI</option>
            <option value="heatmap">Heatmap</option>
            <option value="hotspots">Hotspots</option>
          </select>
          <label className="flex items-center gap-2 text-[11px] text-slate-700 dark:text-slate-300">
            <input type="checkbox" checked={showHeatmap} onChange={()=>setShowHeatmap(v=>!v)} />
            Show heatmap
          </label>
        </div>

        {/* Weather Widget */}
        <WeatherWidget weather={weather} />

        {/* Legend */}
        <div className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-md rounded-2xl shadow-lg p-3 text-xs space-y-2">
          <div className="font-semibold text-slate-900 dark:text-white text-sm">Legend</div>
          <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300"><div className="w-4 h-4 rounded bg-green-500"></div> High NDVI</div>
          <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300"><div className="w-4 h-4 rounded bg-yellow-500"></div> Medium NDVI</div>
          <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300"><div className="w-4 h-4 rounded bg-red-500"></div> Low NDVI</div>
        </div>
      </div>

      <MapContainer
        center={[24.7,46.6]}
        zoom={11}
        style={{height:"100%", width:"100%"}}
        whenCreated={(map)=>{ mapRef.current = map; }}
      >
        {indexLayers.map((idx)=> (layers[idx] && tileUrl(idx)) ? (
        <TileLayer key={idx} url={tileUrl(idx)} opacity={opacity} style={{mixBlendMode: layers.__blend||'normal'}} />
      ) : null))}

      <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        {/* NDVI Tiles */}
        {selectedField?.latest_ndvi_id && activeLayer==="ndvi" && (
          {indexLayers.map((idx)=> (layers[idx] && tileUrl(idx)) ? (
        <TileLayer key={idx} url={tileUrl(idx)} opacity={opacity} style={{mixBlendMode: layers.__blend||'normal'}} />
      ) : null))}

      <TileLayer
            ref={ndviLayerRef}
            url={`/api/satellite/ndvi/tiles?ndvi_id=${selectedField.latest_ndvi_id}&tenant_id=${selectedField.tenant_id || 1}`}
            opacity={0.9}
          />
        )}

        {/* Hotspots polygons */}
        {activeLayer==="hotspots" && hotspots.map((g, i)=>(
          <GeoJSON
            key={`hotspot-${i}`}
            data={g}
            pathOptions={{ color: "red", weight: 1, fillOpacity: 0.35 }}
          />
        ))}

        {/* Heatmap circles (lightweight) */}
        {activeLayer==="heatmap" && showHeatmap && heatmapPoints.map((p, i)=>(
          <GeoJSON
            key={`hm-${i}`}
            data={{"type":"Point","coordinates":[p.x, p.y]}}
            pointToLayer={(feature, latlng) => L.circleMarker(latlng, {
              radius: 6,
              fillOpacity: Math.min(0.6, 0.15 + (p.weight||0)*0.6),
              weight: 0
            })}
          />
        ))}

        {/* Fields boundaries */}
        {fields.map(f=>(
          f.boundary_geojson && (
            <GeoJSON
              key={f.id}
              data={f.boundary_geojson}
              pathOptions={{ color: riskColor(f.risk_level), weight: selectedId===f.id?3:2, fillOpacity: 0.05 }}
              onEachFeature={onEachField}
            />
          )
        ))}
      
      {window.__agroZones && <AgroZonesLayer geojson={window.__agroZones} />}
    {layers['soil_ph'] && <TileLayer url={soilUrl('ph')} opacity={opacity} />}
{layers['soil_ec_ds_m'] && <TileLayer url={soilUrl('ec_ds_m')} opacity={opacity} />}
{layers['soil_som_pct'] && <TileLayer url={soilUrl('som_pct')} opacity={opacity} />}
</MapContainer>
    </div>
      </>
  );
}
