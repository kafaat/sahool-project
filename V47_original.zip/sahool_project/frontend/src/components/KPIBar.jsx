import RiskBadge from "./RiskBadge.jsx";

function Card({title, value, sub, right}){
  return (
    <div className="bg-white dark:bg-slate-950 border dark:border-slate-800 rounded-2xl p-4 shadow-sm flex items-center justify-between">
      <div>
        <div className="text-xs font-semibold text-slate-500">{title}</div>
        <div className="text-2xl font-extrabold text-slate-900 mt-1">{value}</div>
        {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
      </div>
      {right}
    </div>
  );
}

export default function KPIBar({selectedField, totalFields=0, criticalAlerts=0, avgNdvi=null}){
  if(!selectedField){
    return (
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <Card title="NDVI" value="—"/>
        <Card title="VSI" value="—"/>
        <Card title="WSI" value="—"/>
        <Card title="FUI" value="—"/>
        <Card title="Risk" value="—"/>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
      <Card
        title="NDVI"
        value={selectedField.latest_ndvi?.toFixed?.(2) ?? "N/A"}
        sub={selectedField.delta_ndvi!=null ? `Δ ${selectedField.delta_ndvi.toFixed(2)}` : ""}
      />
      <Card title="VSI" value={selectedField.vsi?.toFixed?.(0) ?? "N/A"} sub="Vegetation Stress Index"/>
      <Card title="WSI" value={selectedField.wsi_lst!=null ? selectedField.wsi_lst.toFixed(2) : (selectedField.wsi?.toFixed?.(2) ?? "N/A")} sub="Water Stress"/>
      <Card title="FUI" value={selectedField.fui?.toFixed?.(2) ?? "N/A"} sub="Uniformity"/>
      <Card title="Risk Level" value={<RiskBadge level={selectedField.risk_level}/>} />
          <Card title="Total Fields" value={totalFields} />
          <Card title="Critical Alerts" value={criticalAlerts} />
          <Card title="Avg NDVI" value={avgNdvi!=null ? avgNdvi.toFixed(2) : '—'} />
    </div>
  );
}
