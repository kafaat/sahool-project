export default function AnomalyButton({ fieldId, indexName="ndvi" }){
  if(!fieldId) return null;
  return (
    <button
      onClick={async ()=>{
        const res = await fetch(`/api/analytics/anomalies/index/latest?field_id=${fieldId}&index_name=${indexName}`, {method:"POST"});
        if(res.ok) alert(`Anomaly task started for ${indexName}.`);
        else alert("Failed to start anomalies");
      }}
      className="px-3 py-2 rounded bg-orange-600 text-white"
    >
      Run {indexName.toUpperCase()} Anomalies
    </button>
  );
}
