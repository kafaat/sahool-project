import React, { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
const API=(p)=>`/api${p}`;

export default function WeatherDashboard({lat=30.0444, lon=31.2357}){
  const [live,setLive]=useState(null);
  const [history,setHistory]=useState(null);
  const [dailyForecast,setDailyForecast]=useState(null);
  const [alerts,setAlerts]=useState(null);
  const [plan,setPlan]=useState(null);
  const [irrig,setIrrig]=useState(null);
  const [crop,setCrop]=useState("wheat");
  const [stage,setStage]=useState("mid");
  const token=localStorage.getItem("token");
  const tenantId=localStorage.getItem("tenant")||"1";
  const headers=token?{Authorization:`Bearer ${token}`,"x-tenant-id":tenantId}:{ "x-tenant-id":tenantId };

  async function load(){
    const r=await fetch(API(`/weather/live?lat=${lat}&lon=${lon}`),{headers});
    const lj=await r.json(); setLive(lj);
    const end=new Date().toISOString().slice(0,10);
    const start=new Date(Date.now()-7*86400000).toISOString().slice(0,10);
    const h=await fetch(API(`/weather/history?lat=${lat}&lon=${lon}&start=${start}&end=${end}`),{headers});
    const d=await fetch(API(`/weather/daily?lat=${lat}&lon=${lon}&days=7`),{headers});
    setDailyForecast(await d.json());
    const al=await fetch(API(`/weather/alerts?lat=${lat}&lon=${lon}&crop=${crop||'wheat'}&stage=${stage||'mid'}`),{headers});
    setAlerts(await al.json());
    const pl=await fetch(API(`/weather/plan?lat=${lat}&lon=${lon}&crop=${crop||'wheat'}&stage=${stage||'mid'}&days=7`),{headers});
    setPlan(await pl.json());
    setHistory(await h.json());
    const ir=await fetch(API(`/weather/irrigation?lat=${lat}&lon=${lon}&crop=${crop}&stage=${stage}`),{headers});
    setIrrig(await ir.json());
  }
  useEffect(()=>{load();},[lat,lon]);

  const hist=history?.points||[];
  const chartData={ labels: hist.map(p=>p.date),
    datasets:[
      {label:"T2M (°C)", data: hist.map(p=>p.t2m)},
      {label:"Solar (MJ/m²)", data: hist.map(p=>p.solar)},
      {label:"Wind (m/s)", data: hist.map(p=>p.wind10m)},
    ]};

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-lg font-bold">Weather Dashboard</h2>

      {live?.summary && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
          <Card title="Temperature" value={`${live.summary.temperature.toFixed(1)} °C`} />
          <Card title="Humidity" value={`${live.summary.humidity.toFixed(0)} %`} />
          <Card title="Wind Speed" value={`${live.summary.wind_speed.toFixed(1)} m/s`} />
          <Card title="Solar Radiation" value={`${live.summary.solar_radiation.toFixed(0)} W/m²`} />
          <Card title="ET₀" value={`${live.summary.et0.toFixed(2)} mm/day`} />
          <Card title="Sunshine Hours" value={`${live.summary.sunshine_hours.toFixed(1)} h`} />
        </div>
      )}

      <div className="border rounded p-3 bg-white space-y-2">
        <div className="flex gap-2 items-center text-sm">
          <label>Crop:</label>
          <select className="border p-1" value={crop} onChange={e=>setCrop(e.target.value)}>
            <option value="wheat">Wheat</option><option value="corn">Corn</option><option value="rice">Rice</option>
            <option value="tomato">Tomato</option><option value="cotton">Cotton</option>
          </select>
          <label>Stage:</label>
          <select className="border p-1" value={stage} onChange={e=>setStage(e.target.value)}>
            <option value="initial">Initial</option><option value="mid">Mid</option><option value="end">End</option>
          </select>
          <button className="border px-2 py-1 rounded" onClick={load}>Update</button>
        </div>
        {irrig?.recommendation && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
            <Card title="ET₀" value={`${irrig.recommendation.et0_mm.toFixed(2)} mm/day`} />
            <Card title="Kc Need" value={`${irrig.recommendation.kc_need_mm.toFixed(2)} mm/day`} />
            <Card title="Net Irrigation" value={`${irrig.recommendation.net_irrigation_mm.toFixed(2)} mm/day`} />
            <Card title="m³/ha" value={`${irrig.recommendation.m3_per_ha.toFixed(1)} m³/ha`} />
            <Card title="Effective Rain" value={`${irrig.recommendation.effective_rain_mm.toFixed(2)} mm`} />
          </div>
        )}
      </div>

      
      
      {alerts?.alerts?.length>0 && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold mb-2">Agro Alerts</div>
          <ul className="list-disc ml-5">
            {alerts.alerts.map((a,i)=>(
              <li key={i}><b>{a.type}</b> — {a.level} — {a.message}</li>
            ))}
          </ul>
          {alerts.deficit && <div className="mt-2">7d Deficit: {alerts.deficit.deficit_mm?.toFixed?.(1)} mm</div>}
        </div>
      )}
      {plan?.plan?.length>0 && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold mb-2">Irrigation Plan</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {plan.plan.map((p,i)=>(
              <div key={i} className="border rounded p-2 bg-slate-50">
                <div className="font-semibold">{p.date}</div>
                <div>Net: {p.net_irrigation_mm?.toFixed?.(1)} mm</div>
                <div>Gross: {p.gross_irrigation_mm?.toFixed?.(1)} mm</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {dailyForecast?.points?.length>0 && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold mb-2">7-Day Forecast (with GDD)</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {dailyForecast.points.map((p,i)=>(
              <div key={i} className="border rounded p-2 bg-slate-50">
                <div className="font-semibold">{p.date}</div>
                <div>Tmin/Tmax: {p.tmin} / {p.tmax} °C</div>
                <div>Rain: {p.rain_sum} mm</div>
                <div>ET₀: {p.et0} mm</div>
                <div>GDD: {p.gdd?.toFixed?.(2)} (cum {p.gdd_cum?.toFixed?.(2)})</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {hist.length>0 && (
        <div className="border rounded p-3 bg-white">
          <Line data={chartData}/>
        </div>
      )}
    </div>
  );
}
function Card({title,value}){return (
  <div className="border rounded p-3 bg-slate-50">
    <div className="text-xs text-slate-500">{title}</div>
    <div className="font-semibold">{value}</div>
  </div>
);}
