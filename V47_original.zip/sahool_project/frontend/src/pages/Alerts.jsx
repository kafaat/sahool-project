import { useEffect, useState } from "react";

const severityColor = (s) => {
  switch(s){
    case "low": return "text-green-700";
    case "medium": return "text-orange-700";
    case "high": return "text-red-700";
    default: return "text-slate-700";
  }
};

export default function Alerts({tenantId, onGoField}){
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    (async ()=>{
      setLoading(true);
      const res = await fetch(`/api/alerts/dashboard?tenant_id=${tenantId}`);
      const data = await res.json();
      setAlerts(data.items || []);
      setLoading(false);
    })();
  },[tenantId]);

  return (
    <div className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold">التنبيهات</h2>
        <div className="text-xs text-slate-500">آخر 50 تنبيه</div>
      </div>

      {loading && <div>Loading...</div>}
      {!loading && alerts.length===0 && <div className="text-slate-500">لا يوجد تنبيهات.</div>}

      <div className="space-y-2">
        {alerts.map(a => (
          <div key={a.id} className="bg-white border rounded p-3 flex items-start justify-between">
            <div>
              <div className="font-semibold">
                حقل #{a.field_id} — {a.type}
              </div>
              <div className={`text-sm ${severityColor(a.severity)}`}>
                الخطورة: {a.severity}
              </div>
              <div className="text-sm text-slate-700 mt-1">{a.message}</div>
              <div className="text-xs text-slate-500 mt-1">{a.created_at?.slice(0,19).replace("T"," ")}</div>
            </div>
            <button
              onClick={()=>onGoField?.(a.field_id)}
              className="text-blue-600 text-sm hover:underline"
            >
              عرض الحقل
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
