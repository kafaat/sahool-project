import { useEffect, useMemo, useState } from "react";
import { fetchWeather } from "../api.js";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale,
  PointElement, LineElement, Tooltip, Legend
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

export default function Weather({ fieldId, tenantId=1 }){
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(()=>{
    if(!fieldId) return;
    let alive=true;
    (async ()=>{
      setLoading(true); setError("");
      try{
        const res = await fetchWeather(fieldId, tenantId);
        if(alive) setData(res.weather);
      }catch(e){
        if(alive) setError(e.message || "Failed to load weather");
      }finally{
        if(alive) setLoading(false);
      }
    })();
    return ()=>{alive=false};
  },[fieldId, tenantId]);

  const current = data?.current || {};
  const daily = data?.daily || [];

  const chartData = useMemo(()=>{
    return {
      labels: daily.map(d=>d.date),
      datasets: [
        { label:"Temp Max (°C)", data: daily.map(d=>d.temp_max_c) },
        { label:"Temp Min (°C)", data: daily.map(d=>d.temp_min_c) }
      ]
    };
  },[daily]);

  const rainData = useMemo(()=>({
    labels: daily.map(d=>d.date),
    datasets: [{ label:"Rain (mm)", data: daily.map(d=>d.precip_sum_mm) }]
  }),[daily]);

  return (
    <div className="space-y-4">
      {!fieldId && <div className="text-sm text-slate-500">اختر حقلًا لعرض الطقس.</div>}
      {loading && <div className="text-sm text-slate-600">Loading weather…</div>}
      {error && <div className="text-sm text-red-600">{error}</div>}
      {data && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Stat label="Temperature" value={`${current.temperature_c ?? "—"} °C`} />
            <Stat label="Humidity" value={`${current.humidity_pct ?? "—"} %`} />
            <Stat label="Wind" value={`${current.wind_kmh ?? "—"} km/h`} />
            <Stat label="Precip" value={`${current.precip_mm ?? "—"} mm`} />
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border dark:border-slate-800">
            <div className="font-semibold mb-2">7‑Day Temperature Forecast</div>
            <Line data={chartData} options={{responsive:true}} />
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border dark:border-slate-800">
            <div className="font-semibold mb-2">7‑Day Rain Forecast</div>
            <Line data={rainData} options={{responsive:true}} />
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border dark:border-slate-800 overflow-auto">
            <div className="font-semibold mb-2">Daily Details</div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-1">Date</th>
                  <th>Min</th>
                  <th>Max</th>
                  <th>Rain</th>
                  <th>Wind</th>
                  <th>UV</th>
                </tr>
              </thead>
              <tbody>
                {daily.map((d, i)=>(
                  <tr key={i} className="border-t dark:border-slate-800">
                    <td className="py-1">{d.date}</td>
                    <td>{d.temp_min_c ?? "—"}</td>
                    <td>{d.temp_max_c ?? "—"}</td>
                    <td>{d.precip_sum_mm ?? "—"}</td>
                    <td>{d.wind_max_kmh ?? "—"}</td>
                    <td>{d.uv_max ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function Stat({label, value}){
  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border dark:border-slate-800">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-lg font-bold text-slate-900 dark:text-white">{value}</div>
    </div>
  );
}
