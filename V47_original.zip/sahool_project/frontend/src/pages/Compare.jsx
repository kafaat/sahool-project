import { useEffect, useState } from "react";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale, LinearScale,
  PointElement, LineElement,
  Tooltip, Legend
} from "chart.js";
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

export default function Compare({tenantId, fields}){
  const [selected, setSelected] = useState([]);
  const [series, setSeries] = useState({});
  const [loading, setLoading] = useState(false);

  const toggle = (id)=>{
    setSelected(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [prev, id]);
  };

  useEffect(()=>{
    if(selected.length===0){ setSeries({}); return; }
    (async ()=>{
      setLoading(true);
      const out={};
      for(const id of selected){
        try{
          const res = await fetch(`/api/satellite/ndvi/timeline?field_id=${id}&tenant_id=${tenantId}`);
          const tl = await res.json();
          out[id]=tl.items || [];
        }catch{ out[id]=[]; }
      }
      setSeries(out);
      setLoading(false);
    })();
  },[selected, tenantId]);

  const allDates = Array.from(new Set(
    Object.values(series).flat().map(p => (p.processed_at||p.date||"").slice(0,10))
  )).sort();

  const datasets = selected.map((id, idx)=>({
    label: fields.find(f=>f.id===id)?.name || `Field ${id}`,
    data: allDates.map(d=>{
      const pt = (series[id]||[]).find(x=> (x.processed_at||x.date||"").slice(0,10)===d);
      return pt ? pt.mean_ndvi : null;
    }),
    spanGaps: true,
    tension: 0.35
  }));

  const data = { labels: allDates, datasets };
  const options = {
    responsive:true,
    plugins:{ legend:{ position:"bottom" } },
    scales:{ y:{ min:0, max:1 } }
  };

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-lg font-bold">مقارنة الحقول</h2>
      <div className="text-sm text-slate-600">اختر أكثر من حقل للمقارنة:</div>

      <div className="grid grid-cols-2 gap-2">
        {fields.map(f=>(
          <label key={f.id} className="bg-white border rounded p-2 flex items-center gap-2 text-sm">
            <input type="checkbox" checked={selected.includes(f.id)} onChange={()=>toggle(f.id)} />
            <span>{f.name}</span>
          </label>
        ))}
      </div>

      {loading && <div>Loading</div>}
      {!loading && selected.length>0 && (
        <div className="bg-white border rounded p-3">
          <Line data={data} options={options}/>
        </div>
      )}
      {!loading && selected.length===0 && (
        <div className="text-slate-500 text-sm">لم يتم اختيار حقول بعد.</div>
      )}
    </div>
  );
}
