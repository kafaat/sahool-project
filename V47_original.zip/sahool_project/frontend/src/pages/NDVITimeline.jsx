import React, {useState} from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import { Line } from "react-chartjs-2";
import { API, headers } from "../services/api";

export default function NDVITimeline(){
  const [fieldId,setFieldId]=useState("");
  const [days,setDays]=useState(365);
  const [ts,setTs]=useState(null);
  const [frameIdx,setFrameIdx]=useState(0);
  const [err,setErr]=useState(null);

  async function load(){
    setErr(null);
    if(!fieldId) return;
    const r=await fetch(API(`/ndvi/timeseries?field_id=${fieldId}&days=${days}`),{headers});
    if(!r.ok){ setErr(await r.text()); return;}
    const j=await r.json();
    setTs(j);
    setFrameIdx(0);
  }

  const frames = ts?.points || [];
  const current = frames[frameIdx];

  const chartData = ts ? {
    labels: frames.map(p=>p.date),
    datasets: [{label:"NDVI Mean", data: frames.map(p=>p.ndvi_mean)}]
  } : null;

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-xl font-bold">NDVI Timeline</h2>
      <div className="flex flex-wrap gap-2 items-end">
        <div>
          <label className="block text-sm">Field ID</label>
          <input className="border p-2 rounded w-32" value={fieldId} onChange={e=>setFieldId(e.target.value)} placeholder="3"/>
        </div>
        <div>
          <label className="block text-sm">Days</label>
          <input type="number" className="border p-2 rounded w-32" value={days} onChange={e=>setDays(e.target.value)} />
        </div>
        <button onClick={load} className="bg-black text-white px-4 py-2 rounded">Load</button>
      </div>

      {err && <div className="text-red-600 text-sm">{err}</div>}

      {chartData && (
        <div className="border rounded bg-white p-3">
          <Line data={chartData}/>
        </div>
      )}

      {current && (
        <div className="border rounded bg-white p-3 space-y-2">
          <div className="font-semibold">Frame: {current.date}</div>
          <input type="range" min="0" max={frames.length-1} value={frameIdx}
            onChange={e=>setFrameIdx(parseInt(e.target.value))} className="w-full"/>
          <MapContainer center={[0,0]} zoom={13} style={{height:360}}>
            <TileLayer url={API(`/satellite/ndvi/tiles/${current.result_id}/{z}/{x}/{y}.png`)} />
          </MapContainer>
        </div>
      )}
    </div>
  );
}
