import React, { useEffect, useState } from "react";
const API = (p)=>`/api${p}`;

export default function AdminConsole(){
  const [tenantId,setTenantId]=useState(localStorage.getItem("tenant")||"1");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [otp,setOtp]=useState("");
  const [token,setToken]=useState(localStorage.getItem("token")||"");
  const [refresh,setRefresh]=useState(localStorage.getItem("refresh")||"");
  const [tab,setTab]=useState("users");

  const [users,setUsers]=useState([]);
  const [tenants,setTenants]=useState([]);
  const [apikeys,setApikeys]=useState([]);
  const [audit,setAudit]=useState([]);
  const [usage,setUsage]=useState(null);

  const [newUser,setNewUser]=useState({email:"",password:"",roles:"user"});
  const [newTenant,setNewTenant]=useState({name:""});
  const [newKeyName,setNewKeyName]=useState("device");
  const [createdKey,setCreatedKey]=useState("");

  const headers = token ? {Authorization:`Bearer ${token}`,"x-tenant-id":tenantId} : {"x-tenant-id":tenantId};

  async function login(){
    const r=await fetch(API(`/auth/login?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}&tenant_id=${tenantId}&otp_code=${otp}`),{method:"POST"});
    const j=await r.json();
    setToken(j.access_token); setRefresh(j.refresh_token);
    localStorage.setItem("token", j.access_token);
    localStorage.setItem("refresh", j.refresh_token);
    localStorage.setItem("tenant", tenantId);
  }
  async function refreshToken(){
    const r=await fetch(API(`/auth/refresh?refresh_token=${refresh}`),{method:"POST"});
    const j=await r.json();
    setToken(j.access_token); setRefresh(j.refresh_token);
    localStorage.setItem("token", j.access_token);
    localStorage.setItem("refresh", j.refresh_token);
  }

  async function load(){
    if(tab==="users"){
      const r=await fetch(API("/admin/users"),{headers}); setUsers((await r.json()).items||[]);
    }
    if(tab==="tenants"){
      const r=await fetch(API("/admin/tenants"),{headers}); setTenants((await r.json()).items||[]);
    }
    if(tab==="apikeys"){
      const r=await fetch(API("/admin/apikeys"),{headers}); setApikeys((await r.json()).items||[]);
    }
    if(tab==="audit"){
      const r=await fetch(API("/admin/audit"),{headers}); setAudit((await r.json()).items||[]);
    }
    if(tab==="usage"){
      const r=await fetch(API("/admin/usage/sentinel"),{headers}); setUsage(await r.json());
    }
  }

  useEffect(()=>{ if(token) load(); },[tab,token,tenantId]);

  if(!token){
    return (
      <div className="p-4 space-y-2">
        <h2 className="text-lg font-bold">Admin Panel (Phase18)</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <input className="border p-2" placeholder="Tenant ID" value={tenantId} onChange={e=>setTenantId(e.target.value)} />
          <input className="border p-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="border p-2" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          <input className="border p-2" placeholder="OTP (TOTP)" value={otp} onChange={e=>setOtp(e.target.value)} />
        </div>
        <button className="px-3 py-2 bg-blue-600 text-white rounded" onClick={login}>Login</button>
      </div>
    )
  }

  return (
    <div className="p-4 space-y-3">
      <div className="flex flex-wrap gap-2 text-sm">
        {["users","tenants","apikeys","audit","usage"].map(t=>(
          <button key={t} onClick={()=>setTab(t)}
            className={`px-3 py-1 rounded border ${tab===t?"bg-slate-200":""}`}>{t}</button>
        ))}
        <button className="px-3 py-1 rounded border" onClick={refreshToken}>Refresh</button>
        <button className="px-3 py-1 rounded border" onClick={()=>{
          setToken(""); setRefresh(""); localStorage.clear();
        }}>Logout</button>
      </div>

      {tab==="users" && (
        <div className="space-y-3">
          <div className="border p-3 rounded bg-slate-50 grid grid-cols-1 md:grid-cols-4 gap-2">
            <input className="border p-2" placeholder="Email" value={newUser.email} onChange={e=>setNewUser({...newUser,email:e.target.value})}/>
            <input className="border p-2" placeholder="Password" type="password" value={newUser.password} onChange={e=>setNewUser({...newUser,password:e.target.value})}/>
            <input className="border p-2" placeholder="Roles" value={newUser.roles} onChange={e=>setNewUser({...newUser,roles:e.target.value})}/>
            <button className="px-3 py-2 bg-green-600 text-white rounded" onClick={async()=>{
              await fetch(API(`/auth/users?tenant_id=${tenantId}&email=${encodeURIComponent(newUser.email)}&password=${encodeURIComponent(newUser.password)}&roles=${encodeURIComponent(newUser.roles)}`),{method:"POST",headers});
              setNewUser({email:"",password:"",roles:"user"}); load();
            }}>Create User</button>
          </div>

          <table className="w-full text-sm border">
            <thead><tr className="bg-slate-50">
              <th className="p-2 border">ID</th><th className="p-2 border">Email</th>
              <th className="p-2 border">Roles</th><th className="p-2 border">Active</th><th className="p-2 border">Actions</th>
            </tr></thead>
            <tbody>
              {users.map(u=>(
                <tr key={u.id}>
                  <td className="p-2 border">{u.id}</td>
                  <td className="p-2 border">{u.email}</td>
                  <td className="p-2 border">{u.roles}</td>
                  <td className="p-2 border">{String(u.is_active)}</td>
                  <td className="p-2 border space-x-2">
                    <button className="px-2 py-1 border rounded" onClick={async()=>{
                      await fetch(API(`/admin/users/${u.id}/toggle`),{method:"POST",headers});
                      load();
                    }}>Toggle</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab==="tenants" && (
        <div className="space-y-3">
          <div className="border p-3 rounded bg-slate-50 grid grid-cols-1 md:grid-cols-3 gap-2">
            <input className="border p-2" placeholder="Tenant name" value={newTenant.name} onChange={e=>setNewTenant({name:e.target.value})}/>
            <button className="px-3 py-2 bg-green-600 text-white rounded" onClick={async()=>{
              await fetch(API(`/auth/tenants?name=${encodeURIComponent(newTenant.name)}`),{method:"POST",headers});
              setNewTenant({name:""}); load();
            }}>Create Tenant</button>
          </div>

          <table className="w-full text-sm border">
            <thead><tr className="bg-slate-50">
              <th className="p-2 border">ID</th><th className="p-2 border">Name</th>
              <th className="p-2 border">Active</th><th className="p-2 border">Actions</th>
            </tr></thead>
            <tbody>
              {tenants.map(t=>(
                <tr key={t.id}>
                  <td className="p-2 border">{t.id}</td>
                  <td className="p-2 border">{t.name}</td>
                  <td className="p-2 border">{String(t.is_active)}</td>
                  <td className="p-2 border">
                    <button className="px-2 py-1 border rounded" onClick={async()=>{
                      await fetch(API(`/admin/tenants/${t.id}/toggle`),{method:"POST",headers});
                      load();
                    }}>Toggle</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab==="apikeys" && (
        <div className="space-y-3">
          <div className="border p-3 rounded bg-slate-50 grid grid-cols-1 md:grid-cols-3 gap-2">
            <input className="border p-2" placeholder="Key name" value={newKeyName} onChange={e=>setNewKeyName(e.target.value)}/>
            <button className="px-3 py-2 bg-green-600 text-white rounded" onClick={async()=>{
              const r=await fetch(API(`/auth/apikeys?name=${encodeURIComponent(newKeyName)}`),{method:"POST",headers});
              const j=await r.json(); setCreatedKey(j.api_key); load();
            }}>Create API Key</button>
            {createdKey && <div className="text-xs break-all p-2 bg-white border rounded">NEW KEY: {createdKey}</div>}
          </div>

          <table className="w-full text-sm border">
            <thead><tr className="bg-slate-50">
              <th className="p-2 border">ID</th><th className="p-2 border">Name</th>
              <th className="p-2 border">Created</th><th className="p-2 border">Last Used</th>
            </tr></thead>
            <tbody>
              {apikeys.map(k=>(
                <tr key={k.id}>
                  <td className="p-2 border">{k.id}</td>
                  <td className="p-2 border">{k.name}</td>
                  <td className="p-2 border">{String(k.created_at)}</td>
                  <td className="p-2 border">{String(k.last_used_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab==="audit" && (
        <table className="w-full text-sm border">
          <thead><tr className="bg-slate-50">
            <th className="p-2 border">ID</th><th className="p-2 border">Event</th>
            <th className="p-2 border">User</th><th className="p-2 border">Meta</th><th className="p-2 border">At</th>
          </tr></thead>
          <tbody>
            {audit.map(a=>(
              <tr key={a.id}>
                <td className="p-2 border">{a.id}</td>
                <td className="p-2 border">{a.event}</td>
                <td className="p-2 border">{a.user_id}</td>
                <td className="p-2 border">{JSON.stringify(a.meta)}</td>
                <td className="p-2 border">{String(a.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {tab==="usage" && usage && (
        <div className="space-y-2">
          <div className="text-sm border p-3 rounded bg-slate-50">
            <div>Sentinel used today: <b>{usage.used_today}</b> / {usage.limit}</div>
            <div className="w-full bg-white border rounded h-3 mt-2">
              <div className="h-3 bg-blue-500" style={{width:`${Math.min(100, (usage.used_today/usage.limit)*100)}%`}}></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
