    import { useEffect, useState } from "react";

    import { fetchWeather } from "../api.js";

export default function Reports({tenantId, fieldId}){
      const [report, setReport] = useState(null);
      const [weather, setWeather] = useState(null);
      const [loading, setLoading] = useState(true);

      useEffect(()=>{
  if(!fieldId) return;
  (async ()=>{
    try{
      const w = await fetchWeather(fieldId, tenantId);
      setWeather(w.weather);
    }catch{ setWeather(null); }
  })();
},[tenantId, fieldId]);

      useEffect(()=>{
        if(!fieldId) return;
        (async ()=>{
          setLoading(true);
          const res = await fetch(`/api/reports/weekly?field_id=${fieldId}&tenant_id=${tenantId}`);
          const data = await res.json();
          setReport(data);
          setLoading(false);
        })();
      },[tenantId, fieldId]);

      if(!fieldId){
        return <div className="p-4 text-slate-500">اختر حقلًا من الخريطة أولاً.</div>;
      }

      return (
        <div className="p-4 space-y-3">
          <h2 className="text-lg font-bold">التقرير الأسبوعي</h2>
          {loading && <div>Loading</div>}
          {!loading && !report && <div className="text-slate-500">لا يوجد تقرير.</div>}
          {weather?.daily?.length>0 && (
  <div className="bg-white border rounded p-4 space-y-2">
    <div className="font-semibold">Weather Forecast (7 أيام)</div>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
      {weather.daily.map((d)=>(
        <div key={d.date} className="border rounded p-2">
          <div className="font-semibold">{d.date}</div>
          <div>🌡 {d.temp_min_c}–{d.temp_max_c}°C</div>
          <div>☔ {d.precip_sum_mm} mm</div>
          <div>🌬 {d.wind_max_kmh} km/h</div>
        </div>
      ))}
    </div>
  </div>
)}

{!loading && report && (
            <div className="bg-white border rounded p-4 space-y-2">
              <div className="font-semibold">الحالة العامة</div>
              <pre className="text-xs bg-slate-50 p-2 rounded overflow-auto">
{JSON.stringify(report, null, 2)}
              </pre>
            </div>
          )}
        </div>
      );
    }
