import React, {useEffect, useState} from "react";
const API=(p)=>`/api${p}`;

export default function SoilDashboard(){
  const token=localStorage.getItem("token");
  const tenantId=localStorage.getItem("tenant")||"1";
  const headers = token ? {Authorization:`Bearer ${token}`,"x-tenant-id":tenantId,"Content-Type":"application/json"} : {"x-tenant-id":tenantId,"Content-Type":"application/json"};
  const [items,setItems]=useState([]);

  const [suit,setSuit]=useState(null);
  const [fertility,setFertility]=useState(null);
  const [soilAnalysis,setSoilAnalysis]=useState(null);
  const [soilRec,setSoilRec]=useState(null);
  
  
  async function loadAnalysis(fieldId){
    if(!fieldId) return;
    const r=await fetch(API(`/soil/analysis?field_id=${fieldId}`),{headers});
    if(r.ok) setSoilAnalysis(await r.json());
    const rr=await fetch(API(`/soil/recommendations?field_id=${fieldId}`),{headers});
    if(rr.ok) setSoilRec(await rr.json());
  }

async function loadFertility(fieldId){
    if(!fieldId) return;
    const r=await fetch(API(`/soil/fertility?field_id=${fieldId}`),{headers});
    if(r.ok) setFertility(await r.json());
  }

async function loadSuit(fieldId){
    if(!fieldId) return;
    const r=await fetch(API(`/soil/profile-depth?field_id=${fieldId}&depth=${form.depth||'surface'}`),{headers});
    if(r.ok) setSuit(await r.json());
  }

  const [form,setForm]=useState({field_id:"", sand_pct:"", silt_pct:"", clay_pct:"", ph:"", ec_ds_m:"", som_pct:"", n_ppm:"", p_ppm:"", k_ppm:""});

  async function load(){
    const r=await fetch(API("/soil"),{headers});
    const j=await r.json(); setItems(j.items||[]);
  }
  async function save(){
    const body={...form};
    Object.keys(body).forEach(k=>{ if(body[k]==="") delete body[k]; else if(k!=="field_id") body[k]=Number(body[k]); });
    body.field_id=Number(form.field_id);
    await fetch(API("/soil"),{method:"POST",headers,body:JSON.stringify(body)});
    setForm({field_id:"", sand_pct:"", silt_pct:"", clay_pct:"", ph:"", ec_ds_m:"", som_pct:"", n_ppm:"", p_ppm:"", k_ppm:""});
    load();
  }
  useEffect(()=>{load();},[]);
useEffect(()=>{ if(form.field_id) { loadSuit(form.field_id); loadFertility(form.field_id); loadAnalysis(form.field_id);} },[form.field_id]);

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-lg font-bold">Soil Dashboard</h2>
      <div className="border p-3 rounded bg-slate-50 grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
        <input className="border p-2" placeholder="Field ID" value={form.field_id} onChange={e=>setForm({...form,field_id:e.target.value})}/>
        <input className="border p-2" placeholder="Sand %" value={form.sand_pct} onChange={e=>setForm({...form,sand_pct:e.target.value})}/>
        <input className="border p-2" placeholder="Silt %" value={form.silt_pct} onChange={e=>setForm({...form,silt_pct:e.target.value})}/>
        <input className="border p-2" placeholder="Clay %" value={form.clay_pct} onChange={e=>setForm({...form,clay_pct:e.target.value})}/>
        <input className="border p-2" placeholder="pH" value={form.ph} onChange={e=>setForm({...form,ph:e.target.value})}/>
        <input className="border p-2" placeholder="EC dS/m" value={form.ec_ds_m} onChange={e=>setForm({...form,ec_ds_m:e.target.value})}/>
        <input className="border p-2" placeholder="SOM %" value={form.som_pct} onChange={e=>setForm({...form,som_pct:e.target.value})}/>
        <input className="border p-2" placeholder="N ppm" value={form.n_ppm} onChange={e=>setForm({...form,n_ppm:e.target.value})}/>
        <input className="border p-2" placeholder="P ppm" value={form.p_ppm} onChange={e=>setForm({...form,p_ppm:e.target.value})}/>
        <input className="border p-2" placeholder="K ppm" value={form.k_ppm} onChange={e=>setForm({...form,k_ppm:e.target.value})}/>
        <button className="px-3 py-2 bg-green-600 text-white rounded col-span-2 md:col-span-4" onClick={save}>Save Profile</button>
      </div>

      
      {suit && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold">Suitability Score: {suit.score}</div>
          <div>Best crops: {(suit.best_crops||[]).join(", ")}</div>
          {(suit.warnings||[]).length>0 && <div className="text-orange-600">Warnings: {(suit.warnings||[]).join(", ")}</div>}
        </div>
      )}


      
      {soilAnalysis && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold mb-1">Soil Analysis</div>
          <div>Texture: {soilAnalysis.texture_class}</div>
          <div>AWC: {soilAnalysis.awc_mm_per_m} mm/m</div>
          <div>Salinity: {soilAnalysis.salinity_class}</div>
          <div>Infiltration risk: {soilAnalysis.infiltration_risk}</div>
          <div>Health score: {soilAnalysis.soil_health_score}</div>
        </div>
      )}
      {soilRec && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold mb-1">Recommendations</div>
          <div>Available water: {soilRec.irrigation_from_soil?.available_water_mm} mm</div>
          <div>Suggested frequency: {soilRec.irrigation_from_soil?.suggested_frequency_days} days</div>
        </div>
      )}

      {fertility && (
        <div className="border rounded p-3 bg-white text-sm">
          <div className="font-semibold">Fertility Index: {fertility.fertility_index}</div>
          {(fertility.fertilizer_hints||[]).length>0 && (
            <ul className="list-disc ml-5">
              {fertility.fertilizer_hints.map((h,i)=><li key={i}>{h}</li>)}
            </ul>
          )}
        </div>
      )}

<table className="w-full text-sm border">
        <thead><tr className="bg-slate-50">
          <th className="p-2 border">ID</th><th className="p-2 border">Field</th>
          <th className="p-2 border">Texture (S/S/C)</th><th className="p-2 border">pH</th>
          <th className="p-2 border">EC</th><th className="p-2 border">SOM</th>
          <th className="p-2 border">N/P/K</th>
        </tr></thead>
        <tbody>
          {items.map(it=>(
            <tr key={it.id}>
              <td className="p-2 border">{it.id}</td>
              <td className="p-2 border">{it.field_id}</td>
              <td className="p-2 border">{it.sand_pct}/{it.silt_pct}/{it.clay_pct}</td>
              <td className="p-2 border">{it.ph}</td>
              <td className="p-2 border">{it.ec_ds_m}</td>
              <td className="p-2 border">{it.som_pct}</td>
              <td className="p-2 border">{it.n_ppm}/{it.p_ppm}/{it.k_ppm}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
