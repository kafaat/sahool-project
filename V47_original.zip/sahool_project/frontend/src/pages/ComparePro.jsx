import { useEffect, useState } from "react";
import CompareImage from "react-compare-image";
import { listNdviResults } from "../api.js";

const INDICES=["ndvi","ndre","gndvi","savi","evi","ndwi"];

export default function ComparePro({ fieldId }){
  const [rows, setRows] = useState([]);
  const [indexName, setIndexName] = useState("ndvi");
  const [oldId, setOldId] = useState(null);
  const [newId, setNewId] = useState(null);

  useEffect(()=>{
    if(!fieldId) return;
    listNdviResults(fieldId).then(r=>{
      setRows(r);
      setNewId(r?.[0]?.id || null);
      setOldId(r?.[1]?.id || null);
    });
  },[fieldId]);

  if(!fieldId) return <div className="text-sm text-slate-500">اختر حقلًا أولاً.</div>;
  if(rows.length<2) return <div className="text-sm text-slate-500">احتاج نتيجتين NDVI على الأقل.</div>;

  const oldUrl = `/api/satellite/${indexName}/png/${oldId}`;
  const newUrl = `/api/satellite/${indexName}/png/${newId}`;

  return (
    <div className="space-y-3">
      <div className="mb-2">
  <label className="text-xs text-slate-500">Index</label>
  <select value={indexName} onChange={e=>setIndexName(e.target.value)} className="w-full p-2 rounded border dark:border-slate-800">
    {INDICES.map(i=><option key={i} value={i}>{i.toUpperCase()}</option>)}
  </select>
</div>
<div className="grid grid-cols-2 gap-2">
        <select value={oldId||""} onChange={e=>setOldId(Number(e.target.value))} className="p-2 rounded border dark:border-slate-800">
          {rows.map(r=><option key={r.id} value={r.id}>Old #{r.id} — {r.processed_at?.slice(0,10)}</option>)}
        </select>
        <select value={newId||""} onChange={e=>setNewId(Number(e.target.value))} className="p-2 rounded border dark:border-slate-800">
          {rows.map(r=><option key={r.id} value={r.id}>New #{r.id} — {r.processed_at?.slice(0,10)}</option>)}
        </select>
      </div>

      <div className="rounded-xl overflow-hidden border dark:border-slate-800 bg-white dark:bg-slate-900">
        <CompareImage leftImage={oldUrl} rightImage={newUrl} sliderLineWidth={3} />
      </div>

      <button
        onClick={async ()=>{
          await fetch(`/api/compare/delta/${indexName}?field_id=${fieldId}&old_result_id=${oldId}&new_result_id=${newId}`, {method:"POST"});
          alert("Delta task started. It will appear in timeline soon.");
        }}
        className="px-3 py-2 rounded bg-slate-900 text-white dark:bg-white dark:text-slate-900"
      >
        Generate Delta (Change Detection)
      </button>
    </div>
  );
}
