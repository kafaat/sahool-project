import { useEffect, useState } from "react";
import TimelineChart from "../components/TimelineChart.jsx";
import { fetchTimeline, fetchCloudTimeline } from "../api.js";

export default function Timeline({ fieldId, tenantId=1 }){
  const [timeline, setTimeline] = useState(null);
  const [cloud, setCloud] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(()=>{
    if(!fieldId) return;
    let alive=true;
    (async ()=>{
      setLoading(true); setError("");
      try{
        const res = await fetchTimeline(fieldId, tenantId);
        const cl = await fetchCloudTimeline(fieldId);
        if(alive) setCloud(cl.items);
        if(alive) setTimeline(res);
      }catch(e){
        if(alive) setError(e.message || "Failed to load timeline");
      }finally{
        if(alive) setLoading(false);
      }
    })();
    return ()=>{alive=false};
  },[fieldId, tenantId]);

  return (
    <div className="space-y-3">
      {!fieldId && <div className="text-sm text-slate-500">اختر حقلًا لعرض السجل الزمني للمؤشرات.</div>}
      {loading && <div className="text-sm text-slate-600">Loading timeline…</div>}
      {error && <div className="text-sm text-red-600">{error}</div>}
      {timeline && (
        <>
          <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border dark:border-slate-800">
            <TimelineChart timeline={timeline} />
            {cloud && (
              <div className="mt-3 text-xs text-slate-600 dark:text-slate-300">
                Cloud %: {cloud.map((c,i)=><span key={i} className="mr-2">{(c.cloud_pct??0).toFixed?.(1)}%</span>)}
              </div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-xl p-3 border dark:border-slate-800 overflow-auto">
            <div className="font-semibold mb-2">History</div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-500">
                  <th className="py-1">Date</th>
                  <th>Mean NDVI</th>
                  <th>Min</th>
                  <th>Max</th>
                  <th>Cloud %</th>
                </tr>
              </thead>
              <tbody>
                {timeline.items.map((it, i)=>(
                  <tr key={i} className="border-t dark:border-slate-800">
                    <td className="py-1">{(it.processed_at || it.date || "").slice(0,10)}</td>
                    <td>{it.mean_ndvi?.toFixed?.(3) ?? it.mean_ndvi}</td>
                    <td>{it.min_ndvi?.toFixed?.(3) ?? it.min_ndvi}</td>
                    <td>{it.max_ndvi?.toFixed?.(3) ?? it.max_ndvi}</td>
                    <td>{it.cloud_pct ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
