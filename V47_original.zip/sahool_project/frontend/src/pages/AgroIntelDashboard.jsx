import React, { useEffect, useState } from "react";
import { API, headers } from "../services/api";

export default function AgroIntelDashboard(){
  const [fieldId,setFieldId]=useState("");
  const [crop,setCrop]=useState("wheat");
  const [stage,setStage]=useState("mid");
  const [data,setData]=useState(null);
  const [err,setErr]=useState(null);

  async function load(){
    setErr(null);
    if(!fieldId) return;
    const r=await fetch(API(`/agro/ai?field_id=${fieldId}&crop=${crop}&stage=${stage}`),{headers});
    if(!r.ok){ setErr(await r.text()); return; }
    const j=await r.json(); setData(j); window.__agroZones=j.zones_geojson;
  }

  return (
    <div className="p-4 space-y-3">
      <h2 className="text-xl font-bold">Agro Intelligence (AI)</h2>

      <div className="flex flex-wrap gap-2 items-end">
        <div>
          <label className="block text-sm">Field ID</label>
          <input className="border p-2 rounded w-32" value={fieldId} onChange={e=>setFieldId(e.target.value)} placeholder="3"/>
        </div>
        <div>
          <label className="block text-sm">Crop</label>
          <select className="border p-2 rounded" value={crop} onChange={e=>setCrop(e.target.value)}>
            <option>wheat</option><option>corn</option><option>tomato</option><option>cotton</option><option>rice</option>
          </select>
        </div>
        <div>
          <label className="block text-sm">Stage</label>
          <select className="border p-2 rounded" value={stage} onChange={e=>setStage(e.target.value)}>
            <option value="ini">ini</option>
            <option value="mid">mid</option>
            <option value="end">end</option>
          </select>
        </div>
        <button onClick={load} className="bg-black text-white px-4 py-2 rounded">Run</button>

        <button onClick={()=>window.open(API(`/agro/report.pdf?field_id=${fieldId}&crop=${crop}&stage=${stage}`))} className="border px-3 py-2 rounded">Download Zones PDF</button>
        <button onClick={()=>window.open(API(`/reports/agro.pdf?field_id=${fieldId}&crop=${crop}&stage=${stage}`))} className="border px-3 py-2 rounded">Agro Report PDF</button>

      </div>

      {err && <div className="text-red-600 text-sm">{err}</div>}

      {data && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="border rounded p-3 bg-white text-sm space-y-1">
            <div className="font-semibold">Field Summary</div>
            <div>Overall health: {data.field_summary?.overall_health?.toFixed?.(1)}</div>
            <div>Salinity risk: {data.field_summary?.salinity_risk}</div>
            <div>7d deficit: {data.field_summary?.water_deficit_mm_7d?.toFixed?.(1)} mm</div>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-1">
            <div className="font-semibold">NDVI Stress Fractions</div>
            <div>High: {(data.ndvi_stress?.high*100).toFixed(1)}%</div>
            <div>Moderate: {(data.ndvi_stress?.moderate*100).toFixed(1)}%</div>
            <div>Low: {(data.ndvi_stress?.low*100).toFixed(1)}%</div>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-2 md:col-span-2">
            <div className="font-semibold">Zones Irrigation</div>
            {(data.zones||[]).map((z,i)=>(
              <div key={i} className="border rounded p-2 bg-slate-50">
                <div className="font-semibold capitalize">{z.level} — {(z.area_fraction*100).toFixed(1)}%</div>
                <div>Multiplier: {z.irrigation_multiplier}</div>
                <div>Suggested frequency: {z.suggested_frequency_days} days</div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-1 mt-1">
                  {(z.plan||[]).slice(0,3).map((p,ix)=>(
                    <div key={ix} className="border rounded p-2 bg-white">
                      <div>{p.date}</div>
                      <div>Net: {p.net_zone_mm?.toFixed?.(1)} mm</div>
                      <div>Gross: {p.gross_zone_mm?.toFixed?.(1)} mm</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>


          <div className="border rounded p-3 bg-white text-sm space-y-1">
            <div className="font-semibold">Pest/Disease Risk</div>
            <div>Level: {data.pest_risk?.level}</div>
            <ul className="list-disc ml-5">
              {(data.pest_risk?.notes||[]).map((n,i)=><li key={i}>{n}</li>)}
            </ul>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-1">
            <div className="font-semibold">Yield Prediction</div>
            <div>Base: {data.yield_prediction?.base_t_ha} t/ha</div>
            <div>Factor: {data.yield_prediction?.factor}</div>
            <div className="font-semibold">Predicted: {data.yield_prediction?.predicted_t_ha} t/ha</div>
          </div>



          <div className="border rounded p-3 bg-white text-sm space-y-1 md:col-span-2">
            <div className="font-semibold">Zones Yield</div>
            <table className="w-full text-sm border">
              <thead><tr className="bg-slate-100">
                <th className="p-1 border">Level</th>
                <th className="p-1 border">Area %</th>
                <th className="p-1 border">Factor</th>
                <th className="p-1 border">Pred t/ha</th>
                <th className="p-1 border">Weighted</th>
              </tr></thead>
              <tbody>
                {(data.zones_yield||[]).map((z,i)=>(
                  <tr key={i}>
                    <td className="border p-1">{z.level}</td>
                    <td className="border p-1">{(z.area_fraction*100).toFixed(1)}</td>
                    <td className="border p-1">{z.factor}</td>
                    <td className="border p-1">{z.predicted_t_ha}</td>
                    <td className="border p-1">{z.weighted_t_ha}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-1 md:col-span-2">
            <div className="font-semibold">Zone Soil Stats</div>
            <ul className="list-disc ml-5">
              {(data.zone_polygons_stats||[]).map((z,i)=>(
                <li key={i}>
                  {z.level} — pH {z.soil_stats?.ph_mean?.toFixed?.(2)} | EC {z.soil_stats?.ec_mean?.toFixed?.(2)} | SOM {z.soil_stats?.som_mean?.toFixed?.(2)}
                </li>
              ))}
            </ul>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-1 md:col-span-2">
            <div className="font-semibold">Zone Polygons (coarse)</div>
            <ul className="list-disc ml-5">
              {(data.zone_polygons||[]).map((z,i)=>(
                <li key={i}>{z.level} — {(z.area_fraction*100).toFixed(1)}% — bbox: {z.bbox.join(", ")}</li>
              ))}
            </ul>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-1">
            <div className="font-semibold">Soil Suitability</div>
            <div>Score: {data.soil?.suitability?.score}</div>
            <div>Best crops: {(data.soil?.suitability?.best_crops||[]).join(", ")}</div>
          </div>

          <div className="border rounded p-3 bg-white text-sm space-y-1">
            <div className="font-semibold">Weather Alerts</div>
            <ul className="list-disc ml-5">
              {(data.weather?.alerts||[]).map((a,i)=>(
                <li key={i}>{a.type} — {a.level}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
