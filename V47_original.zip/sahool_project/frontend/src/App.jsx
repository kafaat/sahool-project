import { useEffect, useMemo, useState } from "react";
import TopBar from "./components/TopBar.jsx";
import Sidebar from "./components/Sidebar.jsx";
import KPIBar from "./components/KPIBar.jsx";
import Panel from "./components/Panel.jsx";
import MapView from "./components/MapView.jsx";
import TimelineChart from "./components/TimelineChart.jsx";
import Alerts from "./pages/Alerts.jsx";
import Reports from "./pages/Reports.jsx";
import Compare from "./pages/Compare.jsx";
import ComparePro from "./pages/ComparePro.jsx";
import AdminConsole from "./pages/AdminConsole.jsx";
import WeatherDashboard from "./pages/WeatherDashboard.jsx";
import SoilDashboard from "./pages/SoilDashboard.jsx";
import AnomalyButton from "./components/AnomalyButton.jsx";
import Weather from "./pages/Weather.jsx";
import TimelinePage from "./pages/Timeline.jsx";
import { fetchDashboardData, fetchTimeline } from "./api.js";

export default function App(){
  const [theme, setTheme] = useState(()=> localStorage.getItem('theme') || 'light');
  useEffect(()=>{
    document.documentElement.classList.toggle('dark', theme==='dark');
    localStorage.setItem('theme', theme);
  },[theme]);

  const [tenantId, setTenantId] = useState(1);
  const [data, setData] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [showAnomaly, setShowAnomaly] = useState(false);
  const [showAnomalyIndex, setShowAnomalyIndex] = useState(false);
  const [timeline, setTimeline] = useState(null);
  const [tab, setTab] = useState("map");
  const [indexName, setIndexName] = useState("ndvi");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(()=>{
    (async ()=>{
      setLoading(true); setError("");
      try{
        const d = await fetchDashboardData(tenantId);
        setData(d);
        if(d.items.length) setSelectedId(d.items[0].id);
      }catch(e){ setError(e.message); }
      finally{ setLoading(false); }
    })();
  },[tenantId]);

  useEffect(()=>{
    if(!selectedId || tab!=="map") return;
    (async ()=>{
      try{
        const tl = await fetchTimeline(selectedId, tenantId);
        setTimeline(tl);
      }catch{ setTimeline(null); }
    })();
  },[selectedId, tenantId, tab]);

  const fields = data?.items || [];
  const selectedField = useMemo(()=>fields.find(f=>f.id===selectedId), [fields, selectedId]);

  return (
    <div className="h-full w-full bg-slate-100 dark:bg-slate-900 flex flex-col">
      <TopBar
        tenantId={tenantId}
        onTenantChange={setTenantId}
        activeTab={tab}
        onTabChange={setTab}
      />

      <div className="flex flex-1 min-h-0">
        {tab==="map" && (
          <Sidebar showAnomalyIndex={showAnomalyIndex} setShowAnomalyIndex={setShowAnomalyIndex}
  
            fields={fields}
            selectedId={selectedId}
            onSelect={setSelectedId}
          />
        )}

        <main className="flex-1 min-h-0 p-4 overflow-y-auto space-y-4 transition-colors duration-300">
          {/* KPI row */}
          const totalFields = fields.length;
      const criticalAlerts = fields.filter(f=>f.risk_level>=4).length;
      const avgNdvi = fields.length ? fields.reduce((s,f)=>s+(f.latest_ndvi||0),0)/fields.length : null;

              <KPIBar selectedField={selectedField} totalFields={totalFields} criticalAlerts={criticalAlerts} avgNdvi={avgNdvi} />

          {loading && <div className="text-sm text-slate-600">Loading...</div>}
          {error && <div className="text-sm text-red-600">{error}</div>}

          {!loading && !error && tab==="map" && (
            <div className="grid grid-cols-1 xl:grid-cols-[1.4fr_1fr] gap-4">
              <Panel title="NDVI Map Layer" right={
                <div className="text-xs text-slate-500">
                  Field: {selectedField?.name || "—"}
                </div>
              }>
                <div className="h-[520px] rounded-xl overflow-hidden">
                  <MapView fields={fields} selectedId={selectedId} onSelect={setSelectedId} indexName={indexName} />
                </div>
              </Panel>

              <Panel title="NDVI Timeline">
                <TimelineChart timeline={timeline}/>
              </Panel>
            </div>
          )}

          {!loading && !error && tab==="timeline" && (
            <Panel title="NDVI Timeline">
              <TimelinePage fieldId={selectedId} tenantId={tenantId} />
            </Panel>
          )}

          {!loading && !error && tab==="weather" && (
            <Panel title="Weather Dashboard">
              <Weather fieldId={selectedId} tenantId={tenantId} />
            </Panel>
          )}

          {!loading && !error && tab==="alerts" && (
            <Panel title="Alerts">
              <Alerts tenantId={tenantId} onGoField={(fid)=>{ setSelectedId(fid); setTab("map"); }} />
            </Panel>
          )}

          {!loading && !error && tab==="reports" && (
            <Panel title="Weekly Reports">
              <Reports tenantId={tenantId} fieldId={selectedId}/>
            </Panel>
          )}

          {!loading && !error && tab==="compare" && (
            <Panel title="Compare Fields">
              <Compare tenantId={tenantId} fields={fields}/>
            </Panel>
          )}

          <footer className="text-xs text-slate-400 pt-2">
            Sahool © {new Date().getFullYear()} — Smart agriculture monitoring
          </footer>
        </main>
      </div>
    </div>
  );
}
