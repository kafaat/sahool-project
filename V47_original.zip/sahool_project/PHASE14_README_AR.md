# Phase 14 — Enterprise Hardening

## ما تم إضافته
1. Rate limiting عبر Redis لكل tenant/IP.
2. Redis cache للـ legend والـ tiles (TTL).
3. SentinelHub quota guard + circuit breaker.
4. RBAC خفيفة عبر Headers:
   - x-tenant-id
   - x-roles
   - x-user-id
5. Audit logs في جدول `audit_logs`.

## إعدادات جديدة في .env
```env
RATE_LIMIT_RPM=120
SENTINEL_DAILY_LIMIT=200
```

## ملاحظة
RBAC هنا خفيفة (headers-based). يمكن استبدالها لاحقًا بـ JWT.
