# Web field drawing + NDVI tiles (vanilla Leaflet)

Open `index.html` in a static server.
Set `API_BASE` inside file.


Additions: see package_additions.txt for NDVI timeline, before/after, and PDF.
