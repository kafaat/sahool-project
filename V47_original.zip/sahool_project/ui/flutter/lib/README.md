### Polygon Offline Pack (Phase7)
Use `fetchOfflinePolygonTileList` instead of bbox list for accurate field-shaped downloads.
