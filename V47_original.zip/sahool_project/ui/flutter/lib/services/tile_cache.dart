// Offline tile cache interface (Hybrid Balanced).
// Replace memory map with Hive/SQLite for persistence.

class TileKey {
  final int resultId, z, x, y;
  const TileKey(this.resultId, this.z, this.x, this.y);

  @override
  String toString() => '$resultId-$z-$x-$y';

  @override
  bool operator ==(Object other) =>
      other is TileKey && other.resultId==resultId && other.z==z && other.x==x && other.y==y;

  @override
  int get hashCode => Object.hash(resultId, z, x, y);
}

class TileCache {
  final Map<String, List<int>> _mem = {};

  bool has(TileKey k) => _mem.containsKey(k.toString());
  List<int>? get(TileKey k) => _mem[k.toString()];
  void put(TileKey k, List<int> bytes) => _mem[k.toString()] = bytes;
}
