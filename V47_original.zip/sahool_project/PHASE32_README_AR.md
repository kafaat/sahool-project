# Phase 32 — Smart Agronomic Engine

## Endpoint
`GET /api/agro/ai?field_id=&crop=&stage=`

يرجع:
- NDVI stress fractions من tiles
- Soil suitability + analysis + irrigation-from-soil
- Weather summary + alerts + irrigation plan
- توصيات ري لكل stress zone

## Web
Route: `/agro`  (Agro AI Dashboard)
