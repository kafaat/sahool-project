Phase36 placeholder: closing spectral, soil layers, time-series, disease engine.
