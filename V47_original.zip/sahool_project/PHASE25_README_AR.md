# Phase 25 — NDVI Stress Worker + Soil Suitability + Soil Tiles + Irrigation Zones + Celery Beat

## الجديد
1. NDVI Stress Worker يومي:
   - app/modules/ndvi/stress_pipeline.py
   - app/modules/ndvi/stress_worker.py
   - ينتج tiles في storage/ndvi_stress

2. Soil Suitability Engine:
   - app/modules/soil/suitability.py
   - endpoint: GET /soil/suitability?field_id=&crop=

3. Soil Tiles:
   - /soil/tiles/ph/{z}/{x}/{y}.png
   - /soil/tiles/ec/{z}/{x}/{y}.png
   - /soil/tiles/som/{z}/{x}/{y}.png

4. Irrigation per stress zones:
   - GET /weather/irrigation-zones?field_id=&crop=&stage=

5. Celery Beat scheduling:
   - ndvi_stress_daily كل 24 ساعة
   - weekly_irrigation كل 7 أيام
