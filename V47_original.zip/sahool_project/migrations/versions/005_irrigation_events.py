"""irrigation events

Revision ID: 005
Revises: 004
"""
from alembic import op
import sqlalchemy as sa

revision="005"
down_revision="004"

def upgrade():
    op.create_table(
        "irrigation_events",
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("field_id", sa.Integer(), nullable=False),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("amount_mm", sa.Float(), nullable=False),
        sa.Column("method", sa.String()),
        sa.Column("created_at", sa.DateTime()),
        sa.Column("meta", sa.JSON()),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["field_id"], ["fields.id"]),
        sa.UniqueConstraint("tenant_id","field_id","date", name="uq_irrig_event_field_date"),
    )
    op.create_index("ix_irrigation_events_field_id","irrigation_events",["field_id"])
    op.create_index("ix_irrigation_events_date","irrigation_events",["date"])
    op.create_index("ix_irrigation_events_tenant_id","irrigation_events",["tenant_id"])

def downgrade():
    op.drop_table("irrigation_events")
