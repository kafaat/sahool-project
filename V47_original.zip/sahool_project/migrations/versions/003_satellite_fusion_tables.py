"""satellite indices + daily states + crop/soil

Revision ID: 003
Revises: 002
"""
from alembic import op
import sqlalchemy as sa

revision="003"
down_revision="002"
branch_labels=None
depends_on=None

def upgrade():
    op.create_table(
        "crop_calendars",
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("field_id", sa.Integer(), nullable=False),
        sa.Column("crop_name", sa.String(), nullable=False),
        sa.Column("variety", sa.String()),
        sa.Column("season_start", sa.Date(), nullable=False),
        sa.Column("season_end", sa.Date()),
        sa.Column("planting_date", sa.Date()),
        sa.Column("harvest_date", sa.Date()),
        sa.Column("stage_0_days", sa.Integer()),
        sa.Column("stage_1_days", sa.Integer()),
        sa.Column("stage_2_days", sa.Integer()),
        sa.Column("stage_3_days", sa.Integer()),
        sa.Column("stage_4_days", sa.Integer()),
        sa.Column("base_temp_c", sa.Float(), server_default="10.0"),
        sa.Column("gdd_stage_1", sa.Float(), server_default="250.0"),
        sa.Column("gdd_stage_2", sa.Float(), server_default="600.0"),
        sa.Column("gdd_stage_3", sa.Float(), server_default="900.0"),
        sa.Column("gdd_stage_4", sa.Float(), server_default="1200.0"),
        sa.Column("notes", sa.JSON()),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["field_id"], ["fields.id"]),
        sa.UniqueConstraint("tenant_id","field_id","season_start", name="uq_crop_calendar_season"),
    )
    op.create_index("ix_crop_calendars_field_id","crop_calendars",["field_id"])
    op.create_index("ix_crop_calendars_tenant_id","crop_calendars",["tenant_id"])

    op.create_table(
        "soil_profiles",
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("field_id", sa.Integer(), nullable=False),
        sa.Column("texture", sa.String()),
        sa.Column("depth_cm", sa.Float()),
        sa.Column("awc_mm", sa.Float()),
        sa.Column("organic_matter_pct", sa.Float()),
        sa.Column("ph", sa.Float()),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["field_id"], ["fields.id"]),
        sa.UniqueConstraint("tenant_id","field_id", name="uq_soil_profile_field"),
    )
    op.create_index("ix_soil_profiles_field_id","soil_profiles",["field_id"])
    op.create_index("ix_soil_profiles_tenant_id","soil_profiles",["tenant_id"])

    op.create_table(
        "satellite_index_records",
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("field_id", sa.Integer(), nullable=False),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("processed_at", sa.DateTime()),
        sa.Column("ndvi_mean", sa.Float()),
        sa.Column("ndvi_min", sa.Float()),
        sa.Column("ndvi_max", sa.Float()),
        sa.Column("ndwi_mean", sa.Float()),
        sa.Column("evi_mean", sa.Float()),
        sa.Column("savi_mean", sa.Float()),
        sa.Column("cloud_pct", sa.Float()),
        sa.Column("raw", sa.JSON()),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["field_id"], ["fields.id"]),
        sa.UniqueConstraint("tenant_id","field_id","date", name="uq_sat_idx_field_date"),
    )
    op.create_index("ix_satellite_index_records_field_id","satellite_index_records",["field_id"])
    op.create_index("ix_satellite_index_records_date","satellite_index_records",["date"])
    op.create_index("ix_satellite_index_records_tenant_id","satellite_index_records",["tenant_id"])

    op.create_table(
        "field_daily_states",
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("field_id", sa.Integer(), nullable=False),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("created_at", sa.DateTime()),
        sa.Column("ndvi", sa.Float()),
        sa.Column("ndwi", sa.Float()),
        sa.Column("evi", sa.Float()),
        sa.Column("savi", sa.Float()),
        sa.Column("temp_max_c", sa.Float()),
        sa.Column("temp_min_c", sa.Float()),
        sa.Column("precip_sum_mm", sa.Float()),
        sa.Column("humidity_current_pct", sa.Float()),
        sa.Column("water_stress", sa.Float()),
        sa.Column("heat_stress", sa.Float()),
        sa.Column("vigor_score", sa.Float()),
        sa.Column("anomaly_score", sa.Float()),
        sa.Column("stage", sa.String()),
        sa.Column("recommendation", sa.JSON()),
        sa.Column("raw", sa.JSON()),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["field_id"], ["fields.id"]),
        sa.UniqueConstraint("tenant_id","field_id","date", name="uq_field_state_date"),
    )
    op.create_index("ix_field_daily_states_field_id","field_daily_states",["field_id"])
    op.create_index("ix_field_daily_states_date","field_daily_states",["date"])
    op.create_index("ix_field_daily_states_tenant_id","field_daily_states",["tenant_id"])

def downgrade():
    op.drop_table("field_daily_states")
    op.drop_table("satellite_index_records")
    op.drop_table("soil_profiles")
    op.drop_table("crop_calendars")
