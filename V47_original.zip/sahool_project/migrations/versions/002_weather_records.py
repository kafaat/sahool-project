"""weather records table

Revision ID: 002
Revises: 001
"""
from alembic import op
import sqlalchemy as sa

revision="002"
down_revision="001"
branch_labels=None
depends_on=None

def upgrade():
    op.create_table(
        "weather_records",
        sa.Column("tenant_id", sa.BigInteger(), nullable=False),
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("field_id", sa.Integer(), nullable=False),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("temp_max_c", sa.Float()),
        sa.Column("temp_min_c", sa.Float()),
        sa.Column("precip_sum_mm", sa.Float()),
        sa.Column("wind_max_kmh", sa.Float()),
        sa.Column("uv_max", sa.Float()),
        sa.Column("temp_current_c", sa.Float()),
        sa.Column("humidity_current_pct", sa.Float()),
        sa.Column("wind_current_kmh", sa.Float()),
        sa.Column("precip_current_mm", sa.Float()),
        sa.Column("cloud_cover_current_pct", sa.Float()),
        sa.Column("raw", sa.JSON()),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["field_id"], ["fields.id"]),
        sa.UniqueConstraint("tenant_id","field_id","date", name="uq_weather_field_date"),
    )
    op.create_index("ix_weather_records_field_id","weather_records",["field_id"])
    op.create_index("ix_weather_records_date","weather_records",["date"])
    op.create_index("ix_weather_records_tenant_id","weather_records",["tenant_id"])

def downgrade():
    op.drop_index("ix_weather_records_tenant_id", table_name="weather_records")
    op.drop_index("ix_weather_records_date", table_name="weather_records")
    op.drop_index("ix_weather_records_field_id", table_name="weather_records")
    op.drop_table("weather_records")
