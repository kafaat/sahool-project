"""phase37 soil depth layers

Revision ID: phase37_soil_depth_layers
Revises: 
Create Date: 2025-11-24

"""

from alembic import op
import sqlalchemy as sa

revision = 'phase37_soil_depth_layers'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table('soil_profiles') as batch:
        batch.add_column(sa.Column('ph_0_30', sa.Float(), nullable=True))
        batch.add_column(sa.Column('ph_30_60', sa.Float(), nullable=True))
        batch.add_column(sa.Column('ph_60_100', sa.Float(), nullable=True))
        batch.add_column(sa.Column('ec_0_30', sa.Float(), nullable=True))
        batch.add_column(sa.Column('ec_30_60', sa.Float(), nullable=True))
        batch.add_column(sa.Column('ec_60_100', sa.Float(), nullable=True))
        batch.add_column(sa.Column('som_0_30', sa.Float(), nullable=True))
        batch.add_column(sa.Column('som_30_60', sa.Float(), nullable=True))
        batch.add_column(sa.Column('som_60_100', sa.Float(), nullable=True))

def downgrade():
    with op.batch_alter_table('soil_profiles') as batch:
        for col in ['ph_0_30','ph_30_60','ph_60_100','ec_0_30','ec_30_60','ec_60_100','som_0_30','som_30_60','som_60_100']:
            batch.drop_column(col)
