# Scaling & Cloud Notes (Phase 10)

## Workers Scaling
في `docker-compose.prod.yml`:
```yaml
worker:
  deploy:
    replicas: 2
```

ارفعها إلى 4/6 حسب حجم المعالجة.

## Redis Tuning
- اجعل Redis على VM منفصلة لو زاد الحمل.
- استخدم AOF persistence في الإنتاج.

## DB (PostGIS)
- فعّل backups اليومية عبر `deploy/db/backup.sh`.
- ضع الـ DB على disk SSD.

## Observability
- /metrics متوافق مع Prometheus.
- يمكنك ربط Grafana مباشرة.

## Production Tip
إن كان عندك tiles كثيرة:
- اجعل `storage/` على volume خارجي (S3/MinIO).
