# V47 — Full Merge (Docker + E2E Turbo + Swagger Enhancements)

## ✅ Changes
1) **docker-compose.yml**
   - Fixed invalid `beat` placement.
   - Added `beat` service properly.
   - Corrected Celery commands (no `.celery` suffix).
   - Added `working_dir: /code` consistency.
   - **E2E Turbo Mode**: uses official Playwright image directly (no build).

2) **Playwright**
   - Updated `frontend/Dockerfile.e2e` as optional CI-only image with cached npm ci.

3) **Swagger/OpenAPI**
   - Global metadata and tags in `app/main.py`.
   - Added summaries/descriptions to routes:
     - Timeline (/timeline/*)
     - Heatmap tiles
     - Video export
     - Reports
     - Disease risk

## ▶️ Run
```bash
docker compose up -d --build
```

### Run E2E
```bash
docker compose run --rm e2e
```
