# Phase 17 — Admin UI + Refresh Rotation Guard + MFA (TOTP)

## ما تم
1. Admin Panel UI حقيقية (tables/actions) بدل JSON.
2. حماية refresh token rotation ضد reuse:
   - إذا استُخدم refresh قديم بعد تدويره → يتم إلغاء كل refresh للمستخدم.
3. MFA اختياري عبر TOTP:
   - /auth/mfa/enable
   - /auth/mfa/confirm
   - /auth/mfa/disable
   - login يدعم otp_code

## متغيرات البيئة
```env
JWT_SECRET=change-this
```

## تفعيل MFA
1) enable:
POST /api/auth/mfa/enable?user_id=2  (admin)
ترجع secret + uri

2) أضف secret في Google Authenticator

3) confirm:
POST /api/auth/mfa/confirm?user_id=2&code=123456

## تسجيل الدخول مع MFA
POST /api/auth/login?...&otp_code=123456
