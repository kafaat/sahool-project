# Phase25 Tests

## Backend
تشغيل:
```bash
pytest -m phase25
```

الاختبارات تشمل:
- NDVI stress pipeline + tile generation
- Soil suitability scoring + warnings
- Soil tiles render (blank & with profile)
- Irrigation zones endpoint smoke
- Celery tasks import

## Frontend E2E
تشغيل:
```bash
docker compose run e2e
```
الاختبارات تشمل:
- تفعيل طبقات Soil tiles
- ظهور suitability panel
- irrigation-zones mock smoke
