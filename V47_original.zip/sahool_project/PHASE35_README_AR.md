# Phase 35 — Vector Polygons + Yield per Zone + PDF Export

## الجديد
1. Vectorization حقيقي من NDVI raster:
   - app/modules/agro_intel/vectorize.py
   - zones_geojson أصبح مبني على contours (marching squares)

2. Yield per Zone:
   - app/modules/agro_intel/yield_zones.py
   - يخرج zones_yield

3. تقرير PDF:
   - app/modules/agro_intel/report_pdf.py
   - endpoint: /api/agro/report.pdf

4. Web:
   - زر Download PDF
   - جدول Zones Yield

## التشغيل
- API: GET /api/agro/ai
- PDF: GET /api/agro/report.pdf
