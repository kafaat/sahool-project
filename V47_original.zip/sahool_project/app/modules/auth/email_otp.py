from __future__ import annotations
import datetime, random
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from app.core.config import settings

def _serializer():
    return URLSafeTimedSerializer(settings.jwt_secret or "change-me", salt="mfa-email")

def generate_code(email: str) -> str:
    code = f"{random.randint(0, 999999):06d}"
    token = _serializer().dumps({"email": email, "code": code})
    return code, token

def verify_token(token: str, code: str, max_age: int) -> bool:
    try:
        data = _serializer().loads(token, max_age=max_age)
        return data.get("code") == code
    except (BadSignature, SignatureExpired):
        return False
