from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, JSON, UniqueConstraint
from sqlalchemy.orm import relationship
from app.core.db import Base
import datetime

class Tenant(Base):
    __tablename__="tenants"
    id=Column(Integer, primary_key=True)
    name=Column(String(120), unique=True, nullable=False)
    is_active=Column(Boolean, default=True)
    mfa_enabled=Column(Boolean, default=False)
    mfa_secret=Column(String(64), nullable=True)
    mfa_email_enabled=Column(Boolean, default=False)
    mfa_email_token=Column(String(255), nullable=True)
    mfa_email_sent_at=Column(DateTime, nullable=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class Role(Base):
    __tablename__="roles"
    id=Column(Integer, primary_key=True)
    name=Column(String(80), unique=True, nullable=False)

class User(Base):
    __tablename__="users"
    id=Column(Integer, primary_key=True)
    tenant_id=Column(Integer, ForeignKey("tenants.id"), nullable=False)
    email=Column(String(180), nullable=False)
    password_hash=Column(String(255), nullable=False)
    roles=Column(String(255), default="user")  # comma-separated
    is_active=Column(Boolean, default=True)
    mfa_enabled=Column(Boolean, default=False)
    mfa_secret=Column(String(64), nullable=True)
    mfa_email_enabled=Column(Boolean, default=False)
    mfa_email_token=Column(String(255), nullable=True)
    mfa_email_sent_at=Column(DateTime, nullable=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

    __table_args__=(UniqueConstraint("tenant_id","email",name="uq_user_tenant_email"),)

class APIKey(Base):
    __tablename__="api_keys"
    id=Column(Integer, primary_key=True)
    tenant_id=Column(Integer, ForeignKey("tenants.id"), nullable=False)
    name=Column(String(120), nullable=False)
    key_hash=Column(String(255), nullable=False, unique=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    last_used_at=Column(DateTime, nullable=True)
    usage_count=Column(Integer, default=0)
    meta=Column(JSON, nullable=True)


class RefreshToken(Base):
    __tablename__="refresh_tokens"
    id=Column(Integer, primary_key=True)
    user_id=Column(Integer, ForeignKey("users.id"), nullable=False)
    token_hash=Column(String(255), nullable=False, unique=True)
    expires_at=Column(DateTime, nullable=False)
    revoked=Column(Boolean, default=False)
    reused=Column(Boolean, default=False)
    replaced_by=Column(String(255), nullable=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
