from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.models import User
from app.modules.auth.deps import require_tenant
from app.modules.auth.email_otp import generate_code, verify_token
from app.core.config import settings
from app.integrations.mailer.smtp import send_email
import datetime

router = APIRouter(prefix="/auth/mfa-email", tags=["mfa-email"])

@router.post("/send")
async def send_code(user_id: int, tenant=Depends(require_tenant), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"user not found")
    code, token = generate_code(u.email)
    u.mfa_email_token = token
    u.mfa_email_sent_at = datetime.datetime.utcnow()
    db.add(u); db.commit()
    await send_email(u.email, "Your Sahool MFA code", f"Your code is: {code}")
    return {"ok": True}

@router.post("/confirm")
def confirm(user_id: int, code: str, tenant=Depends(require_tenant), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"] or not u.mfa_email_token:
        raise HTTPException(404,"user not found")
    if not verify_token(u.mfa_email_token, code, settings.mfa_email_ttl_sec):
        raise HTTPException(400,"invalid code")
    u.mfa_email_enabled = True
    u.mfa_email_token = None
    db.add(u); db.commit()
    return {"ok": True}

@router.post("/disable")
def disable(user_id: int, tenant=Depends(require_tenant), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"user not found")
    u.mfa_email_enabled = False
    u.mfa_email_token = None
    db.add(u); db.commit()
    return {"ok": True}
