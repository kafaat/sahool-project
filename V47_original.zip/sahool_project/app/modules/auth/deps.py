from __future__ import annotations
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.models import User, APIKey, RefreshToken
from app.modules.auth.security import decode_token, verify_api_key, hash_api_key
from app.core.permissions import has_perm

def get_identity(request: Request, db: Session = Depends(get_db)):
    # 1) API key
    api_key = request.headers.get("x-api-key")
    if api_key:
        key_hash = hash_api_key(api_key)
        row = db.query(APIKey).filter_by(key_hash=key_hash).first()
        if not row:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid API key")
        try:
            row.last_used_at = __import__('datetime').datetime.utcnow()
            row.usage_count = (row.usage_count or 0) + 1
            db.add(row); db.commit()
        except Exception:
            pass
        return {"tenant_id": row.tenant_id, "sub": f"apikey:{row.id}", "roles": "device"}

    # 2) JWT Bearer
    auth = request.headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        token = auth.split(" ",1)[1].strip()
        try:
            data = decode_token(token)
            sub = data.get("sub")
            tenant_id = data.get("tenant_id")
            roles = "user"
            if sub and str(sub).isdigit():
                u = db.get(User, int(sub))
                if u and u.is_active:
                    roles = u.roles or "user"
                    tenant_id = u.tenant_id
            return {"tenant_id": tenant_id, "sub": sub, "roles": roles}
        except Exception:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token")

    raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Auth required")

def require_role(role_or_perm: str):
    def dep(ident = Depends(get_identity)):
        roles = [r.strip() for r in (ident.get("roles") or "").split(",") if r.strip()]
        if not has_perm(ident.get('roles','user'), role_or_perm) and role_or_perm not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Forbidden")
        return True
    return dep

def require_tenant(ident = Depends(get_identity)):
    if not ident.get("tenant_id"):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Tenant required")
    return ident

# load user roles from DB (phase16)
