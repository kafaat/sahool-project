import pyotp

def new_mfa_secret():
    return pyotp.random_base32()

def otp_uri(email: str, secret: str, issuer="SahoolFarmonaut"):
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=email, issuer_name=issuer)

def verify_otp(secret: str, code: str) -> bool:
    return pyotp.TOTP(secret).verify(code, valid_window=1)
