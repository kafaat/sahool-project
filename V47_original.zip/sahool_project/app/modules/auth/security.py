from __future__ import annotations
import datetime, hashlib, hmac, os
from typing import Optional, Dict, Any
import jwt
from passlib.context import CryptContext
from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(p: str) -> str:
    return pwd_context.hash(p)

def verify_password(p: str, hashed: str) -> bool:
    return pwd_context.verify(p, hashed)

def _jwt_secret() -> str:
    return settings.jwt_secret or "change-me"

def create_access_token(sub: str, tenant_id: int, roles: str, expires_minutes: int = 60*24) -> str:
    now = datetime.datetime.utcnow()
    payload = {
        "sub": sub,
        "tenant_id": tenant_id,
        "roles": roles,
        "iat": int(now.timestamp()),
        "exp": int((now + datetime.timedelta(minutes=expires_minutes)).timestamp())
    }
    return jwt.encode(payload, _jwt_secret(), algorithm="HS256")

def decode_token(token: str) -> Dict[str, Any]:
    return jwt.decode(token, _jwt_secret(), algorithms=["HS256"])

def hash_api_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()

def verify_api_key(key: str, key_hash: str) -> bool:
    return hmac.compare_digest(hash_api_key(key), key_hash)


def create_refresh_token(raw: str) -> str:
    return hash_api_key(raw)

def new_refresh_pair(sub: str, tenant_id: int, roles: str, refresh_expires_days: int = 30):
    access = create_access_token(sub=sub, tenant_id=tenant_id, roles=roles, expires_minutes=60*24)
    raw_refresh = secrets.token_urlsafe(48)
    refresh_hash = create_refresh_token(raw_refresh)
    exp = datetime.datetime.utcnow() + datetime.timedelta(days=refresh_expires_days)
    return access, raw_refresh, refresh_hash, exp
