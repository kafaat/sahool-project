from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.models import User
from app.modules.auth.deps import require_tenant, require_role
from app.modules.auth.mfa import new_mfa_secret, otp_uri, verify_otp

router = APIRouter(prefix="/auth/mfa", tags=["mfa"], dependencies=[Depends(require_role("admin"))])

@router.post("/enable")
def enable_mfa(user_id: int, tenant=Depends(require_tenant), db: Session=Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"user not found")
    secret = new_mfa_secret()
    u.mfa_secret = secret
    u.mfa_enabled = False
    db.add(u); db.commit()
    return {"secret": secret, "uri": otp_uri(u.email, secret)}

@router.post("/confirm")
def confirm_mfa(user_id: int, code: str, tenant=Depends(require_tenant), db: Session=Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"] or not u.mfa_secret:
        raise HTTPException(404,"user not found")
    if not verify_otp(u.mfa_secret, code):
        raise HTTPException(400,"invalid code")
    u.mfa_enabled = True
    db.add(u); db.commit()
    return {"ok": True}

@router.post("/disable")
def disable_mfa(user_id: int, tenant=Depends(require_tenant), db: Session=Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"user not found")
    u.mfa_enabled = False
    u.mfa_secret = None
    db.add(u); db.commit()
    return {"ok": True}
