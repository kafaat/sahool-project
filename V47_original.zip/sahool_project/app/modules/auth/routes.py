from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.models import Tenant, User, APIKey, RefreshToken
from app.modules.auth.security import hash_password, verify_password, create_access_token, hash_api_key, new_refresh_pair, create_refresh_token
from app.modules.auth.deps import require_role, require_tenant
from app.core.config import settings
import secrets, datetime

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login")
def login(email: str, password: str, tenant_id: int, otp_code: str | None = None, email_otp_code: str | None = None, db: Session = Depends(get_db)):
    u = db.query(User).filter_by(email=email, tenant_id=tenant_id, is_active=True).first()
    if not u or not verify_password(password, u.password_hash):
        raise HTTPException(401, "Invalid credentials")

    if u.mfa_enabled:
        from app.modules.auth.mfa import verify_otp
        if not otp_code or not u.mfa_secret or not verify_otp(u.mfa_secret, otp_code):
            raise HTTPException(401, "OTP required")

    if u.mfa_email_enabled:
        from app.modules.auth.email_otp import verify_token
        if not email_otp_code or not u.mfa_email_token or not verify_token(u.mfa_email_token, email_otp_code, settings.mfa_email_ttl_sec):
            raise HTTPException(401, "Email OTP required")
        u.mfa_email_token = None

    access, raw_refresh, refresh_hash, exp = new_refresh_pair(sub=str(u.id), tenant_id=u.tenant_id, roles=u.roles)
    row = RefreshToken(user_id=u.id, token_hash=refresh_hash, expires_at=exp)
    db.add(row); db.commit()
    return {"access_token": access, "refresh_token": raw_refresh, "token_type":"bearer"}

@router.post("/tenants", dependencies=[Depends(require_role("superadmin"))])
def create_tenant(name: str, db: Session = Depends(get_db)):
    t = Tenant(name=name)
    db.add(t); db.commit(); db.refresh(t)
    return {"id": t.id, "name": t.name}

@router.post("/users", dependencies=[Depends(require_role("admin"))])
def create_user(tenant_id: int, email: str, password: str, roles: str="user", db: Session = Depends(get_db)):
    u = User(tenant_id=tenant_id, email=email, password_hash=hash_password(password), roles=roles)
    db.add(u); db.commit(); db.refresh(u)
    return {"id": u.id, "email": u.email, "roles": u.roles}

@router.post("/apikeys", dependencies=[Depends(require_role("admin"))])
def create_apikey(tenant = Depends(require_tenant), name: str="device", db: Session = Depends(get_db)):
    raw = secrets.token_urlsafe(32)
    row = APIKey(tenant_id=tenant["tenant_id"], name=name, key_hash=hash_api_key(raw))
    db.add(row); db.commit(); db.refresh(row)
    return {"api_key": raw, "id": row.id, "name": row.name}

@router.get("/apikeys", dependencies=[Depends(require_role("admin"))])
def list_apikeys(tenant = Depends(require_tenant), db: Session = Depends(get_db)):
    rows = db.query(APIKey).filter_by(tenant_id=tenant["tenant_id"]).all()
    return {"items":[{"id":r.id,"name":r.name,"created_at":r.created_at} for r in rows]}

@router.delete("/apikeys/{key_id}", dependencies=[Depends(require_role("admin"))])
def delete_apikey(key_id: int, tenant = Depends(require_tenant), db: Session = Depends(get_db)):
    r=db.get(APIKey, key_id)
    if not r or r.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"Not found")
    db.delete(r); db.commit()
    return {"ok": True}



@router.post("/logout")
def logout(refresh_token: str, db: Session = Depends(get_db)):
    h = create_refresh_token(refresh_token)
    row = db.query(RefreshToken).filter_by(token_hash=h).first()
    if row:
        row.revoked = True
        db.add(row); db.commit()
    return {"ok": True}


@router.post("/refresh")
def refresh(refresh_token: str, db: Session = Depends(get_db)):
    h = create_refresh_token(refresh_token)

    row = db.query(RefreshToken).filter_by(token_hash=h).first()
    if not row:
        raise HTTPException(401, "Invalid refresh token")

    if row.revoked:
        row.reused = True
        db.add(row); db.commit()

        db.query(RefreshToken).filter_by(user_id=row.user_id, revoked=False).update({"revoked": True})
        db.commit()
        raise HTTPException(401, "Refresh token reuse detected")

    if row.expires_at < datetime.datetime.utcnow():
        row.revoked = True
        db.add(row); db.commit()
        raise HTTPException(401, "Refresh expired")

    u = db.get(User, row.user_id)
    if not u or not u.is_active:
        raise HTTPException(401, "User inactive")

    access, raw_refresh, refresh_hash, exp = new_refresh_pair(sub=str(u.id), tenant_id=u.tenant_id, roles=u.roles)

    row.revoked = True
    row.replaced_by = refresh_hash
    db.add(row)

    new_row = RefreshToken(user_id=u.id, token_hash=refresh_hash, expires_at=exp, revoked=False)
    db.add(new_row)
    db.commit()

    return {"access_token": access, "refresh_token": raw_refresh, "token_type":"bearer"}
