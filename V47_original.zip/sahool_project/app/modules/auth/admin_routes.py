from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.models import Tenant, User, APIKey
from app.modules.auth.security import hash_password
from app.modules.auth.deps import require_role, require_tenant
import datetime

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(require_role("admin.users.read"))])

@router.get("/tenants")
def tenants(db: Session = Depends(get_db)):
    rows = db.query(Tenant).order_by(Tenant.id.asc()).offset((page-1)*page_size).limit(page_size).all()
    return {"items":[{"id":t.id,"name":t.name,"is_active":t.is_active} for t in rows]}

@router.post("/tenants/{tenant_id}/toggle")
def toggle_tenant(tenant_id: int, db: Session = Depends(get_db)):
    t = db.get(Tenant, tenant_id)
    if not t: raise HTTPException(404,"not found")
    t.is_active = not t.is_active
    db.add(t); db.commit()
    return {"id": t.id, "is_active": t.is_active}

@router.get("/users")
def users(page: int = 1, page_size: int = 50, tenant = Depends(require_tenant), db: Session = Depends(get_db)):
    rows = db.query(User).filter_by(tenant_id=tenant["tenant_id"]).order_by(User.id.asc()).offset((page-1)*page_size).limit(page_size).all()
    return {"items":[{"id":u.id,"email":u.email,"roles":u.roles,"is_active":u.is_active} for u in rows]}

@router.post("/users/{user_id}/toggle")
def toggle_user(user_id: int, tenant = Depends(require_tenant), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"not found")
    u.is_active = not u.is_active
    db.add(u); db.commit()
    return {"id": u.id, "is_active": u.is_active}

@router.post("/users/{user_id}/reset-password")
def reset_password(user_id: int, new_password: str, tenant = Depends(require_tenant), db: Session = Depends(get_db)):
    u=db.get(User, user_id)
    if not u or u.tenant_id != tenant["tenant_id"]:
        raise HTTPException(404,"not found")
    u.password_hash = hash_password(new_password)
    db.add(u); db.commit()
    return {"ok": True}

@router.get("/apikeys")
def apikeys(tenant = Depends(require_tenant), db: Session = Depends(get_db)):
    rows = db.query(APIKey).filter_by(tenant_id=tenant["tenant_id"]).order_by(APIKey.id.asc()).offset((page-1)*page_size).limit(page_size).all()
    return {"items":[{"id":k.id,"name":k.name,"created_at":k.created_at,"last_used_at":k.last_used_at} for k in rows]}
