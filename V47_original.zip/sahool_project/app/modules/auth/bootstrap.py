from sqlalchemy.orm import Session
from app.modules.auth.models import Tenant, User
from app.modules.auth.security import hash_password
import os

def ensure_bootstrap(db: Session):
    if db.query(Tenant).count() == 0:
        t = Tenant(name=os.getenv("BOOTSTRAP_TENANT_NAME","default"))
        db.add(t); db.commit(); db.refresh(t)
        u = User(
            tenant_id=t.id,
            email=os.getenv("BOOTSTRAP_ADMIN_EMAIL","admin@sahool.local"),
            password_hash=hash_password(os.getenv("BOOTSTRAP_ADMIN_PASS","admin123")),
            roles="superadmin,admin"
        )
        db.add(u); db.commit()
