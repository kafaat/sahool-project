from sqlalchemy import Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import relationship
from geoalchemy2 import Geometry
from app.core.db import Base
from app.modules.weather.models import WeatherRecord
from app.modules.satellite.fused_models import SatelliteIndexRecord, FieldDailyState
from app.modules.crops.models import CropCalendar, SoilProfile

from app.core.tenant_mixin import TenantMixin

class Field(TenantMixin, Base):
    __tablename__ = "fields"
    id = Column(Integer, primary_key=True)
    farm_id = Column(Integer, ForeignKey("farms.id"), nullable=True)

    name = Column(String, nullable=False)
    boundary = Column(Geometry("POLYGON", srid=4326), nullable=False)
    area_ha = Column(Float, default=0)

    farm = relationship("Farm", back_populates="fields")
    satellite_images = relationship("SatelliteImage", back_populates="field")
    weather_records = relationship("WeatherRecord", back_populates="field", cascade="all,delete-orphan")
    satellite_indices = relationship("SatelliteIndexRecord", back_populates="field", cascade="all,delete-orphan")
    daily_states = relationship("FieldDailyState", back_populates="field", cascade="all,delete-orphan")
    crop_calendars = relationship("CropCalendar", back_populates="field", cascade="all,delete-orphan")
    soil_profile = relationship("SoilProfile", back_populates="field", uselist=False, cascade="all,delete-orphan")
    ndvi_results = relationship("NDVIResult", back_populates="field")