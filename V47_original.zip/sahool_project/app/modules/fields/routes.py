from app.modules.auth.deps import require_tenant
from fastapi import APIRouter, Depends, Depends, HTTPException
from sqlalchemy.orm import Session
from shapely.geometry import shape as shapely_shape, Polygon
from geoalchemy2.shape import from_shape, to_shape

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from .models import Field
from .schemas import FieldCreateByShape, FieldOut, CircleData, RectData, SemiCircleData, PolygonData
from .services.shapes import (
    circle_to_polygon, rectangle_to_polygon,
    semicircle_to_polygon, polygon_passthrough
)


@router.post("/", response_model=FieldOut)
def create_field(payload: FieldCreateByShape, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    try:
        if payload.shape == "circle":
            d: CircleData = payload.data  # type: ignore
            geojson = circle_to_polygon(d.center_lat, d.center_lon, d.radius_m, d.num_points or 64)
        elif payload.shape == "rectangle":
            d: RectData = payload.data  # type: ignore
            geojson = rectangle_to_polygon(d.lat1, d.lon1, d.lat2, d.lon2)
        elif payload.shape == "semicircle":
            d: SemiCircleData = payload.data  # type: ignore
            geojson = semicircle_to_polygon(d.center_lat, d.center_lon, d.radius_m, d.direction, d.num_points or 64)
        elif payload.shape == "polygon":
            d: PolygonData = payload.data  # type: ignore
            if d.geojson:
                geojson = polygon_passthrough(d.geojson)
            elif d.points and len(d.points) >= 3:
                pts = [(p.lon, p.lat) for p in d.points]
                pts.append(pts[0])
                geojson = Polygon(pts).__geo_interface__
            else:
                raise ValueError("Polygon requires geojson or >=3 points")
        else:
            raise ValueError("Unsupported shape")

        poly = shapely_shape(geojson)
        if not poly.is_valid or poly.area == 0:
            raise ValueError("Invalid polygon geometry")

    except ValueError as e:
        raise HTTPException(400, str(e))

    field = Field(tenant_id=tenant_id, 
        name=payload.name,
        boundary=from_shape(poly, srid=4326),
        area_ha=float(payload.area_ha or 0),
    )
    db.add(field)
    db.commit()
    db.refresh(field)

    return FieldOut(
        id=field.id,
        name=field.name,
        boundary_geojson=poly.__geo_interface__,
        area_ha=field.area_ha,
    )

@router.get("/{field_id}", response_model=FieldOut)
def get_field(field_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    field = db.get(Field, field_id)
    if not field:
        raise HTTPException(404, "Field not found")
    polygon = to_shape(field.boundary)
    return FieldOut(
        id=field.id,
        name=field.name,
        boundary_geojson=polygon.__geo_interface__,
        area_ha=field.area_ha
    )
from fastapi import APIRouter, Depends, Depends, HTTPException
import datetime as dt
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.modules.fields.models import Field
from app.modules.satellite.fused_models import FieldDailyState
from app.modules.alerts.service import get_recent_alerts
from app.modules.crops.soil_water import SoilWaterBalance

router = APIRouter(prefix="/fields", tags=["fields"])

@router.get("/{field_id}/health")
def field_health(field_id:int, days:int=30, db:Session=Depends(get_db), tenant_id:int=Depends(get_tenant_id_open)):
    field=db.query(Field).filter(Field.id==field_id, Field.tenant_id==tenant_id).first()
    if not field: raise HTTPException(404,"Field not found")
    start=dt.date.today()-dt.timedelta(days=days)
    states=(db.query(FieldDailyState)
              .filter(FieldDailyState.field_id==field_id,
                      FieldDailyState.tenant_id==tenant_id,
                      FieldDailyState.date>=start)
              .order_by(FieldDailyState.date.asc()).all())
    history=[]
    for s in states:
        sm = (db.query(SoilWaterBalance.soil_moisture_frac)
                .filter(SoilWaterBalance.field_id==field_id,
                        SoilWaterBalance.tenant_id==tenant_id,
                        SoilWaterBalance.date==s.date).scalar())
        history.append({
            "date": s.date.isoformat(),
            "ndvi": s.ndvi,
            "ndwi": s.ndwi,
            "temp_max_c": s.temp_max_c,
            "precip_sum_mm": s.precip_sum_mm,
            "water_stress": s.water_stress,
            "heat_stress": s.heat_stress,
            "vigor_score": s.vigor_score,
            "anomaly_score": s.anomaly_score,
            "stage": s.stage,
            "recommendation": s.recommendation,
            "yield_pred_kg_ha": (s.raw or {}).get("yield_pred_kg_ha"),
            "soil_moisture_frac": sm,
        })
    swb=(db.query(SoilWaterBalance)
           .filter(SoilWaterBalance.field_id==field_id,
                   SoilWaterBalance.tenant_id==tenant_id,
                   SoilWaterBalance.date>=start)
           .order_by(SoilWaterBalance.date.asc()).all())
    swb_series=[{
        "date": r.date.isoformat(),
        "soil_moisture_frac": r.soil_moisture_frac,
        "soil_moisture_mm": r.soil_moisture_mm,
        "et0_mm": r.et0_mm,
        "kc": r.kc,
        "crop_et_mm": r.crop_et_mm,
        "rain_mm": r.rain_mm,
        "irrigation_mm": r.irrigation_mm,
    } for r in swb]
    alerts=get_recent_alerts(db, field_id=field_id, tenant_id=tenant_id, days=days)
    return {"field_id":field_id,"field_name":field.name,"days":days,"today_state":history[-1] if history else None,"history":history,"alerts":alerts,"soil_water_balance":swb_series}
