from pydantic import BaseModel, Field as PydField
from typing import Any, Literal, Union, Optional, List

class CircleData(BaseModel):
    center_lat: float
    center_lon: float
    radius_m: float
    num_points: Optional[int] = 64

class RectData(BaseModel):
    # two opposite corners
    lat1: float
    lon1: float
    lat2: float
    lon2: float

class SemiCircleData(BaseModel):
    center_lat: float
    center_lon: float
    radius_m: float
    direction: Literal["up", "down", "left", "right"] = "up"
    num_points: Optional[int] = 64

class PointLatLon(BaseModel):
    lat: float
    lon: float

class PolygonData(BaseModel):
    # Accept either raw GeoJSON polygon or list of points
    geojson: Optional[dict] = None
    points: Optional[List[PointLatLon]] = None

class FieldCreateByShape(BaseModel):
    name: str
    area_ha: Optional[float] = 0
    shape: Literal["circle", "rectangle", "semicircle", "polygon"]
    data: Union[CircleData, RectData, SemiCircleData, PolygonData]

class FieldOut(BaseModel):
    id: int
    name: str
    boundary_geojson: Any
    area_ha: float

    class Config:
        from_attributes = True
