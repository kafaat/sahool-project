import os, datetime as dt
from dataclasses import dataclass
from typing import Optional, List, Dict, Any

import numpy as np
from sqlalchemy.orm import Session
from joblib import dump
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score

from app.modules.satellite.fused_models import FieldDailyState
from app.modules.alerts.models import Alert

MODEL_PATH=os.getenv("ANOMALY_MODEL_PATH","/code/storage/models/anomaly_model.joblib")

@dataclass
class TrainResult:
    n_samples:int
    auc: Optional[float]
    report: Dict[str, Any]
    model_path:str

def build_anomaly_dataset(db: Session, days:int=365):
    start=dt.date.today()-dt.timedelta(days=days)
    states=(db.query(FieldDailyState).filter(FieldDailyState.date>=start).all())
    alerts=(db.query(Alert.field_id, Alert.alert_type, Alert.created_at)
              .filter(Alert.created_at>=dt.datetime.combine(start, dt.time.min)).all())
    pos_types={"drought_risk","heat_stress","veg_anomaly"}
    alert_idx={(fid, created_at.date()) for fid,atype,created_at in alerts if atype in pos_types and created_at}

    X=[]; y=[]
    for s in states:
        X.append([s.ndvi or 0.0, s.ndwi or 0.0, s.precip_sum_mm or 0.0, s.temp_max_c or 0.0, s.water_stress or 0.0, s.heat_stress or 0.0])
        y.append(1 if (s.field_id, s.date) in alert_idx else 0)
    return np.array(X,dtype="float32"), np.array(y,dtype="int64")

def train_anomaly_model(db: Session, days:int=365)->TrainResult:
    X,y=build_anomaly_dataset(db,days)
    if len(y)<20 or len(set(y))<2:
        return TrainResult(len(y), None, {"warning":"not enough labeled data"}, MODEL_PATH)
    model=RandomForestClassifier(n_estimators=300, max_depth=8, random_state=42, class_weight="balanced_subsample")
    model.fit(X,y)
    proba=model.predict_proba(X)[:,1]
    auc=float(roc_auc_score(y,proba))
    report=classification_report(y, model.predict(X), output_dict=True)
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    dump(model, MODEL_PATH)
    return TrainResult(len(y), auc, report, MODEL_PATH)
