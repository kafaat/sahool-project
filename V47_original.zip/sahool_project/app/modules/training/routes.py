import datetime as dt
from typing import List, Dict
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.modules.training.anomaly_train import train_anomaly_model
from app.modules.training.yield_train import train_yield_model

router=APIRouter(prefix="/training", tags=["training"])

@router.post("/anomaly/train")
def anomaly_train(days:int=365, db:Session=Depends(get_db), tenant_id:int=Depends(get_tenant_id_open)):
    res=train_anomaly_model(db,days)
    return {"status":"ok", **res.__dict__}

@router.post("/yield/train")
def yield_train(payload: List[Dict], db:Session=Depends(get_db), tenant_id:int=Depends(get_tenant_id_open)):
    labeled=[]
    for row in payload:
        labeled.append({
            "field_id": int(row["field_id"]),
            "tenant_id": tenant_id,
            "season_start": dt.date.fromisoformat(row["season_start"]),
            "season_end": dt.date.fromisoformat(row["season_end"]),
            "actual_yield_kg_ha": float(row["actual_yield_kg_ha"]),
        })
    res=train_yield_model(db,labeled)
    return {"status":"ok", **res.__dict__}
