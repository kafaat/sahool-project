import os
from functools import lru_cache
from joblib import load

ANOMALY_MODEL_PATH=os.getenv("ANOMALY_MODEL_PATH","/code/storage/models/anomaly_model.joblib")
YIELD_MODEL_PATH=os.getenv("YIELD_MODEL_PATH","/code/storage/models/yield_model.joblib")

@lru_cache
def load_anomaly_model():
    return load(ANOMALY_MODEL_PATH) if os.path.exists(ANOMALY_MODEL_PATH) else None

@lru_cache
def load_yield_model():
    return load(YIELD_MODEL_PATH) if os.path.exists(YIELD_MODEL_PATH) else None
