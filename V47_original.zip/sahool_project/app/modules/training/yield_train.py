import os, datetime as dt
from dataclasses import dataclass
from typing import Optional, Dict, Any, List

import numpy as np
from joblib import dump
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sqlalchemy.orm import Session

from app.modules.satellite.fused_models import SatelliteIndexRecord
from app.modules.weather.models import WeatherRecord

MODEL_PATH=os.getenv("YIELD_MODEL_PATH","/code/storage/models/yield_model.joblib")

@dataclass
class YieldTrainResult:
    n_samples:int
    mae: Optional[float]
    r2: Optional[float]
    report: Dict[str, Any]
    model_path:str

def build_yield_features(db: Session, field_id:int, tenant_id:int, start:dt.date, end:dt.date):
    sat=(db.query(SatelliteIndexRecord.ndvi_mean)
           .filter(SatelliteIndexRecord.field_id==field_id,
                   SatelliteIndexRecord.tenant_id==tenant_id,
                   SatelliteIndexRecord.date>=start,
                   SatelliteIndexRecord.date<=end).all())
    ndvi_vals=[v[0] for v in sat if v and v[0] is not None]
    ndvi_integral=sum(ndvi_vals); ndvi_mean=float(np.mean(ndvi_vals)) if ndvi_vals else 0.0

    w=(db.query(WeatherRecord.temp_max_c, WeatherRecord.temp_min_c, WeatherRecord.precip_sum_mm)
         .filter(WeatherRecord.field_id==field_id,
                 WeatherRecord.tenant_id==tenant_id,
                 WeatherRecord.date>=start,
                 WeatherRecord.date<=end).all())
    tmax=[x[0] for x in w if x[0] is not None]; tmin=[x[1] for x in w if x[1] is not None]; rain=[x[2] for x in w if x[2] is not None]
    return [ndvi_integral, ndvi_mean, float(np.mean(tmax)) if tmax else 0.0, float(np.mean(tmin)) if tmin else 0.0, float(np.sum(rain)) if rain else 0.0]

def train_yield_model(db: Session, labeled_seasons: List[Dict])->YieldTrainResult:
    X=[]; y=[]
    for row in labeled_seasons:
        X.append(build_yield_features(db,row["field_id"],row["tenant_id"],row["season_start"],row["season_end"]))
        y.append(row["actual_yield_kg_ha"])
    if len(y)<5:
        return YieldTrainResult(len(y), None, None, {"warning":"need more labeled seasons"}, MODEL_PATH)
    X=np.array(X,dtype="float32"); y=np.array(y,dtype="float32")
    model=RandomForestRegressor(n_estimators=500,max_depth=10,random_state=42)
    model.fit(X,y)
    pred=model.predict(X)
    mae=float(mean_absolute_error(y,pred)); r2=float(r2_score(y,pred))
    os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
    dump(model, MODEL_PATH)
    return YieldTrainResult(len(y), mae, r2, {"features":["ndvi_integral","ndvi_mean","tmax_mean","tmin_mean","rain_sum"]}, MODEL_PATH)
