from sqlalchemy import Column, Integer, String, DateTime, JSON
from app.core.db import Base

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    event = Column(String(120), nullable=False)
    tenant_id = Column(Integer, nullable=True)
    user_id = Column(String(120), nullable=True)
    meta = Column(JSON, nullable=True)
    created_at = Column(DateTime, nullable=False)
