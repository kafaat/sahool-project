from fastapi import APIRouter, Depends
from redis import Redis
from app.core.config import settings
from app.modules.auth.deps import require_role, require_tenant
import time

router = APIRouter(prefix="/admin/usage", tags=["admin-usage"], dependencies=[Depends(require_role("admin.usage.read"))])

redis = Redis.from_url(settings.redis_url)

@router.get("/sentinel")
def sentinel_usage(tenant = Depends(require_tenant)):
    day = int(time.time()//86400)
    key = f"quota:{tenant['tenant_id']}:{day}"
    used = int(redis.get(key) or 0)
    limit = int(getattr(settings,'sentinel_daily_limit',200))
    return {"used_today": used, "limit": limit, "day": day}
