from fastapi import APIRouter, Depends
from redis import Redis
from app.core.config import settings
from app.modules.auth.deps import require_tenant, require_role
import time

router = APIRouter(prefix="/admin/usage", tags=["admin-usage-history"], dependencies=[Depends(require_role("admin.usage.read"))])
redis = Redis.from_url(settings.redis_url)

@router.get("/sentinel/history")
def sentinel_history(days: int = 7, tenant = Depends(require_tenant)):
    now_day = int(time.time()//86400)
    out=[]
    for d in range(days):
        day = now_day - d
        key = f"quota:{tenant['tenant_id']}:{day}"
        used = int(redis.get(key) or 0)
        out.append({"day": day, "used": used})
    out.reverse()
    return {"days": days, "series": out}
