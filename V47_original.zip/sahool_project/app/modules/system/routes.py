from fastapi import APIRouter
import time

router = APIRouter(prefix="/system", tags=["System"])

@router.get("/health")
def health():
    return {"status": "ok"}

@router.get("/info")
def info():
    return {
        "service": "Sahool Backend",
        "version": "1.0.0",
        "uptime": time.time()
    }
