from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from geoalchemy2.shape import to_shape
import math

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.modules.fields.models import Field
from app.modules.satellite.models import NDVIResult
from app.modules.satellite.services.hotspots import (
    extract_hotspots_points,
    compute_dynamic_threshold,
    read_ndvi_array
)

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

def compute_risk(latest_ndvi: float | None, prev_ndvi: float | None):
    if latest_ndvi is None:
        return 0, "no_data"
    delta = None if prev_ndvi is None else (latest_ndvi - prev_ndvi)
    d = delta if delta is not None else 0.0
    if latest_ndvi > 0.5 and d > -0.05:
        return 1, "normal"
    if latest_ndvi > 0.4 and d > -0.10:
        return 2, "watch"
    if latest_ndvi > 0.30 and d > -0.15:
        return 3, "risk_medium"
    if latest_ndvi > 0.20:
        return 4, "risk_high"
    return 5, "critical"

def safe_std_from_range(min_v, max_v):
    if min_v is None or max_v is None:
        return None
    # rough std estimate
    return (max_v - min_v) / 4.0

def compute_indicators(latest: NDVIResult | None, prev: NDVIResult | None, history: list[NDVIResult]):
    if not latest:
        return {
            "vsi": None, "wsi": None, "fui": None, "gm": None, "hss": None,
            "hotspot_density": None, "dynamic_threshold": None,
            "lst_mean": None, "wsi_lst": None, "dsi": None, "hsi": None, "rain_7d_mm": None
        }

    latest_ndvi = latest.mean_ndvi
    prev_ndvi = prev.mean_ndvi if prev else None
    delta = None if (latest_ndvi is None or prev_ndvi is None) else latest_ndvi - prev_ndvi

    # std from stats or rough range
    stats = latest.stats or {}
    std = stats.get("std_ndvi") or stats.get("std") or safe_std_from_range(latest.min_ndvi, latest.max_ndvi)
    mean = latest.mean_ndvi

    # dynamic threshold + hotspots from tif if available
    dyn_th = None
    h_points=[]
    if latest.ndvi_tif_path:
        try:
            arr, _, _ = read_ndvi_array(latest.ndvi_tif_path)
            dyn_th = compute_dynamic_threshold(arr, k=0.8)
            h_points = extract_hotspots_points(latest.ndvi_tif_path, threshold=None)  # dynamic
        except Exception:
            dyn_th = None
            h_points = []

    hotspot_density = (len(h_points) / 1000.0) if h_points else 0.0
    hss = (sum(p.get("weight",0.0) for p in h_points) / len(h_points)) if h_points else 0.0

    # VSI: 0..100 (higher better)
    vsi = None
    if mean is not None:
        d_pen = 0 if delta is None else max(0.0, -delta) * 100
        vs = (mean * 100) - d_pen - (hotspot_density * 50)
        vsi = max(0.0, min(100.0, vs))

    # WSI: NDVI-only proxy
    wsi = None
    if mean is not None:
        wsi = max(0.0, min(1.0, (1 - mean) * (1 + hotspot_density)))

    # LST optional integration (if present in stats)
    lst_mean = stats.get("lst_mean") or stats.get("LST_mean") or None
    wsi_lst = None
    # Weather-based indices if stats available
    rain_7d_mm = stats.get("rain_7d_mm") or None
    temp_mean_c = stats.get("temp_mean_c") or None
    dsi = None
    hsi = None
    if rain_7d_mm is not None and mean is not None:
        # higher means more drought stress
        dsi = max(0.0, min(1.0, (1-mean) * (1.0 - min(float(rain_7d_mm)/50.0,1.0))))
    if temp_mean_c is not None and mean is not None:
        # normalize 20..45C
        tnorm = max(0.0, min(1.0, (float(temp_mean_c)-20.0)/25.0))
        hsi = max(0.0, min(1.0, tnorm * (1-mean)))
    if lst_mean is not None and mean is not None:
        # normalize lst roughly 10..50C -> 0..1
        lst_n = max(0.0, min(1.0, (float(lst_mean) - 10.0) / 40.0))
        wsi_lst = max(0.0, min(1.0, 0.6 * wsi + 0.4 * lst_n))

    # FUI: uniformity
    fui = None
    if mean not in (None, 0) and std is not None:
        fui = max(0.0, min(1.0, 1 - (std / mean)))

    # GM: momentum over ~last 3-7 days using history
    gm = 0.0
    if history and latest_ndvi is not None:
        # take oldest within last 7 items (approx days) if exists
        base = history[-1]  # oldest in list
        base_ndvi = base.mean_ndvi
        if base_ndvi is not None:
            gm = latest_ndvi - base_ndvi
    elif delta is not None:
        gm = delta

    return {
        "vsi": vsi,
        "wsi": wsi,
        "fui": fui,
        "gm": gm,
        "hss": hss,
        "hotspot_density": hotspot_density,
        "dynamic_threshold": dyn_th,
        "lst_mean": lst_mean,
        "wsi_lst": wsi_lst,
            "dsi": dsi,
            "hsi": hsi,
            "rain_7d_mm": rain_7d_mm
    }

    latest_ndvi = latest.mean_ndvi
    prev_ndvi = prev.mean_ndvi if prev else None
    delta = None if (latest_ndvi is None or prev_ndvi is None) else latest_ndvi - prev_ndvi

    # std from stats or rough range
    stats = latest.stats or {}
    std = stats.get("std_ndvi") or stats.get("std") or safe_std_from_range(latest.min_ndvi, latest.max_ndvi)
    mean = latest.mean_ndvi

    # dynamic threshold from tif if available
    dyn_th = None
    h_points=[]
    if latest.ndvi_tif_path:
        try:
            arr, _, _ = read_ndvi_array(latest.ndvi_tif_path)
            dyn_th = compute_dynamic_threshold(arr, k=0.8)
            h_points = extract_hotspots_points(latest.ndvi_tif_path, threshold=None)  # dynamic
        except Exception:
            dyn_th = None
            h_points = []

    hotspot_density = (len(h_points) / 1000.0) if h_points else 0.0
    hss = (sum(p.get("weight",0.0) for p in h_points) / len(h_points)) if h_points else 0.0

    # VSI: 0..100 (higher better)
    vsi = None
    if mean is not None:
        d_pen = 0 if delta is None else max(0.0, -delta) * 100  # penalize drops
        vs = (mean * 100) - d_pen - (hotspot_density * 50)
        vsi = max(0.0, min(100.0, vs))

    # WSI: water stress proxy
    wsi = None
    if mean is not None:
        wsi = max(0.0, min(1.0, (1 - mean) * (1 + hotspot_density)))

    # FUI: uniformity
    fui = None
    if mean not in (None, 0) and std is not None:
        fui = max(0.0, min(1.0, 1 - (std / mean)))

    # GM: growth momentum (3-day proxy using prev)
    gm = delta if delta is not None else 0.0

    return {
        "vsi": vsi,
        "wsi": wsi,
        "fui": fui,
        "gm": gm,
        "hss": hss,
        "hotspot_density": hotspot_density,
        "dynamic_threshold": dyn_th
    }

@router.get("/data", summary="Dashboard data (fields + NDVI + risk + smart indicators)")
def dashboard_data(
    tenant_id: int = Depends(get_tenant_id_open),
    db: Session = Depends(get_db),
):
    fields = db.query(Field).filter(Field.tenant_id == tenant_id).all()
    out = []
    for f in fields:
        latest_two = (db.query(NDVIResult)
                        .filter(NDVIResult.field_id == f.id, NDVIResult.tenant_id == tenant_id)
                        .order_by(NDVIResult.processed_at.desc())
                        .limit(2).all())
        latest = latest_two[0] if len(latest_two) > 0 else None
        prev   = latest_two[1] if len(latest_two) > 1 else None
        latest_ndvi = latest.mean_ndvi if latest else None
        prev_ndvi   = prev.mean_ndvi if prev else None
        risk_level, risk_label = compute_risk(latest_ndvi, prev_ndvi)

        history = (db.query(NDVIResult)
                       .filter(NDVIResult.field_id == f.id, NDVIResult.tenant_id == tenant_id)
                       .order_by(NDVIResult.processed_at.desc())
                       .limit(7).all())
        ind = compute_indicators(latest, prev, list(reversed(history)))

        poly = to_shape(f.boundary) if f.boundary is not None else None
        out.append({
            "id": f.id,
            "name": f.name,
            "area_ha": f.area_ha,
            "boundary_geojson": poly.__geo_interface__ if poly else None,
            "latest_ndvi": latest_ndvi,
            "prev_ndvi": prev_ndvi,
            "delta_ndvi": None if (latest_ndvi is None or prev_ndvi is None) else latest_ndvi - prev_ndvi,
            "risk_level": risk_level,
            "risk_label": risk_label,
            "latest_ndvi_id": latest.id if latest else None,

            # smart indicators
            **ind
        })
    return {"tenant_id": tenant_id, "items": out}