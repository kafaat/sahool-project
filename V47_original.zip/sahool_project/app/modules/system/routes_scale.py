from fastapi import APIRouter
from app.workers.celery_app import celery

router = APIRouter(prefix="/system", tags=["system"])

@router.get("/queue")
def queue_length():
    insp = celery.control.inspect()
    active = insp.active() or {}
    reserved = insp.reserved() or {}
    total = sum(len(v) for v in active.values()) + sum(len(v) for v in reserved.values())
    return {"queued_or_active": total}

@router.post("/scale")
def scale_hint(target_replicas: int):
    return {"recommended_replicas": target_replicas, "note": "apply scaling in orchestrator"}
