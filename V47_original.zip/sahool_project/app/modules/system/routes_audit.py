from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.system.models import AuditLog
from app.modules.auth.deps import require_role, require_tenant

router = APIRouter(prefix="/admin/audit", tags=["admin-audit"], dependencies=[Depends(require_role("admin.audit.read"))])

@router.get("")
def list_audit(tenant = Depends(require_tenant), limit: int = 200, db: Session = Depends(get_db)):
    rows = db.query(AuditLog).filter(
        (AuditLog.tenant_id==tenant["tenant_id"]) | (AuditLog.tenant_id==None)
    ).order_by(AuditLog.id.desc()).limit(limit).all()
    return {"items":[{"id":a.id,"event":a.event,"user_id":a.user_id,"meta":a.meta,"created_at":a.created_at} for a in rows]}
