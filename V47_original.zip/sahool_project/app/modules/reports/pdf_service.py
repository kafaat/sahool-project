from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from io import BytesIO
from datetime import datetime

def build_field_report_pdf(field, ndvi_results, alerts):
    buff = BytesIO()
    c = canvas.Canvas(buff, pagesize=A4)
    w, h = A4

    c.setFont("Helvetica-Bold", 16)
    c.drawString(40, h-50, "Sahool Farmonaut Report")

    c.setFont("Helvetica", 10)
    c.drawString(40, h-70, f"Field: {field.name} (ID {field.id})")
    c.drawString(40, h-85, f"Generated: {datetime.utcnow().isoformat()}Z")

    y = h-115
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40, y, "Latest NDVI / Indices")
    y -= 18
    c.setFont("Helvetica", 10)

    if ndvi_results:
        r = ndvi_results[0]
        s = r.stats or {}
        c.drawString(40, y, f"NDVI mean/min/max: {r.mean_ndvi} / {r.min_ndvi} / {r.max_ndvi}")
        y -= 14
        for k in ["ndre_mean","gndvi_mean","savi_mean","evi_mean","ndwi_mean"]:
            if k in s and s[k] is not None:
                c.drawString(55, y, f"{k.replace('_',' ').upper()}: {s[k]}")
                y -= 12
    else:
        c.drawString(40, y, "No NDVI results yet.")
        y -= 14

    y -= 6
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40, y, "Recent Alerts")
    y -= 18
    c.setFont("Helvetica", 10)
    if alerts:
        for a in alerts[:8]:
            c.drawString(40, y, f"- {a.level.upper()} | {a.message} | {a.created_at.date().isoformat()}")
            y -= 12
            if y < 80:
                c.showPage()
                y = h-80
    else:
        c.drawString(40, y, "No alerts.")

    c.showPage()
    c.save()
    buff.seek(0)
    return buff.getvalue()


def _add_legend_table(c, index_name, x, y):
    from app.modules.satellite.services.legend import get_ranges
    ranges=get_ranges(index_name)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(x, y, f"Legend: {index_name.upper()}")
    c.setFont("Helvetica", 8)
    yy=y-12
    for a,b,l in ranges:
        c.drawString(x, yy, f"{l}: {a} → {b}")
        yy -= 10
