from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from app.modules.agro_intel.service import build_agro_ai
from .agro_pdf import build_agro_report

router = APIRouter(
    prefix="/reports",
    tags=["Reports"],
    dependencies=[Depends(require_tenant), Depends(require_role("agro.read"))],
)

@router.get("/agro.pdf", summary="Advanced agro PDF report", description="Generate a multi-page PDF combining NDVI stress, soil suitability, weather, risks, and irrigation plan.")
async def agro_pdf(field_id: int, crop: str, stage: str="mid", db: Session=Depends(get_db), tenant=Depends(require_tenant)):
    data = await build_agro_ai(field_id, crop, stage, db, tenant["tenant_id"])
    if "error" in data:
        return data
    pdf = build_agro_report({**data, "crop": crop, "stage": stage})
    return Response(content=pdf, media_type="application/pdf")
