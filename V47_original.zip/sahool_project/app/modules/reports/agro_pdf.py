from __future__ import annotations
from typing import Dict, Any, List
from io import BytesIO
import datetime, math

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors

def _title(c, text, y):
    c.setFont("Helvetica-Bold", 16); c.drawString(40,y,text); return y-28

def _section(c, text, y):
    c.setFont("Helvetica-Bold", 12); c.drawString(40,y,text); return y-18

def _kv(c, k, v, y, x=46):
    c.setFont("Helvetica", 10); c.drawString(x,y,f"{k}: {v}"); return y-14

def _bar(c, x, y, w, h, frac, col):
    c.setFillColor(col); c.rect(x,y,w*frac,h, fill=1, stroke=0)
    c.setStrokeColor(colors.black); c.rect(x,y,w,h, fill=0, stroke=1)

def _page_break_if_needed(c, y):
    if y < 80:
        c.showPage()
        return A4[1]-60
    return y

def build_agro_report(data: Dict[str,Any]) -> bytes:
    buf=BytesIO()
    c=canvas.Canvas(buf, pagesize=A4)
    W,H=A4
    y=H-60

    field=data.get("field",{})
    crop=data.get("crop"); stage=data.get("stage"); kc=data.get("kc")
    ndvi=data.get("ndvi_stress",{}) or {}
    soil=data.get("soil",{}) or {}
    weather=data.get("weather",{}) or {}
    pest=data.get("pest_risk",{}) or {}
    disease=data.get("disease_risk",{}) or {}
    zones=data.get("zones_yield") or data.get("zones") or []

    # Page 1: Overview + stress bars
    y=_title(c,"Sahool Agro Report", y)
    y=_kv(c,"Date", datetime.date.today().isoformat(), y)
    y=_kv(c,"Field", f"{field.get('name')} (ID {field.get('id')})", y)
    y=_kv(c,"Crop/Stage", f"{crop}/{stage}", y)
    y=_kv(c,"Kc", kc, y)
    y-=8
    y=_section(c,"NDVI Stress Summary", y)
    total=sum(float(v or 0) for v in ndvi.values()) or 1.0
    for level, col in [("high", colors.red), ("moderate", colors.orange), ("low", colors.green)]:
        frac=float(ndvi.get(level) or 0)/total
        c.setFont("Helvetica",10); c.drawString(46,y,f"{level}: {frac*100:.1f}%")
        _bar(c,160,y-8,260,10,frac,col)
        y-=18
    y-=4

    # Zone yield quick table
    y=_section(c,"Zones Yield (quick)", y)
    for z in zones:
        lvl=z.get("level")
        area=z.get("area_fraction") or 0
        pred=z.get("predicted_t_ha") or ""
        y=_kv(c,f"{lvl}", f"area {area*100:.1f}%  pred {pred} t/ha", y)
    y=_page_break_if_needed(c,y)

    # Page 2: Soil
    y=_title(c,"Soil Report", y)
    suit=soil.get("suitability") or soil.get("report") or {}
    analysis=soil.get("analysis") or {}
    spatial=soil.get("spatial_sample_center") or {}
    y=_section(c,"Suitability", y)
    for k in ["overall","ph_status","salinity_status","som_status"]:
        if k in suit: y=_kv(c,k,suit[k],y)
    y-=6
    y=_section(c,"Analysis", y)
    for k in ["soil_health_score","salinity_class","awc_mm_m","irrigation_frequency_days"]:
        if k in analysis: y=_kv(c,k,analysis[k],y)
    y-=6
    y=_section(c,"Spatial Sample (center)", y)
    for k,v in spatial.items():
        y=_kv(c,k, (f"{v:.2f}" if isinstance(v,(float,int)) else v), y)
    y=_page_break_if_needed(c,y)

    # Page 3: Weather + pests/diseases
    y=_title(c,"Weather & Risks", y)
    alerts=weather.get("alerts") or {}
    deficit=(alerts.get("deficit") or {}).get("deficit_mm")
    y=_section(c,"Weather Summary", y)
    for k in ["tmin","tmax","tmean","eto","rain_sum"]:
        if k in weather: y=_kv(c,k,weather[k],y)
    if deficit is not None: y=_kv(c,"water_deficit_mm_7d", deficit, y)
    y-=6
    y=_section(c,"Pest Risk", y)
    if pest:
        y=_kv(c,"level", pest.get("level"), y)
        for n in pest.get("notes",[])[:5]:
            y=_kv(c,"note", n, y, x=60)
    y-=6
    y=_section(c,"Disease Risk", y)
    if disease:
        y=_kv(c,"overall", f"{disease.get('overall_level')} ({disease.get('overall_score')})", y)
        for d in (disease.get("diseases") or [])[:6]:
            y=_kv(c,d.get("disease"), f"{d.get('level')} ({d.get('score')})", y, x=60)
    y=_page_break_if_needed(c,y)

    # Page 4: Irrigation plan
    y=_title(c,"Irrigation Plan", y)
    irr=weather.get("irrigation") or weather.get("plan") or {}
    plan=(irr.get("plan_7d") or irr.get("plan") or [])
    if plan:
        for p in plan[:14]:
            d=p.get("date"); mm=p.get("mm")
            y=_kv(c,d, f"{mm} mm", y)
            y=_page_break_if_needed(c,y)
    else:
        y=_kv(c,"plan","No irrigation plan available", y)

    c.showPage()
    c.save()
    return buf.getvalue()
