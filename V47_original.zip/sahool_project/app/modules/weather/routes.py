from fastapi import APIRouter, Depends
from app.modules.auth.deps import require_role, require_tenant
from .service import get_live_weather, get_history_weather, get_irrigation, get_irrigation_zones, get_daily_forecast, get_agro_summary, get_agro_alerts, get_vpd, get_irrigation_plan

router = APIRouter(prefix="/weather", tags=["weather"], dependencies=[Depends(require_tenant), Depends(require_role("weather.read"))])

@router.get("/live")
async def live(lat: float, lon: float):
    return await get_live_weather(lat, lon)

@router.get("/history")
async def history(lat: float, lon: float, start: str, end: str):
    return await get_history_weather(lat, lon, start, end)

@router.get("/irrigation")
async def irrigation(lat: float, lon: float, crop: str, stage: str="mid"):
    return await get_irrigation(lat, lon, crop, stage)


@router.get("/irrigation-zones")
async def irrigation_zones(field_id: int, crop: str, stage: str="mid"):
    return await get_irrigation_zones(field_id, crop, stage)


@router.get("/daily")
async def daily(lat: float, lon: float, days: int = 7):
    return await get_daily_forecast(lat, lon, days)

@router.get("/agro-summary")
async def agro_summary(lat: float, lon: float, crop: str, stage: str="mid"):
    return await get_agro_summary(lat, lon, crop, stage)


@router.get("/alerts")
async def agro_alerts(lat: float, lon: float, crop: str, stage: str="mid"):
    return await get_agro_alerts(lat, lon, crop, stage)

@router.get("/vpd")
async def vpd(lat: float, lon: float):
    return await get_vpd(lat, lon)

@router.get("/plan")
async def irrigation_plan(lat: float, lon: float, crop: str, stage: str="mid", days: int = 14, eff: float = 0.8):
    return await get_irrigation_plan(lat, lon, crop, stage, days, eff)
