from __future__ import annotations
from typing import Dict, Any, List
from .et0_full import ET0Inputs, et0_fao56_full
import datetime, math

def summarize_open_meteo(payload: Dict[str, Any]) -> Dict[str, Any]:
    hourly = payload.get("hourly", {})
    times = hourly.get("time", [])
    if not times:
        return {}
    i = len(times) - 1

    t = float((hourly.get("temperature_2m") or [0])[i] or 0.0)
    rh = float((hourly.get("relativehumidity_2m") or [0])[i] or 0.0)
    wind = float((hourly.get("windspeed_10m") or [0])[i] or 0.0)
    sw = float((hourly.get("shortwave_radiation") or [0])[i] or 0.0)
    rain = float((hourly.get("precipitation") or [0])[i] or 0.0)

    rad_mj = max(sw, 0.0) * 0.0864
    doy = datetime.datetime.utcnow().timetuple().tm_yday
    et0 = et0_fao56_full(ET0Inputs(
        lat_deg=float(payload.get("latitude", 0.0)),
        elevation_m=0.0,
        doy=doy,
        tmin_c=t, tmax_c=t,
        rh_mean_pct=rh,
        wind_ms=wind,
        rs_mj_m2_day=rad_mj
    ))
    sunshine_hours = sum(1 for v in (hourly.get("shortwave_radiation") or []) if v and v > 120)

    return {
        "time": times[i],
        "temperature": t,
        "humidity": rh,
        "wind_speed": wind,
        "solar_radiation": sw,
        "precipitation": rain,
        "et0": float(et0),
        "sunshine_hours": float(sunshine_hours)
    }

def daily_forecast_from_payload(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    daily = payload.get("daily", {})
    times = daily.get("time", []) or []
    tmax = daily.get("temperature_2m_max", []) or []
    tmin = daily.get("temperature_2m_min", []) or []
    rain = daily.get("precipitation_sum", []) or []
    sw = daily.get("shortwave_radiation_sum", []) or []
    et0s = daily.get("et0_fao_evapotranspiration", []) or []

    out=[]
    for i,dt in enumerate(times):
        out.append({
            "date": dt,
            "tmax": tmax[i] if i < len(tmax) else None,
            "tmin": tmin[i] if i < len(tmin) else None,
            "rain_sum": rain[i] if i < len(rain) else None,
            "solar_sum": sw[i] if i < len(sw) else None,
            "et0": et0s[i] if i < len(et0s) else None,
        })
    return out

def compute_gdd_series(points: List[Dict[str, Any]], base_temp_c: float = 10.0) -> List[Dict[str, Any]]:
    # growing degree days cumulative
    cum=0.0
    out=[]
    for p in points:
        tmin=p.get("tmin"); tmax=p.get("tmax")
        if tmin is None or tmax is None:
            gdd=0.0
        else:
            tmean=(float(tmax)+float(tmin))/2.0
            gdd=max(0.0, tmean-base_temp_c)
        cum+=gdd
        out.append({**p, "gdd": gdd, "gdd_cum": cum})
    return out
