from __future__ import annotations
import math, datetime
from typing import Dict, Any, List

def saturation_vapor_pressure_kpa(t_c: float) -> float:
    return 0.6108 * math.exp((17.27 * t_c) / (t_c + 237.3))

def vpd_kpa(t_c: float, rh_pct: float) -> float:
    es = saturation_vapor_pressure_kpa(t_c)
    ea = es * (rh_pct / 100.0)
    return max(0.0, es - ea)

def heat_risk(tmax_c: float|None) -> str:
    if tmax_c is None: return "unknown"
    if tmax_c >= 40: return "extreme"
    if tmax_c >= 35: return "high"
    if tmax_c >= 30: return "moderate"
    return "low"

def frost_risk(tmin_c: float|None) -> str:
    if tmin_c is None: return "unknown"
    if tmin_c <= 0: return "extreme"
    if tmin_c <= 2: return "high"
    if tmin_c <= 5: return "moderate"
    return "low"

def rolling_deficit(daily_points: List[Dict[str,Any]], window_days:int=7) -> Dict[str,Any]:
    # deficit = cum(et0) - cum(rain)
    pts=daily_points[-window_days:] if len(daily_points)>window_days else daily_points
    et0=sum(float(p.get("et0") or 0) for p in pts)
    rain=sum(float(p.get("rain_sum") or 0) for p in pts)
    return {"window_days": window_days, "et0_sum": et0, "rain_sum": rain, "deficit_mm": max(0.0, et0-rain)}

def irrigation_plan_14d(daily_points: List[Dict[str,Any]], kc: float, eff: float=0.8) -> List[Dict[str,Any]]:
    plan=[]
    for p in daily_points[:14]:
        et0=float(p.get("et0") or 0.0)
        rain=float(p.get("rain_sum") or 0.0)
        net= max(0.0, et0*kc - rain)
        gross = net/eff if eff>0 else net
        plan.append({**p, "kc": kc, "net_irrigation_mm": net, "gross_irrigation_mm": gross})
    return plan
