from __future__ import annotations
import math
from dataclasses import dataclass

@dataclass
class ET0Inputs:
    lat_deg: float
    elevation_m: float
    doy: int
    tmin_c: float
    tmax_c: float
    rh_mean_pct: float
    wind_ms: float
    rs_mj_m2_day: float
    albedo: float = 0.23

def _sat_vp(t: float) -> float:
    return 0.6108 * math.exp((17.27*t)/(t+237.3))

def et0_fao56_full(inp: ET0Inputs) -> float:
    lat = math.radians(inp.lat_deg)
    tmean = (inp.tmin_c + inp.tmax_c)/2.0
    dr = 1 + 0.033*math.cos(2*math.pi/365*inp.doy)
    delta = 0.409*math.sin(2*math.pi/365*inp.doy - 1.39)
    ws = math.acos(-math.tan(lat)*math.tan(delta))
    Gsc = 0.0820
    Ra = (24*60/math.pi)*Gsc*dr*(ws*math.sin(lat)*math.sin(delta) + math.cos(lat)*math.cos(delta)*math.sin(ws))
    Rso = (0.75 + 2e-5*inp.elevation_m)*Ra
    Rns = (1-inp.albedo)*inp.rs_mj_m2_day
    sigma=4.903e-9
    ea = (inp.rh_mean_pct/100.0)*_sat_vp(tmean)
    Rnl = sigma * (((inp.tmax_c+273.16)**4 + (inp.tmin_c+273.16)**4)/2) * (0.34 - 0.14*math.sqrt(max(ea,1e-6))) * (1.35*min(inp.rs_mj_m2_day/max(Rso,1e-6),1.0) - 0.35)
    Rn = Rns - Rnl
    es = (_sat_vp(inp.tmax_c)+_sat_vp(inp.tmin_c))/2.0
    ea = (inp.rh_mean_pct/100.0)*es
    delta_slope = 4098*es/((tmean+237.3)**2)
    p=101.3*(((293-0.0065*inp.elevation_m)/293)**5.26)
    gamma=0.000665*p
    et0=(0.408*delta_slope*(Rn) + gamma*(900/(tmean+273))*inp.wind_ms*(es-ea))/(delta_slope + gamma*(1+0.34*inp.wind_ms))
    return max(et0,0.0)
