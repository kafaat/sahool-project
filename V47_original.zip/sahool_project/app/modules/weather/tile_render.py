from __future__ import annotations
import io, math, time, asyncio
from typing import Tuple, Dict, Any
import numpy as np
from PIL import Image
from redis import Redis
from tenacity import retry, stop_after_attempt, wait_fixed
from app.core.config import settings
from .providers.open_meteo import fetch_open_meteo
from .et0_full import ET0Inputs, et0_fao56_full

redis = Redis.from_url(settings.redis_url)
TILE_SIZE=256

def _tile_bounds(z:int,x:int,y:int)->Tuple[float,float,float,float]:
    n=2.0**z
    lon_min=x/n*360.0-180.0
    lon_max=(x+1)/n*360.0-180.0
    def lat_from_y(yy):
        lat_rad=math.atan(math.sinh(math.pi*(1-2*yy/n)))
        return math.degrees(lat_rad)
    lat_max=lat_from_y(y); lat_min=lat_from_y(y+1)
    return lat_min, lat_max, lon_min, lon_max

def _colorize(val,vmin,vmax):
    if vmax<=vmin: vmax=vmin+1
    t=max(0.0,min(1.0,(val-vmin)/(vmax-vmin)))
    if t<0.33:
        k=t/0.33; r=0; g=int(80*k); b=int(200+55*k)
    elif t<0.66:
        k=(t-0.33)/0.33; r=int(200*k); g=int(80+175*k); b=int(255-255*k)
    else:
        k=(t-0.66)/0.34; r=255; g=int(255-155*k); b=0
    return r,g,b,180

@retry(stop=stop_after_attempt(3), wait=wait_fixed(0.8))
async def _fetch_point(lat,lon):
    return await fetch_open_meteo(lat,lon)

async def _grid(lat_min,lat_max,lon_min,lon_max,step,metric):
    lats=np.arange(lat_min,lat_max+1e-9,step)
    lons=np.arange(lon_min,lon_max+1e-9,step)
    tasks=[_fetch_point(float(la),float(lo)) for la in lats for lo in lons]
    payloads=await asyncio.gather(*tasks, return_exceptions=True)
    vals=[]; idx=0; doy=time.gmtime().tm_yday
    for la in lats:
        row=[]
        for lo in lons:
            pay=payloads[idx]; idx+=1
            if isinstance(pay,Exception):
                row.append(float("nan")); continue
            h=pay.get("hourly",{})
            sw=float((h.get("shortwave_radiation") or [0])[-1] or 0.0)
            t=float((h.get("temperature_2m") or [0])[-1] or 0.0)
            rh=float((h.get("relativehumidity_2m") or [0])[-1] or 0.0)
            wind=float((h.get("windspeed_10m") or [0])[-1] or 0.0)
            rad_mj=max(sw,0.0)*0.0864
            if metric=="solar": row.append(sw)
            else:
                et0=et0_fao56_full(ET0Inputs(lat_deg=float(la), elevation_m=0.0, doy=doy, tmin_c=t, tmax_c=t, rh_mean_pct=rh, wind_ms=wind, rs_mj_m2_day=rad_mj))
                row.append(float(et0))
        vals.append(row)
    return np.array(vals,dtype=float)

async def render_tile(metric,z,x,y,step_deg=0.05)->bytes:
    day=int(time.time()//86400)
    key=f"weather_tile:{metric}:{z}:{x}:{y}:{day}"
    c=redis.get(key)
    if c: return c
    lat_min,lat_max,lon_min,lon_max=_tile_bounds(z,x,y)
    arr=await _grid(lat_min,lat_max,lon_min,lon_max,step_deg,metric)
    if not arr.size:
        img=Image.new("RGBA",(TILE_SIZE,TILE_SIZE),(0,0,0,0))
    else:
        vmin=float(np.nanmin(arr)); vmax=float(np.nanmax(arr))
        h,w=arr.shape
        img=Image.new("RGBA",(TILE_SIZE,TILE_SIZE)); px=img.load()
        for iy in range(TILE_SIZE):
            for ix in range(TILE_SIZE):
                gy=int(iy/(TILE_SIZE-1)*(h-1)) if h>1 else 0
                gx=int(ix/(TILE_SIZE-1)*(w-1)) if w>1 else 0
                v=float(arr[gy,gx])
                px[ix,iy]=(0,0,0,0) if math.isnan(v) else _colorize(v,vmin,vmax)
    buf=io.BytesIO(); img.save(buf, format="PNG", optimize=True)
    out=buf.getvalue(); redis.setex(key,3600,out); return out

async def render_solar_tile(z,x,y,step_deg=0.05): return await render_tile("solar",z,x,y,step_deg)
async def render_et0_tile(z,x,y,step_deg=0.05): return await render_tile("et0",z,x,y,step_deg)
