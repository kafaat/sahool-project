from __future__ import annotations
from dataclasses import dataclass

@dataclass
class CropKc:
    name: str
    kc_initial: float
    kc_mid: float
    kc_end: float

CROPS = {
    "wheat": CropKc("wheat", 0.4, 1.15, 0.25),
    "corn": CropKc("corn", 0.3, 1.2, 0.6),
    "rice": CropKc("rice", 1.05, 1.2, 0.9),
    "tomato": CropKc("tomato", 0.6, 1.15, 0.8),
    "cotton": CropKc("cotton", 0.35, 1.15, 0.65),
}

def kc_for_stage(crop: str, stage: str="mid") -> float:
    c=CROPS.get(crop.lower())
    if not c: return 1.0
    return {"initial":c.kc_initial,"mid":c.kc_mid,"end":c.kc_end}.get(stage,c.kc_mid)

def water_need_mm(et0_mm: float, crop: str, stage: str="mid") -> float:
    return et0_mm * kc_for_stage(crop, stage)
