import json
from __future__ import annotations
from typing import Dict, Any, List
from redis import Redis
from app.core.config import settings
from .providers.open_meteo import fetch_open_meteo
from .providers.nasa_power import fetch_nasa_power
from .processor import summarize_open_meteo, daily_forecast_from_payload, compute_gdd_series
from .derived import vpd_kpa, heat_risk, frost_risk, rolling_deficit, irrigation_plan_14d
from .kc import get_kc
from .irrigation import recommend_irrigation

redis = Redis.from_url(settings.redis_url)

async def get_live_weather(lat: float, lon: float) -> Dict[str, Any]:
    key=f"weather:live:{lat:.4f}:{lon:.4f}"
    cached=redis.get(key)
    if cached:
        return json.loads(cached)
    payload = await fetch_open_meteo(
        lat, lon,
        hourly="temperature_2m,relativehumidity_2m,windspeed_10m,shortwave_radiation,precipitation,cloudcover"
    )
    summary = summarize_open_meteo(payload)
    out={"raw": payload, "summary": summary}
    redis.setex(key, 900, json.dumps(out))
    return out

async def get_daily_forecast(lat: float, lon: float, days: int = 7) -> Dict[str, Any]:
    key=f"weather:daily:{lat:.4f}:{lon:.4f}:{days}"
    cached=redis.get(key)
    if cached:
        return json.loads(cached)
    payload = await fetch_open_meteo(
        lat, lon,
        hourly="temperature_2m",
        daily="temperature_2m_max,temperature_2m_min,precipitation_sum,shortwave_radiation_sum,et0_fao_evapotranspiration",
    )
    points = daily_forecast_from_payload(payload)[:days]
    gdd_points = compute_gdd_series(points)
    out={"points": gdd_points}
    redis.setex(key, 3600, json.dumps(out))
    return out

async def get_history_weather(lat: float, lon: float, start: str, end: str) -> Dict[str, Any]:
    payload = await fetch_nasa_power(lat, lon, start, end)
    props = payload.get("properties", {}).get("parameter", {})
    dates = sorted(props.get("T2M", {}).keys())
    points: List[Dict[str, Any]]=[]
    for d in dates:
        if d < start.replace("-","") or d > end.replace("-",""):
            continue
        points.append({
            "date": f"{d[:4]}-{d[4:6]}-{d[6:]}",
            "t2m": props.get("T2M", {}).get(d),
            "rh2m": props.get("RH2M", {}).get(d),
            "wind10m": props.get("WS10M", {}).get(d),
            "solar": props.get("ALLSKY_SFC_SW_DWN", {}).get(d),
            "rain": props.get("PRECTOTCORR", {}).get(d),
        })
    return {"raw": payload, "points": points, "start": start, "end": end}

async def get_irrigation(lat: float, lon: float, crop: str, stage: str="mid") -> Dict[str, Any]:
    live = await get_live_weather(lat, lon)
    et0=float(live.get("summary",{}).get("et0",0.0))
    hourly=live.get("raw",{}).get("hourly",{})
    effective_rain=float((hourly.get("precipitation") or [0])[-1] or 0.0)
    rec=recommend_irrigation(et0, crop, stage, effective_rain)
    return {"live": live.get("summary"), "recommendation": rec}

async def get_agro_summary(lat: float, lon: float, crop: str, stage: str="mid") -> Dict[str, Any]:
    live = await get_live_weather(lat, lon)
    daily = await get_daily_forecast(lat, lon, days=7)
    irrig = await get_irrigation(lat, lon, crop, stage)
    return {
        "live": live.get("summary"),
        "daily": daily.get("points", []),
        "irrigation": irrig.get("recommendation")
    }

# irrigation zones added in phase25 stays appended below if present


async def get_agro_alerts(lat: float, lon: float, crop: str, stage: str="mid") -> Dict[str, Any]:
    daily = await get_daily_forecast(lat, lon, days=7)
    points = daily.get("points", [])
    if not points:
        return {"alerts": []}
    tmax_next = points[0].get("tmax")
    tmin_next = points[0].get("tmin")
    alerts=[]
    hr = heat_risk(float(tmax_next) if tmax_next is not None else None)
    fr = frost_risk(float(tmin_next) if tmin_next is not None else None)
    if hr in ("high","extreme"):
        alerts.append({"type":"heat","level":hr,"message":"Heat risk in next 24h"})
    if fr in ("high","extreme"):
        alerts.append({"type":"frost","level":fr,"message":"Frost risk in next 24h"})
    deficit = rolling_deficit(points, window_days=7)
    if deficit["deficit_mm"] > 15:
        alerts.append({"type":"water_deficit","level":"high","message":"7-day water deficit is high", "deficit_mm": deficit["deficit_mm"]})
    return {"alerts": alerts, "deficit": deficit}

async def get_vpd(lat: float, lon: float) -> Dict[str, Any]:
    live = await get_live_weather(lat, lon)
    s = live.get("summary", {})
    return {"time": s.get("time"), "vpd_kpa": s.get("vpd_kpa"), "temperature": s.get("temperature"), "humidity": s.get("humidity")}

async def get_irrigation_plan(lat: float, lon: float, crop: str, stage: str="mid", days:int=14, eff: float=0.8) -> Dict[str, Any]:
    daily = await get_daily_forecast(lat, lon, days=max(days,7))
    points = daily.get("points", [])
    kc = get_kc(crop, stage)
    plan = irrigation_plan_14d(points, kc=kc, eff=eff)[:days]
    return {"kc": kc, "efficiency": eff, "plan": plan}
