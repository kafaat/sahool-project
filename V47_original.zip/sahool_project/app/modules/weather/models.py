import datetime as dt
from sqlalchemy import Column, Integer, Date, Float, ForeignKey, UniqueConstraint, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.db import Base
from app.core.tenant_mixin import TenantMixin

class WeatherRecord(TenantMixin, Base):
    __tablename__ = "weather_records"
    __table_args__ = (
        UniqueConstraint("tenant_id", "field_id", "date", name="uq_weather_field_date"),
    )

    id = Column(Integer, primary_key=True)
    field_id = Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)

    date = Column(Date, index=True, nullable=False)
    created_at = Column(DateTime, default=dt.datetime.utcnow)

    temp_max_c = Column(Float)
    temp_min_c = Column(Float)
    precip_sum_mm = Column(Float)
    wind_max_kmh = Column(Float)
    uv_max = Column(Float)

    temp_current_c = Column(Float)
    humidity_current_pct = Column(Float)
    wind_current_kmh = Column(Float)
    precip_current_mm = Column(Float)
    cloud_cover_current_pct = Column(Float)

    raw = Column(JSON, default=dict)

    field = relationship("Field", back_populates="weather_records")
