from .kc import get_kc
from __future__ import annotations
from typing import Dict, Any
from .crops import water_need_mm

def recommend_irrigation(et0_mm: float, crop: str, stage: str="mid", effective_rain_mm: float = 0.0) -> Dict[str, Any]:
    need = water_need_mm(et0_mm, crop, stage)
    net_need = max(need - effective_rain_mm, 0.0)
    m3_per_ha = net_need * 10.0
    return {
        "crop": crop, "stage": stage,
        "et0_mm": et0_mm,
        "kc_need_mm": need,
        "effective_rain_mm": effective_rain_mm,
        "net_irrigation_mm": net_need,
        "m3_per_ha": m3_per_ha
    }
