from fastapi import APIRouter, Depends, Response
from app.modules.auth.deps import require_role, require_tenant
from .tile_render import render_solar_tile, render_et0_tile

router = APIRouter(prefix="/weather/tiles", tags=["weather-tiles"], dependencies=[Depends(require_tenant), Depends(require_role("weather.read"))])

@router.get("/solar/{z}/{x}/{y}.png")
async def solar_tile(z:int,x:int,y:int):
    return Response(content=await render_solar_tile(z,x,y), media_type="image/png")

@router.get("/et0/{z}/{x}/{y}.png")
async def et0_tile(z:int,x:int,y:int):
    return Response(content=await render_et0_tile(z,x,y), media_type="image/png")
