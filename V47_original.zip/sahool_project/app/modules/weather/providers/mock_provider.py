
async def mock_fetch_open_meteo(lat, lon, hourly=None, daily=None, past_days=None):
    # supports both hourly and daily mock
    payload = {
        "latitude": lat,
        "longitude": lon,
        "hourly": {
            "time": ["2025-01-01T00:00"],
            "temperature_2m": [22.5],
            "relativehumidity_2m": [55.0],
            "windspeed_10m": [3.2],
            "shortwave_radiation": [750.0],
            "precipitation": [0.0],
            "cloudcover": [20.0]
        }
    }
    if daily:
        payload["daily"] = {
            "time": ["2025-01-01","2025-01-02","2025-01-03"],
            "temperature_2m_max": [25,26,24],
            "temperature_2m_min": [15,16,14],
            "precipitation_sum": [0,1.2,0],
            "shortwave_radiation_sum": [18,17,19],
            "et0_fao_evapotranspiration": [4.1,4.3,3.9],
        }
    return payload
