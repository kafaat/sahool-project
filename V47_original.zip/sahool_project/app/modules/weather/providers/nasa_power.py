from __future__ import annotations
import httpx
from typing import Any, Dict

NASA_POWER_URL="https://power.larc.nasa.gov/api/temporal/daily/point"

async def fetch_nasa_power(lat: float, lon: float, start: str, end: str) -> Dict[str, Any]:
    params = {
        "parameters": "T2M,RH2M,WS10M,ALLSKY_SFC_SW_DWN,PRECTOTCORR",
        "community": "AG",
        "latitude": lat,
        "longitude": lon,
        "start": start.replace("-",""),
        "end": end.replace("-",""),
        "format": "JSON"
    }
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(NASA_POWER_URL, params=params)
        r.raise_for_status()
        return r.json()
