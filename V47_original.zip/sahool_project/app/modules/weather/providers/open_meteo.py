from __future__ import annotations
import httpx
from tenacity import retry, stop_after_attempt, wait_fixed
from typing import Any, Dict

OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

@retry(stop=stop_after_attempt(3), wait=wait_fixed(1.0))
async def fetch_open_meteo(lat: float, lon: float, hourly: str, daily: str|None=None, past_days: int|None=None) -> Dict[str, Any]:
    params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": hourly,
        "timezone": "auto"
    }
    if daily:
        params["daily"] = daily
    if past_days is not None:
        params["past_days"] = past_days
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(OPEN_METEO_URL, params=params)
        r.raise_for_status()
        return r.json()
