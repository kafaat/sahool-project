
import os
USE_MOCK = os.getenv("WEATHER_MOCK", "0") == "1"

if USE_MOCK:
    from .mock_provider import mock_fetch_open_meteo as fetch_open_meteo
else:
    from .open_meteo import fetch_open_meteo
