from __future__ import annotations
from typing import Dict

# Simple FAO-like Kc defaults per crop stage
KC_TABLE: Dict[str, Dict[str, float]] = {
    "wheat": {"ini": 0.7, "mid": 1.15, "end": 0.4},
    "corn": {"ini": 0.4, "mid": 1.2, "end": 0.6},
    "tomato": {"ini": 0.6, "mid": 1.15, "end": 0.8},
    "cotton": {"ini": 0.35, "mid": 1.15, "end": 0.8},
    "rice": {"ini": 1.05, "mid": 1.2, "end": 0.9},
}

def get_kc(crop: str, stage: str="mid") -> float:
    c=crop.lower()
    st=stage.lower()
    return KC_TABLE.get(c, {}).get(st, 1.0)
