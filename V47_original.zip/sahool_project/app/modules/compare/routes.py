from fastapi import APIRouter
from app.workers.tasks import change_detection_task

router = APIRouter(prefix="/compare", tags=["compare"])

@router.post("/delta")
def delta(field_id: int, old_result_id: int, new_result_id: int):
    task = change_detection_task.delay(field_id, old_result_id, new_result_id)
    return {"task_id": task.id}
