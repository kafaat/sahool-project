from app.modules.auth.deps import require_tenant
from fastapi import APIRouter, Depends, HTTPException
from app.workers.tasks import change_detection_task
from app.modules.satellite.models import NDVIResult


@router.post("/delta/{index_name}")
def delta_generic(index_name: str, field_id: int, old_result_id: int, new_result_id: int):
    # use existing task which reads ndvi tif paths; for other indices we store their tif paths in stats
    task = change_detection_task.delay(field_id, old_result_id, new_result_id, index_name)
    return {"task_id": task.id}
