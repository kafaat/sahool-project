from fastapi import APIRouter, Depends, Response, HTTPException
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from .service import build_gif_bytes, build_mp4_bytes

router = APIRouter(
    prefix="/video",
    tags=["Video"],
    dependencies=[Depends(require_tenant), Depends(require_role("ndvi.read"))],
)

@router.get("/timelapse.gif", summary="Export timelapse GIF", description="Generate and return animated GIF timelapse from index tiles over time.")
async def timelapse_gif(
    field_id: int,
    index: str="ndvi",
    days: int=365,
    fps: int=2,
    z: int=12, x: int=0, y: int=0,
    db: Session = Depends(get_db),
    tenant=Depends(require_tenant)
):
    data = await build_gif_bytes(db, field_id, tenant["tenant_id"], index_name=index, days=days, fps=fps, z=z, x=x, y=y)
    if not data:
        raise HTTPException(404, "no frames to render")
    return Response(content=data, media_type="image/gif")

@router.get("/timelapse.mp4", summary="Export timelapse MP4", description="Generate and return MP4 (H264) timelapse from index tiles over time.")
async def timelapse_mp4(
    field_id: int,
    index: str="ndvi",
    days: int=365,
    fps: int=4,
    z: int=12, x: int=0, y: int=0,
    db: Session = Depends(get_db),
    tenant=Depends(require_tenant)
):
    try:
        data = await build_mp4_bytes(db, field_id, tenant["tenant_id"], index_name=index, days=days, fps=fps, z=z, x=x, y=y)
    except Exception as e:
        raise HTTPException(500, f"mp4 render failed: {e}")
    if not data:
        raise HTTPException(404, "no frames to render")
    return Response(content=data, media_type="video/mp4")
