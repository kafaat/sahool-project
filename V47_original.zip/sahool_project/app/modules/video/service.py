from __future__ import annotations
from typing import List, Dict, Any, Optional
from io import BytesIO
import asyncio

from PIL import Image
import imageio.v2 as imageio

from sqlalchemy.orm import Session
from app.modules.satellite.timeline import build_timeseries
from app.modules.satellite.services.tiles import render_index_tile

async def fetch_frames(db: Session, field_id: int, tenant_id: int, index_name: str="ndvi", days:int=365)->List[Dict[str,Any]]:
    ts = build_timeseries(db, field_id, tenant_id, index_name=index_name, days=days)
    return ts.get("points") or []

async def render_frame_png(index_name: str, result_id: int, z:int, x:int, y:int, tenant_id:int)->bytes:
    # Uses existing tile renderer (single XYZ tile per frame)
    return await render_index_tile(index_name, result_id, z, x, y, tenant_id)

async def build_gif_bytes(
    db: Session,
    field_id: int,
    tenant_id: int,
    index_name: str="ndvi",
    days:int=365,
    fps:int=2,
    z:int=12, x:int=0, y:int=0,
    limit_frames:int=120
)->bytes:
    frames = await fetch_frames(db, field_id, tenant_id, index_name=index_name, days=days)
    frames = frames[-limit_frames:]
    images=[]
    for f in frames:
        rid=f["result_id"]
        png = await render_frame_png(index_name, rid, z, x, y, tenant_id)
        im=Image.open(BytesIO(png)).convert("RGBA")
        images.append(im)

    if not images:
        return b""

    duration=max(1, int(1000/fps))
    out=BytesIO()
    images[0].save(out, format="GIF", save_all=True, append_images=images[1:], duration=duration, loop=0, disposal=2)
    return out.getvalue()

async def build_mp4_bytes(
    db: Session,
    field_id: int,
    tenant_id: int,
    index_name: str="ndvi",
    days:int=365,
    fps:int=4,
    z:int=12, x:int=0, y:int=0,
    limit_frames:int=240
)->bytes:
    frames = await fetch_frames(db, field_id, tenant_id, index_name=index_name, days=days)
    frames = frames[-limit_frames:]
    arrs=[]
    for f in frames:
        rid=f["result_id"]
        png = await render_frame_png(index_name, rid, z, x, y, tenant_id)
        im=Image.open(BytesIO(png)).convert("RGB")
        arrs.append(imageio.asarray(im))

    if not arrs:
        return b""

    out=BytesIO()
    # Use ffmpeg via imageio. If ffmpeg missing at runtime, exception will propagate.
    writer=imageio.get_writer(out, format="ffmpeg", mode="I", fps=fps, codec="libx264", quality=8)
    for a in arrs:
        writer.append_data(a)
    writer.close()
    return out.getvalue()
