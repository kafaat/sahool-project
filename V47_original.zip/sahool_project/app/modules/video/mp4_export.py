def build_mp4(frames):
    return b'MP4DATA'