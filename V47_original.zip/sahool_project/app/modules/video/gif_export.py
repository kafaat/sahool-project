def build_gif(frames):
    return b'GIF89a'