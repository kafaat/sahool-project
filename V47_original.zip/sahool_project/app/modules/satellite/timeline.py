from __future__ import annotations
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from sqlalchemy import desc
import statistics, datetime

from app.modules.satellite.models import NDVIResult

INDEX_STATS_KEY = {
    "ndvi":"ndvi_mean",
    "ndre":"ndre_mean",
    "gndvi":"gndvi_mean",
    "evi":"evi_mean",
    "savi":"savi_mean",
    "ndwi":"ndwi_mean",
    "vari":"vari_mean",
    "gci":"gci_mean",
    "nbr":"nbr_mean",
}

def list_results(db: Session, field_id:int, tenant_id:int, limit:int=365)->List[NDVIResult]:
    return (
        db.query(NDVIResult)
          .filter(NDVIResult.field_id==field_id, NDVIResult.tenant_id==tenant_id)
          .order_by(desc(NDVIResult.date))
          .limit(limit)
          .all()
    )

def build_timeseries(db: Session, field_id:int, tenant_id:int, index_name:str="ndvi", days:int=365)->Dict[str,Any]:
    key=INDEX_STATS_KEY.get(index_name.lower(), "ndvi_mean")
    results=list_results(db, field_id, tenant_id, limit=days)
    pts=[]
    for r in results:
        stats=r.stats or {}
        mean=stats.get(key)
        if mean is None and index_name=="ndvi":
            mean=stats.get("mean_ndvi") or stats.get("ndvi")
        pts.append({"date": r.date.isoformat() if hasattr(r.date,"isoformat") else str(r.date),
                    "mean": mean, "result_id": r.id})
    pts=sorted(pts, key=lambda p:p["date"])
    return {"field_id": field_id, "index": index_name.lower(), "points": pts}

def monthly_baseline(points: List[Dict[str,Any]])->Dict[int,float]:
    bym={m:[] for m in range(1,13)}
    for p in points:
        try:
            d=datetime.date.fromisoformat(p["date"])
        except Exception:
            continue
        v=p.get("mean")
        if v is None: continue
        bym[d.month].append(float(v))
    base={}
    for m,vals in bym.items():
        if vals:
            base[m]=statistics.mean(vals)
    return base

def anomaly(points: List[Dict[str,Any]], baseline: Dict[int,float])->List[Dict[str,Any]]:
    out=[]
    for p in points:
        try:
            d=datetime.date.fromisoformat(p["date"])
        except Exception:
            out.append({**p, "anomaly": None}); continue
        b=baseline.get(d.month); v=p.get("mean")
        a=None
        if b is not None and v is not None:
            a=float(v)-float(b)
        out.append({**p, "anomaly": a})
    return out

def timelapse_frames(points: List[Dict[str,Any]])->List[Dict[str,Any]]:
    return [{"date": p["date"], "result_id": p["result_id"]} for p in points]
