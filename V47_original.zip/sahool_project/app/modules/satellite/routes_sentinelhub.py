from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.satellite.services.sentinelhub_service import fetch_best_image_for_field
from app.core.audit import audit
from app.core.rbac import get_tenant_id

router = APIRouter(prefix="/satellite/sentinelhub", tags=["sentinelhub"])

@router.post("/pull")
def pull(request: Request, field_id: int, date_from: str | None = None, date_to: str | None = None, db: Session = Depends(get_db)):
    try:
        tenant_id = get_tenant_id(request)
        img = fetch_best_image_for_field(db, field_id, date_from, date_to)
        audit("sentinelhub_pull", tenant_id, request.headers.get("x-user-id"), {"field_id": field_id, "image_id": img.id})
        return {"image_id": img.id, "tif_path": img.tif_path, "acquired_at": img.acquired_at}
    except Exception as e:
        raise HTTPException(400, str(e))
