from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.satellite.models import NDVIResult

router = APIRouter(prefix="/satellite/qa", tags=["qa"])

@router.get("/cloud-timeline")
def cloud_timeline(field_id: int, db: Session = Depends(get_db)):
    rows = db.query(NDVIResult).filter_by(field_id=field_id).order_by(NDVIResult.processed_at.asc()).all()
    out=[]
    for r in rows:
        cloud_pct = (r.stats or {}).get("cloud_pct")
        out.append({"t": r.processed_at.isoformat() if r.processed_at else None, "cloud_pct": cloud_pct})
    return {"items": out}
