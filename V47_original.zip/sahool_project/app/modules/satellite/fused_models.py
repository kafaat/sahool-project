import datetime as dt
from sqlalchemy import Column, Integer, Date, Float, ForeignKey, UniqueConstraint, DateTime, JSON, String
from sqlalchemy.orm import relationship
from app.core.db import Base
from app.core.tenant_mixin import TenantMixin

class SatelliteIndexRecord(TenantMixin, Base):
    __tablename__="satellite_index_records"
    __table_args__=(UniqueConstraint("tenant_id","field_id","date", name="uq_sat_idx_field_date"),)

    id=Column(Integer, primary_key=True)
    field_id=Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)
    date=Column(Date, index=True, nullable=False)
    processed_at=Column(DateTime, default=dt.datetime.utcnow)

    ndvi_mean=Column(Float)
    ndvi_min=Column(Float)
    ndvi_max=Column(Float)

    ndwi_mean=Column(Float)
    evi_mean=Column(Float)
    savi_mean=Column(Float)

    cloud_pct=Column(Float)
    raw=Column(JSON, default=dict)

    field=relationship("Field", back_populates="satellite_indices")


class FieldDailyState(TenantMixin, Base):
    __tablename__="field_daily_states"
    __table_args__=(UniqueConstraint("tenant_id","field_id","date", name="uq_field_state_date"),)

    id=Column(Integer, primary_key=True)
    field_id=Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)
    date=Column(Date, index=True, nullable=False)
    created_at=Column(DateTime, default=dt.datetime.utcnow)

    ndvi=Column(Float)
    ndwi=Column(Float)
    evi=Column(Float)
    savi=Column(Float)

    temp_max_c=Column(Float)
    temp_min_c=Column(Float)
    precip_sum_mm=Column(Float)
    humidity_current_pct=Column(Float)

    water_stress=Column(Float)
    heat_stress=Column(Float)
    vigor_score=Column(Float)
    anomaly_score=Column(Float)

    stage=Column(String)
    recommendation=Column(JSON, default=list)
    raw=Column(JSON, default=dict)

    field=relationship("Field", back_populates="daily_states")
