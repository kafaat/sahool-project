from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.file_manager import FileManager
from app.modules.satellite.models import NDVIResult
from app.modules.satellite.services.tiles import get_tile_from_tif
from PIL import Image
import io
from pathlib import Path

router = APIRouter()
fm = FileManager()

@router.get("/tiles/{result_id}/{z}/{x}/{y}.png")
def ndvi_tile(result_id: int, z: int, x: int, y: int, db: Session = Depends(get_db)):
    r = db.get(NDVIResult, result_id)
    if not r:
        raise HTTPException(404, "NDVIResult not found")

    tif_path = Path(r.ndvi_tif_path).resolve()
    if fm.root.resolve() not in tif_path.parents and tif_path != fm.root.resolve():
        raise HTTPException(400, "Invalid file path")

    rgb = get_tile_from_tif(str(tif_path), z, x, y)
    if rgb is None:
        raise HTTPException(404, "Empty tile")

    buff = io.BytesIO()
    Image.fromarray(rgb).save(buff, format="PNG")
    return Response(buff.getvalue(), media_type="image/png")
