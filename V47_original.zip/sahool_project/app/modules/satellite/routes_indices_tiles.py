from fastapi import APIRouter, Depends, HTTPException, Response
from app.core.cache import cache_key, get_or_set_bytes
from app.core.image_fmt import png_to_webp
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.core.file_manager import FileManager
from app.modules.satellite.models import NDVIResult
from app.modules.satellite.services.tiles import get_tile_from_tif
from app.integrations.storage.s3 import public_url
from PIL import Image
import io, os

router = APIRouter()

ALLOWED = {"ndvi","ndre","gndvi","savi","evi","ndwi","anomaly_ndvi","anomaly_ndre","anomaly_gndvi","delta_ndvi","delta_ndre","delta_gndvi"}

def _get_tif_for_index(r: NDVIResult, index_name: str):
    name = index_name.lower()
    if name == "ndvi":
        return r.ndvi_tif_path
    # anomaly & delta are stored like other indices in stats if present
    return (r.stats or {}).get(f"{name}_tif_path") or (r.stats or {}).get(f"{name}.tif_path")

@router.get("/satellite/{index_name}/tiles/{result_id}/{z}/{x}/{y}.png")
def index_tiles(index_name: str, result_id: int, z: int, x: int, y: int, db: Session = Depends(get_db)):
    name = index_name.lower()
    if name not in ALLOWED:
        raise HTTPException(400, "Unsupported index")

    r = db.get(NDVIResult, result_id)
    if not r:
        raise HTTPException(404, "Result not found")

    tif_path = _get_tif_for_index(r, name)

    stats = r.stats or {}
    tile_base = stats.get(f"{name}_tiles_base")
    if tile_base:
        url = f"{tile_base}/{z}/{x}/{y}.png"
        return Response(status_code=307, headers={"Location": url})
    if not tif_path or not os.path.exists(tif_path):
        raise HTTPException(404, "TIF not found for index")

    # precomputed tile
    pre = FileManager.tile_path_index(name, result_id, z, x, y)
    if os.path.exists(pre):
        return Response(open(pre, "rb").read(), media_type="image/png",
                        headers={"Cache-Control":"public, max-age=86400, immutable"})

    rgb = get_tile_from_tif(tif_path, z, x, y, index_name=name)
    if rgb is None:
        raise HTTPException(404, "Empty tile")

    buff = io.BytesIO()
    Image.fromarray(rgb).save(buff, format="PNG")
    return Response(buff.getvalue(), media_type="image/png",
                    headers={"Cache-Control":"public, max-age=86400"})
