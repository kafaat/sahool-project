from fastapi import APIRouter, Response
from app.modules.satellite.services.legend import generate_legend_png, get_ranges

router = APIRouter(prefix="/satellite/legend", tags=["legend"])

@router.get("/{index_name}.png")
def legend_png(index_name: str):
    return Response(generate_legend_png(index_name), media_type="image/png")

@router.get("/{index_name}.json")
def legend_json(index_name: str):
    ranges=get_ranges(index_name)
    return {
        "index": index_name.lower(),
        "ranges":[{"min":a,"max":b,"label":l} for a,b,l in ranges]
    }
