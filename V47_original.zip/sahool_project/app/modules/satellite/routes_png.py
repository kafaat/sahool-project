from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.satellite.models import NDVIResult
from app.modules.satellite.services.tiles import index_to_rgb
from app.modules.satellite.routes_indices_tiles import _get_tif_for_index, ALLOWED
from app.modules.satellite.services.indices_large import read_tif
from PIL import Image
import io, os
import numpy as np

router = APIRouter(prefix="/satellite", tags=["satellite"])

@router.get("/{index_name}/png/{result_id}")
def png_preview(index_name: str, result_id: int, db: Session = Depends(get_db)):
    name=index_name.lower()
    if name not in ALLOWED:
        raise HTTPException(400, "Unsupported index")
    r=db.get(NDVIResult, result_id)
    if not r:
        raise HTTPException(404, "Result not found")
    tif=_get_tif_for_index(r, name)
    if not tif or not os.path.exists(tif):
        raise HTTPException(404, "TIF not found")
    arr, prof = read_tif(tif)
    # downsample for preview
    img = Image.fromarray(arr.astype("float32")).resize((512,512), resample=Image.BILINEAR)
    rgb=index_to_rgb(np.array(img).astype("float32"), name)
    buf=io.BytesIO()
    Image.fromarray(rgb).save(buf, format="PNG")
    return Response(buf.getvalue(), media_type="image/png")
