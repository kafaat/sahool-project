from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.modules.satellite.models import ChangeDetectionResult, NDVIResult
from app.workers.tasks import change_detection_task

router = APIRouter()

@router.post("/process")
def process_change(field_id: int, old_ndvi_id: int, new_ndvi_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    if not db.get(NDVIResult, old_ndvi_id) or not db.get(NDVIResult, new_ndvi_id):
        raise HTTPException(404, "NDVI results missing")
    task = change_detection_task.delay(field_id, old_ndvi_id, new_ndvi_id)
    return {"status": "processing", "task_id": task.id}

@router.get("/")
def list_changes(field_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    return (
        db.query(ChangeDetectionResult).filter(ChangeDetectionResult.tenant_id == tenant_id)
        .filter(ChangeDetectionResult.field_id == field_id)
        .order_by(ChangeDetectionResult.processed_at.desc())
        .all()
    )
