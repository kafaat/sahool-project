from app.modules.auth.deps import require_tenant
from fastapi import APIRouter, Depends, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.satellite.models import NDVIResult
from app.modules.fields.models import Field
from app.modules.satellite.services.offline_polygon import tiles_for_field_polygon
import os


@router.get("/tiles/polygon")
def offline_tiles_polygon(field_id: int, result_id: int, zoom_min: int = 10, zoom_max: int = 16, db: Session = Depends(get_db)):
    field = db.get(Field, field_id)
    r = db.get(NDVIResult, result_id)
    if not field or not r or r.field_id != field_id:
        raise HTTPException(404, "Field/Result not found")
    if not r.ndvi_tif_path or not os.path.exists(r.ndvi_tif_path):
        raise HTTPException(404, "TIF missing")
    if not field.boundary_geojson:
        raise HTTPException(400, "Boundary not set")
    return {"tiles": tiles_for_field_polygon(r.ndvi_tif_path, field.boundary_geojson, zoom_min, zoom_max)}
