from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.core.pagination import Page
from app.modules.satellite.models import SatelliteImage
from app.workers.tasks import fetch_sentinel_image_task

router = APIRouter()


class SatelliteImageOut(BaseModel):
    id: int
    field_id: int
    source: str
    captured_at: datetime
    red_path: str
    nir_path: str
    cloud_percent: float
    meta: Optional[dict] = None

    class Config:
        from_attributes = True


@router.post("/fetch")
def fetch_latest_image(field_id: int):
    task = fetch_sentinel_image_task.delay(field_id)
    return {"status": "downloading", "task_id": task.id}


@router.get("/", response_model=Page[SatelliteImageOut])
def list_images(
    field_id: int,
    sort: str = Query("desc", pattern="^(asc|desc)$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    db: Session = Depends(get_db),
):
    q = db.query(SatelliteImage).filter(SatelliteImage.tenant_id == tenant_id).filter(SatelliteImage.field_id == field_id)
    total = q.count()
    order = SatelliteImage.captured_at.asc() if sort == "asc" else SatelliteImage.captured_at.desc()
    q = q.order_by(order)
    items = q.offset((page - 1) * page_size).limit(page_size).all()
    pages = (total + page_size - 1) // page_size
    return Page(items=items, total=total, page=page, page_size=page_size, pages=pages)


@router.get("/{image_id}", response_model=SatelliteImageOut)
def get_image(image_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    img = db.get(SatelliteImage, image_id)
    if not img:
        raise HTTPException(404, "SatelliteImage not found")
    return img
