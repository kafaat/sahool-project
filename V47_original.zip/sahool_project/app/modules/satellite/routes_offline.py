from app.modules.auth.deps import require_tenant
from fastapi import APIRouter, Depends, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.satellite.models import NDVIResult
from app.modules.satellite.services.offline import tiles_for_bbox
import os


@router.get("/tiles")
def offline_tiles(field_id: int, result_id: int, zoom_min: int = 10, zoom_max: int = 16, db: Session = Depends(get_db)):
    r = db.get(NDVIResult, result_id)
    if not r or r.field_id != field_id:
        raise HTTPException(404, "Result not found")
    # compute list of tiles for field bbox
    return {"tiles": tiles_for_bbox(r.ndvi_tif_path, zoom_min, zoom_max)}
