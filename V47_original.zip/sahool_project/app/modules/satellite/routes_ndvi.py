from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.core.pagination import Page
from app.modules.satellite.models import NDVIResult, SatelliteImage
from app.workers.tasks import compute_ndvi_task
from app.modules.satellite.services.hotspots import extract_hotspots_polygons, extract_hotspots_points

router = APIRouter()


class NDVIOut(BaseModel):
    id: int
    field_id: int
    image_id: int
    processed_at: datetime
    mean_ndvi: float
    min_ndvi: float
    max_ndvi: float
    ndvi_tif_path: str
    ndvi_png_path: str
    stats: Optional[dict] = None

    class Config:
        from_attributes = True


@router.post("/process")
def process_ndvi(image_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    image = db.get(SatelliteImage, image_id)
    if not image:
        raise HTTPException(404, "SatelliteImage not found")
    task = compute_ndvi_task.delay(image_id)
    return {"status": "processing", "task_id": task.id}


@router.get("/", response_model=Page[NDVIOut])
def list_ndvi(
    field_id: int,
    sort: str = Query("desc", pattern="^(asc|desc)$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    db: Session = Depends(get_db),
):
    q = db.query(NDVIResult).filter(NDVIResult.tenant_id == tenant_id).filter(NDVIResult.field_id == field_id)
    total = q.count()
    order = NDVIResult.processed_at.asc() if sort == "asc" else NDVIResult.processed_at.desc()
    q = q.order_by(order)
    items = q.offset((page - 1) * page_size).limit(page_size).all()
    pages = (total + page_size - 1) // page_size
    return Page(items=items, total=total, page=page, page_size=page_size, pages=pages)


@router.get("/{result_id}", response_model=NDVIOut)
def get_ndvi(result_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    r = db.get(NDVIResult, result_id)
    if not r:
        raise HTTPException(404, "NDVIResult not found")
    return r

@router.get(
    "/hotspots",
    summary="Detect NDVI stress hotspots (low vegetation areas)",
)
def ndvi_hotspots(
    ndvi_id: int,
    threshold: float = 0.3,
    tenant_id: int = Depends(get_tenant_id_open),
    db: Session = Depends(get_db),
):
    ndvi = db.get(NDVIResult, ndvi_id)
    if not ndvi or ndvi.tenant_id != tenant_id:
        raise HTTPException(404, "NDVIResult not found")

    polys = extract_hotspots_polygons(ndvi.ndvi_tif_path, threshold=threshold)
    points = extract_hotspots_points(ndvi.ndvi_tif_path, threshold=threshold)
    return {
    "ndvi_id": ndvi.id,
    "threshold": threshold,
    "count": len(polys),
    "polygons": polys,
    "heatmap_points": points,
    }