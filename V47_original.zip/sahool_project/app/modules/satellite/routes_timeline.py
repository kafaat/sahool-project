from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from .timeline import build_timeseries, monthly_baseline, anomaly, timelapse_frames

router = APIRouter(
    prefix="/timeline",
    tags=["Timeline"],
    dependencies=[Depends(require_tenant), Depends(require_role("ndvi.read"))],
)

@router.get("/{index_name}/timeseries", summary="Index timeseries", description="Return mean values over time for selected index with monthly baseline.")
def timeseries(index_name:str, field_id:int, days:int=365, db:Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], index_name=index_name, days=days)
    base=monthly_baseline(ts["points"])
    return {**ts, "baseline": base}

@router.get("/{index_name}/anomaly", summary="Index anomaly series", description="Return anomaly series vs monthly climatology baseline.")
def anomaly_ep(index_name:str, field_id:int, days:int=365, db:Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], index_name=index_name, days=days)
    base=monthly_baseline(ts["points"])
    return {"field_id": field_id, "index": index_name, "points": anomaly(ts["points"], base), "baseline": base}

@router.get("/{index_name}/frames", summary="Timelapse frames", description="Return ordered frame list (date + result_id) for timelapse player.")
def frames(index_name:str, field_id:int, days:int=365, db:Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], index_name=index_name, days=days)
    return {"field_id": field_id, "index": index_name, "frames": timelapse_frames(ts["points"])}
