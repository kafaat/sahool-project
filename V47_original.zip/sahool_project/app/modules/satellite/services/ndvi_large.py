import rasterio
from rasterio.windows import Window
from rasterio.mask import mask
import numpy as np
from shapely.geometry import mapping


def compute_ndvi_windowed(red_path, nir_path, field_polygon, tile_size=1024):
    """Compute NDVI over full raster using windowed reads to reduce memory.

    Returns cropped NDVI array, transform, updated profile (LZW), and stats.
    """
    with rasterio.open(red_path) as red_src, rasterio.open(nir_path) as nir_src:
        profile = red_src.profile.copy()
        width, height = red_src.width, red_src.height
        ndvi_full = np.full((height, width), np.nan, dtype=np.float32)

        for row_off in range(0, height, tile_size):
            for col_off in range(0, width, tile_size):
                w = Window(
                    col_off,
                    row_off,
                    min(tile_size, width - col_off),
                    min(tile_size, height - row_off),
                )
                red = red_src.read(1, window=w).astype(np.float32)
                nir = nir_src.read(1, window=w).astype(np.float32)

                denom = nir + red
                ndvi = np.where(denom == 0, np.nan, (nir - red) / denom)
                ndvi_full[
                    row_off : row_off + int(w.height),
                    col_off : col_off + int(w.width),
                ] = ndvi

        # crop to field boundary
        with rasterio.open(red_path) as ref_src:
            ref_crop, transform = mask(
                ref_src, [mapping(field_polygon)], crop=True, filled=False
            )

        crop_h, crop_w = ref_crop.shape[1], ref_crop.shape[2]
        ref_mask = ref_crop[0].mask
        crop = ndvi_full[:crop_h, :crop_w]
        crop = np.where(ref_mask, np.nan, crop)

        stats = {
            "mean": float(np.nanmean(crop)) if np.isfinite(crop).any() else float("nan"),
            "min": float(np.nanmin(crop)) if np.isfinite(crop).any() else float("nan"),
            "max": float(np.nanmax(crop)) if np.isfinite(crop).any() else float("nan"),
        }

        profile.update(dtype=rasterio.float32, count=1, compress="lzw")
        return crop, transform, profile, stats
