from app.core.cache import get_json, set_json
import matplotlib.pyplot as plt
import numpy as np, io

LEGENDS = {
    "ndvi": [(-1,0.0,"bare"), (0.0,0.2,"poor"), (0.2,0.5,"fair"), (0.5,0.8,"good"), (0.8,1.0,"excellent")],
    "ndre": [(-1,0.0,"low"), (0.0,0.3,"moderate"), (0.3,0.6,"good"), (0.6,1.0,"very good")],
    "gndvi":[(-1,0.0,"low"), (0.0,0.3,"moderate"), (0.3,0.6,"good"), (0.6,1.0,"very good")],
    "savi":[(-1,0.0,"bare"), (0.0,0.2,"poor"), (0.2,0.5,"fair"), (0.5,0.8,"good"), (0.8,1.0,"excellent")],
    "evi":[(-1,0.0,"bare"), (0.0,0.2,"poor"), (0.2,0.5,"fair"), (0.5,0.8,"good"), (0.8,1.0,"excellent")],

"vari":[(-1,0.0,"low"), (0.0,0.3,"moderate"), (0.3,0.6,"good"), (0.6,1.0,"very good")],
"nbr":[(-1,0.0,"low"), (0.0,0.3,"moderate"), (0.3,0.6,"good"), (0.6,1.0,"very good")],
"gci":[(0,0.5,"low chlorophyll"), (0.5,1.5,"moderate"), (1.5,3.0,"good"), (3.0,5.0,"very good")],
    "ndwi":[(-1,0.0,"dry"), (0.0,0.3,"moist"), (0.3,0.6,"wet"), (0.6,1.0,"water")],
    "anomaly_ndvi":[(0,0.2,"normal"), (0.2,0.5,"stress"), (0.5,1.0,"high stress")],
    "delta_ndvi":[(-1,-0.2,"drop"), (-0.2,0.2,"stable"), (0.2,1.0,"increase")],
}

def get_ranges(index_name="ndvi"):
    return LEGENDS.get(index_name.lower(), LEGENDS["ndvi"])

def generate_legend_png(index_name="ndvi"):
    ranges=get_ranges(index_name)
    fig, ax = plt.subplots(figsize=(4, 0.6))
    minv=min(r[0] for r in ranges); maxv=max(r[1] for r in ranges)
    gradient = np.linspace(minv, maxv, 256).reshape(1, -1)
    ax.imshow(gradient, aspect='auto')
    ax.set_axis_off()
    ax2=ax.twiny(); ax2.set_xlim(-1,1)
    ticks=[r[0] for r in ranges] + [ranges[-1][1]]
    ax2.set_xticks(ticks)
    ax2.set_xticklabels([str(t) for t in ticks], fontsize=7)
    buf=io.BytesIO()
    plt.tight_layout()
    fig.savefig(buf, format="png", dpi=160, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig); buf.seek(0)
    return buf.getvalue()
