from __future__ import annotations
from sqlalchemy.orm import Session
from app.modules.fields.models import Field
from app.modules.satellite.models import SatelliteImage
from app.core.config import settings
import datetime

def fetch_latest_for_field(db: Session, field_id: int):
    """Stub: create SatelliteImage record to be processed. 
    Replace with real SentinelHub/EO API request.
    """
    field = db.get(Field, field_id)
    if not field:
        return None

    # In real impl: use polygon to request latest acquisitions.
    img = SatelliteImage(
        field_id=field_id,
        tenant_id=field.tenant_id,
        provider="sentinelhub",
        acquired_at=datetime.datetime.utcnow(),
        status="queued",
        meta={"note": "stub, replace with real pull"}
    )
    db.add(img); db.commit(); db.refresh(img)
    return img
