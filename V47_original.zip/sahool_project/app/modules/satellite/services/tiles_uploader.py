from __future__ import annotations
import os
from typing import Optional
from app.integrations.storage.s3 import upload_file, public_url
from app.integrations.storage.prefix import tenant_prefix
from app.core.config import settings

def upload_tiles_folder(local_root: str, key_prefix: str, tenant_id: int | None = None, cleanup_local: bool=True) -> str:
    """Upload all png tiles under local_root to S3 and return base url prefix."""
    for dirpath, _, filenames in os.walk(local_root):
        for fn in filenames:
            if not fn.lower().endswith(".png"):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, local_root).replace("\\","/")
            pref = tenant_prefix(tenant_id)
            key = f"{pref}/{key_prefix}/{rel}"
            upload_file(full, key, content_type="image/png")
    base = public_url(f"{tenant_prefix(tenant_id)}/{key_prefix}")
    if cleanup_local:
        try:
            import shutil
            shutil.rmtree(local_root, ignore_errors=True)
        except Exception:
            pass
    return base
