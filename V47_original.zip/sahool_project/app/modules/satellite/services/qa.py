import numpy as np

def cloud_percentage(clear_mask: np.ndarray | None) -> float:
    if clear_mask is None:
        return 0.0
    total = clear_mask.size
    clear = np.count_nonzero(clear_mask)
    cloudy = total - clear
    return float(cloudy / total) * 100.0
