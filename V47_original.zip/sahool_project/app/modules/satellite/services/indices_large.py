from app.modules.satellite.services.qa import cloud_percentage
from app.modules.satellite.services.cloud_mask import simple_cloud_mask
from typing import Optional, Tuple, Dict
import numpy as np
import rasterio
from rasterio.mask import mask
from shapely.geometry import mapping

def _read_crop(path: str, field_polygon):
    with rasterio.open(path) as src:
        arr, transform = mask(src, [mapping(field_polygon)], crop=True, filled=False)
        data = arr[0].astype("float32")
        if hasattr(arr[0], "mask"):
            data = np.where(arr[0].mask, np.nan, data)
        profile = src.profile.copy()
        return data, transform, profile

def compute_indices(
    red_path: str,
    nir_path: str,
    field_polygon,
    blue_path: Optional[str]=None,
    swir1_path: Optional[str]=None,
    swir2_path: Optional[str]=None,
    green_path: Optional[str]=None,
    rededge_path: Optional[str]=None,
):
    """Compute multiple vegetation indices cropped to field.

    Returns:
      arrays: dict index->np.ndarray
      transform, profile, stats
    """
    red, transform, profile = _read_crop(red_path, field_polygon)
    nir, _, _ = _read_crop(nir_path, field_polygon)

    # NDVI
    ndvi = (nir - red) / (nir + red)
    ndvi = np.where(np.isfinite(ndvi), ndvi, np.nan)

    # SAVI (L=0.5)
    L = 0.5
    savi = ((nir - red) / (nir + red + L)) * (1.0 + L)
    savi = np.where(np.isfinite(savi), savi, np.nan)

    evi = None
    if blue_path:
        blue, _, _ = _read_crop(blue_path, field_polygon)
        evi = 2.5 * (nir - red) / (nir + 6*red - 7.5*blue + 1.0)
        evi = np.where(np.isfinite(evi), evi, np.nan)

    ndwi = None
    if swir1_path:
        swir, _, _ = _read_crop(swir1_path, field_polygon)
        ndwi = (nir - swir) / (nir + swir)
        ndwi = np.where(np.isfinite(ndwi), ndwi, np.nan)

    gndvi = None
    if green_path:
        green, _, _ = _read_crop(green_path, field_polygon)
        gndvi = (nir - green) / (nir + green)
        gndvi = np.where(np.isfinite(gndvi), gndvi, np.nan)

    ndre = None
    if rededge_path:
        re, _, _ = _read_crop(rededge_path, field_polygon)
        ndre = (nir - re) / (nir + re)
        ndre = np.where(np.isfinite(ndre), ndre, np.nan)

    
    vari = None
    if green_path and blue_path:
        green, _, _ = _read_crop(green_path, field_polygon)
        blue, _, _ = _read_crop(blue_path, field_polygon)
        vari = (green - red) / (green + red - blue)
        vari = np.where(np.isfinite(vari), vari, np.nan)

    gci = None
    if green_path:
        green, _, _ = _read_crop(green_path, field_polygon)
        gci = (nir / green) - 1.0
        gci = np.where(np.isfinite(gci), gci, np.nan)

    nbr = None
    swir_for_nbr = None
    if swir2_path:
        swir_for_nbr, _, _ = _read_crop(swir2_path, field_polygon)
    elif swir1_path:
        swir_for_nbr, _, _ = _read_crop(swir1_path, field_polygon)
    if swir_for_nbr is not None:
        nbr = (nir - swir_for_nbr) / (nir + swir_for_nbr)
        nbr = np.where(np.isfinite(nbr), nbr, np.nan)
              "mean": float(np.nanmean(arr)) if arr is not None and np.isfinite(arr).any() else None,
                "min": float(np.nanmin(arr)) if arr is not None and np.isfinite(arr).any() else None,
                "max": float(np.nanmax(arr)) if arr is not None and np.isfinite(arr).any() else None,
            }

        stats = {
            "ndvi_mean": _stats(ndvi)["mean"],
            "ndvi_min": _stats(ndvi)["min"],
            "ndvi_max": _stats(ndvi)["max"],
            "savi_mean": _stats(savi)["mean"],
            "savi_min": _stats(savi)["min"],
            "savi_max": _stats(savi)["max"],
            "evi_mean": _stats(evi)["mean"] if evi is not None else None,
            "evi_min": _stats(evi)["min"] if evi is not None else None,
            "evi_max": _stats(evi)["max"] if evi is not None else None,
            "ndwi_mean": _stats(ndwi)["mean"] if ndwi is not None else None,
            "ndwi_min": _stats(ndwi)["min"] if ndwi is not None else None,
            "ndwi_max": _stats(ndwi)["max"] if ndwi is not None else None,
            "gndvi_mean": _stats(gndvi)["mean"] if gndvi is not None else None,
            "gndvi_min": _stats(gndvi)["min"] if gndvi is not None else None,
            "gndvi_max": _stats(gndvi)["max"] if gndvi is not None else None,
            "ndre_mean": _stats(ndre)["mean"] if ndre is not None else None,
            "ndre_min": _stats(ndre)["min"] if ndre is not None else None,
            "ndre_max": _stats(ndre)["max"] if ndre is not None else None,
            "vari_mean": _stats(vari)["mean"] if vari is not None else None,
            "vari_min": _stats(vari)["min"] if vari is not None else None,
            "vari_max": _stats(vari)["max"] if vari is not None else None,
            "gci_mean": _stats(gci)["mean"] if gci is not None else None,
            "gci_min": _stats(gci)["min"] if gci is not None else None,
            "gci_max": _stats(gci)["max"] if gci is not None else None,
            "nbr_mean": _stats(nbr)["mean"] if nbr is not None else None,
            "nbr_min": _stats(nbr)["min"] if nbr is not None else None,
            "nbr_max": _stats(nbr)["max"] if nbr is not None else None,
        }

        arrays = {
            "ndvi": ndvi,
            "savi": savi,
            "evi": evi,
            "ndwi": ndwi,
            "gndvi": gndvi,
            "ndre": ndre,
            "vari": vari,
            "gci": gci,
            "nbr": nbr,
        }

        profile.update(dtype=rasterio.float32, count=1, compress="lzw")
        return arrays, transform, profile, stats


    def build_overviews(tif_path: str):
        """Best-effort add internal overviews to speed tiles."""
        import rasterio
        from rasterio.enums import Resampling
        try:
            with rasterio.open(tif_path, "r+") as dst:
                dst.build_overviews([2,4,8,16,32,64], Resampling.average)
                dst.update_tags(ns="rio_overview", resampling="average")
        except Exception:
            pass


