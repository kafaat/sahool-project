import rasterio
from rasterio.features import shapes
import numpy as np
from shapely.geometry import shape, mapping
from shapely.ops import unary_union
from scipy.ndimage import binary_opening, binary_closing, generate_binary_structure, label

def compute_dynamic_threshold(arr: np.ndarray, k: float = 0.8) -> float:
    vals = arr[np.isfinite(arr)]
    if vals.size == 0:
        return 0.3
    m = float(vals.mean())
    s = float(vals.std())
    return m - s * k

def read_ndvi_array(ndvi_tif_path: str):
    with rasterio.open(ndvi_tif_path) as src:
        arr = src.read(1).astype("float32")
        transform = src.transform
        res = src.res
    return arr, transform, res

def extract_hotspots_polygons(
    ndvi_tif_path: str,
    threshold: float | None = 0.3,
    min_area_px: int = 80,
    smooth_iters: int = 1,
    dynamic_k: float = 0.8,
):
    """Extract low-NDVI hotspot polygons from an NDVI GeoTIFF.

    Features:
    - Dynamic threshold if threshold is None.
      dynamic_threshold = mean(NDVI) - std(NDVI) * dynamic_k
    - Morphological opening/closing to reduce speckle noise.
    - Connected-components filtering by pixel area.
    """
    if not ndvi_tif_path:
        return []

    arr, transform, res = read_ndvi_array(ndvi_tif_path)

    if threshold is None:
        threshold = compute_dynamic_threshold(arr, k=dynamic_k)

    mask = np.isfinite(arr) & (arr < threshold)
    if mask.sum() == 0:
        return []

    struct = generate_binary_structure(2, 2)
    den = mask.copy()
    for _ in range(max(smooth_iters, 0)):
        den = binary_opening(den, structure=struct)
        den = binary_closing(den, structure=struct)

    labeled, n = label(den, structure=struct)
    if n == 0:
        return []
    keep = np.zeros_like(den, dtype=bool)
    for comp_id in range(1, n+1):
        comp = (labeled == comp_id)
        if comp.sum() >= min_area_px:
            keep |= comp

    if keep.sum() == 0:
        return []

    geoms = []
    for geom, val in shapes(keep.astype("uint8"), mask=keep, transform=transform):
        if val != 1:
            continue
        poly = shape(geom)
        if poly.area <= 0:
            continue
        geoms.append(poly)

    if not geoms:
        return []

    merged = unary_union(geoms)
    polys = []
    if merged.geom_type == "Polygon":
        polys = [merged]
    elif merged.geom_type == "MultiPolygon":
        polys = list(merged.geoms)

    out=[]
    px_area = abs(res[0]*res[1]) + 1e-9
    for p in polys:
        if p.area / px_area < min_area_px:
            continue
        out.append(mapping(p))
    return out

def extract_hotspots_points(
    ndvi_tif_path: str,
    threshold: float | None = 0.3,
    step: int = 8,
    dynamic_k: float = 0.8,
):
    """Return sparse (x, y, weight) points for heatmap rendering.

    Weight ~ how far below threshold the pixel is.
    Uses dynamic threshold if threshold is None.
    """
    if not ndvi_tif_path:
        return []

    arr, transform, res = read_ndvi_array(ndvi_tif_path)

    if threshold is None:
        threshold = compute_dynamic_threshold(arr, k=dynamic_k)

    mask = np.isfinite(arr) & (arr < threshold)
    if mask.sum() == 0:
        return []

    rows, cols = np.where(mask)
    points=[]
    for r, c in zip(rows[::step], cols[::step]):
        # transform pixel to CRS coords
        x, y = rasterio.transform.xy(transform, int(r), int(c))
        val = float(arr[r, c])
        weight = max(0.0, min(1.0, (threshold - val) / max(threshold, 1e-6)))
        points.append({"x": x, "y": y, "weight": weight})
    return points
