from app.core.cache import redis
import mercantile
import numpy as np
from PIL import Image
import rasterio

def _normalize(arr, minv=-1.0, maxv=1.0):
    a = (arr - minv) / (maxv - minv)
    return np.clip(a, 0.0, 1.0)

RANGES = {
    'gci': (0.0, 5.0),
    'default': (-1.0, 1.0)
}

def index_to_rgb(tile: np.ndarray, index_name: str="ndvi") -> np.ndarray:
    """Hybrid balanced colormaps per index.
    Returns uint8 RGB array.
    """
    name = index_name.lower()
    minv,maxv = RANGES.get(name, RANGES['default'])
    norm = _normalize(tile, minv, maxv)
    rgb = np.zeros((tile.shape[0], tile.shape[1], 3), dtype=np.uint8)

    if name in ("ndvi","ndre","gndvi","savi","evi"):
        # vegetation: red->yellow->green
        rgb[...,0] = (255 * (1-norm)).astype(np.uint8)
        rgb[...,1] = (255 * norm).astype(np.uint8)
        rgb[...,2] = (60 * (1-norm)).astype(np.uint8)
    elif name == "ndwi":
        # water: dark->bright blue
        rgb[...,2] = (255 * norm).astype(np.uint8)
        rgb[...,1] = (120 * norm).astype(np.uint8)
    elif name.startswith("delta"):
        # change: negative red, positive green
        neg = _normalize(-tile, 0, 1)
        pos = _normalize(tile, 0, 1)
        rgb[...,0] = (255 * neg).astype(np.uint8)
        rgb[...,1] = (255 * pos).astype(np.uint8)
    elif name.startswith("anomaly"):
        # anomalies: orange/yellow intensity
        rgb[...,0] = (255 * norm).astype(np.uint8)
        rgb[...,1] = (140 * norm).astype(np.uint8)
    else:
        # fallback grayscale
        g = (255 * norm).astype(np.uint8)
        rgb[...,0]=g; rgb[...,1]=g; rgb[...,2]=g

    return rgb

def get_tile_from_tif(tif_path: str, z: int, x: int, y: int, index_name="ndvi", tile_size=256):
    bounds = mercantile.bounds(x, y, z)
    minx, miny, maxx, maxy = bounds.west, bounds.south, bounds.east, bounds.north
    cached = redis.get(tile_cache_key)
    if cached:
        return cached
    with rasterio.open(tif_path) as src:
        try:
            row_min, col_min = src.index(minx, maxy)
            row_max, col_max = src.index(maxx, miny)
        except Exception:
            return None
        if row_min >= row_max or col_min >= col_max:
            return None
        window = rasterio.windows.Window.from_slices((row_min, row_max), (col_min, col_max))
        data = src.read(1, window=window).astype("float32")
        if data.size == 0:
            return None
    img = Image.fromarray(data).resize((tile_size, tile_size), resample=Image.BILINEAR)
    return index_to_rgb(np.array(img).astype("float32"), index_name=index_name)


from io import BytesIO
from PIL import Image

def rgba_to_png_bytes(rgba: np.ndarray)->bytes:
    im = Image.fromarray(rgba, mode="RGBA")
    buf = BytesIO()
    im.save(buf, format="PNG")
    return buf.getvalue()

async def render_index_tile_array(index_name: str, result_id: int, z: int, x: int, y: int, tenant_id: int):
    # same as render_index_tile but return float array (index values) before colorization.
    from .indices_large import load_index_tif_window
    tile = await load_index_tif_window(index_name, result_id, z, x, y, tenant_id)
    return tile
