from __future__ import annotations
from typing import List, Dict, Any
from morecantile import TileMatrixSet
from morecantile.commons import BoundingBox
from shapely.geometry import shape, box
from shapely.ops import unary_union
import rasterio

WMT = TileMatrixSet.web_mercator()

def tiles_for_field_polygon(tif_path: str, boundary_geojson: Dict[str, Any], zoom_min: int=10, zoom_max: int=16) -> List[Dict[str,int]]:
    geom = shape(boundary_geojson.get("geometry", boundary_geojson))
    # bbox for quick coverage
    minx, miny, maxx, maxy = geom.bounds
    bbox = BoundingBox(left=minx, bottom=miny, right=maxx, top=maxy)

    out=[]
    for z in range(zoom_min, zoom_max+1):
        for t in WMT.tiles(bbox, [z]):
            tb = WMT.bounds(t)
            tgeom = box(tb.left, tb.bottom, tb.right, tb.top)
            if geom.intersects(tgeom):
                out.append({"z": t.z, "x": t.x, "y": t.y})
    return out
