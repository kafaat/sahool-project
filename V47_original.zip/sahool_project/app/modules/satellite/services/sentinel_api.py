"""Legacy compatibility for worker tasks.

The Phase18 worker expected `SentinelAPIService`. In newer code,
logic moved into `cdse_client`/`sentinelhub_service`.
This wrapper keeps the old interface stable.
"""
from __future__ import annotations
from typing import Any, Dict, Optional
from .cdse_client import CDSEClient

class SentinelAPIService:
    def __init__(self, **kwargs):
        self.client = CDSEClient(**kwargs)

    async def fetch_latest_for_field(self, field: Any, **kwargs) -> Optional[Dict[str, Any]]:
        # delegate to client if exists, else None
        if hasattr(self.client, "fetch_latest_for_field"):
            return await self.client.fetch_latest_for_field(field, **kwargs)  # type: ignore
        return None

    async def download_scene(self, *args, **kwargs):
        if hasattr(self.client, "download_scene"):
            return await self.client.download_scene(*args, **kwargs)  # type: ignore
        raise NotImplementedError("download_scene not implemented in CDSEClient")

    async def search_scenes(self, *args, **kwargs):
        if hasattr(self.client, "search_scenes"):
            return await self.client.search_scenes(*args, **kwargs)  # type: ignore
        return []
