from __future__ import annotations
from typing import List, Tuple, Dict
from rio_tiler.io import COGReader
from rio_tiler.colormap import cmap
from rio_tiler.utils import render
from morecantile import TileMatrixSet
from morecantile.commons import BoundingBox
import os

DEFAULT_CMAP = cmap.get("viridis")
WMT = TileMatrixSet.web_mercator()

def render_tile(tif_path: str, z: int, x: int, y: int, index_name: str="ndvi") -> bytes:
    with COGReader(tif_path) as cog:
        img = cog.tile(x, y, z)
        return render(img.data, mask=img.mask, colormap=DEFAULT_CMAP, img_format="PNG")

def cover_tiles(tif_path: str, zoom_min: int=10, zoom_max: int=16) -> List[Tuple[int,int,int]]:
    tiles=[]
    with COGReader(tif_path) as cog:
        bounds = cog.geographic_bounds
        bbox = BoundingBox(left=bounds[0], bottom=bounds[1], right=bounds[2], top=bounds[3])
        for z in range(zoom_min, zoom_max+1):
            for t in WMT.tiles(bbox, [z]):
                tiles.append((t.z, t.x, t.y))
    return tiles

def precompute_tiles(tif_path: str, out_root: str, zoom_min: int=10, zoom_max: int=16) -> Dict[str,int]:
    os.makedirs(out_root, exist_ok=True)
    tiles = cover_tiles(tif_path, zoom_min, zoom_max)
    written=0
    for z,x,y in tiles:
        zdir=os.path.join(out_root,str(z),str(x))
        os.makedirs(zdir, exist_ok=True)
        out=os.path.join(zdir,f"{y}.png")
        if os.path.exists(out): 
            continue
        png=render_tile(tif_path,z,x,y)
        with open(out,"wb") as f: f.write(png)
        written+=1
    return {"tiles_total": len(tiles), "tiles_written": written}
