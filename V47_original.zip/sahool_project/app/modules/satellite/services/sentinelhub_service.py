from __future__ import annotations
from typing import Dict, Any, Optional
import datetime, os, tempfile
from sqlalchemy.orm import Session

from app.integrations.sentinelhub.client import get_client
from app.integrations.sentinelhub.catalog import search_best_acquisition
from app.modules.fields.models import Field
from app.modules.satellite.models import SatelliteImage

EVALSCRIPT = "//VERSION=3\nfunction setup() {\n  return {\n    input: [{bands: [\"B02\",\"B03\",\"B04\",\"B05\",\"B08\",\"B11\",\"SCL\"], units: \"REFLECTANCE\"}],\n    output: { bands: 7, sampleType: \"FLOAT32\" }\n  };\n}\nfunction evaluatePixel(sample) {\n  return [sample.B02, sample.B03, sample.B04, sample.B05, sample.B08, sample.B11, sample.SCL];\n}\n"

def _process_payload(geometry_geojson: Dict[str, Any], date_from: str, date_to: str) -> Dict[str, Any]:
    return {
      "input": {
        "bounds": {"geometry": geometry_geojson},
        "data": [{
          "type": "sentinel-2-l2a",
          "dataFilter": {
            "timeRange": {"from": date_from, "to": date_to}
          }
        }]
      },
      "output": {
        "responses": [{
          "identifier":"default",
          "format": {"type":"image/tiff"}
        }]
      },
      "evalscript": EVALSCRIPT
    }

def fetch_best_image_for_field(db: Session, field_id: int, date_from: Optional[str]=None, date_to: Optional[str]=None) -> SatelliteImage:
    field: Field = db.get(Field, field_id)
    if not field or not field.boundary_geojson:
        raise ValueError("Field polygon missing")

    client = get_client()
    if date_to is None:
        date_to = datetime.datetime.utcnow().replace(microsecond=0).isoformat()+"Z"
    if date_from is None:
        date_from = (datetime.datetime.utcnow()-datetime.timedelta(days=10)).replace(microsecond=0).isoformat()+"Z"

    geom = field.boundary_geojson.get("geometry", field.boundary_geojson)
    payload = _process_payload(geom, date_from, date_to)
    try:
        feat = search_best_acquisition(client, geom, date_from, date_to, max_cloud=60.0)
        if feat:
            dt = feat.get('properties',{}).get('datetime')
            if dt:
                payload = _process_payload(geom, dt, dt)
    except Exception:
        pass
    tiff_bytes = client.process(payload)

    tmpdir = tempfile.mkdtemp(prefix="sentinel_")
    tif_path = os.path.join(tmpdir, f"field_{field_id}_{datetime.datetime.utcnow().date()}.tif")
    with open(tif_path, "wb") as f:
        f.write(tiff_bytes)

    img = SatelliteImage(
        field_id=field_id,
        tenant_id=field.tenant_id,
        provider="sentinelhub",
        acquired_at=datetime.datetime.utcnow(),
        status="downloaded",
        tif_path=tif_path,
        meta={"date_from": date_from, "date_to": date_to, "note":"downloaded via Process API"}
    )
    db.add(img); db.commit(); db.refresh(img)
    return img
