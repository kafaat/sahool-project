from __future__ import annotations
import numpy as np

def heatmap_rgba(values: np.ndarray, vmin: float=-1.0, vmax: float=1.0)->np.ndarray:
    # normalize 0..1
    norm = (values - vmin) / (vmax - vmin + 1e-9)
    norm = np.clip(norm, 0, 1)
    # simple red-yellow-green ramp (no explicit colors in code here besides endpoints)
    r = np.clip(2*(1-norm), 0, 1)
    g = np.clip(2*norm, 0, 1)
    b = np.zeros_like(norm)
    a = np.where(np.isfinite(values), 1.0, 0.0)
    rgba = np.stack([r,g,b,a], axis=-1)
    return (rgba*255).astype(np.uint8)
