from __future__ import annotations
from typing import List, Dict
from morecantile import TileMatrixSet
from morecantile.commons import BoundingBox
import rasterio

WMT = TileMatrixSet.web_mercator()

def tiles_for_bbox(tif_path: str, zoom_min: int=10, zoom_max: int=16) -> List[Dict[str,int]]:
    with rasterio.open(tif_path) as src:
        b = src.bounds
        # assume bounds already lon/lat; if projected, rasterio will still give CRS bounds
        # best-effort: use bounds as geographic
        bbox = BoundingBox(left=b.left, bottom=b.bottom, right=b.right, top=b.top)

    out=[]
    for z in range(zoom_min, zoom_max+1):
        for t in WMT.tiles(bbox, [z]):
            out.append({"z": t.z, "x": t.x, "y": t.y})
    return out
