import os, shutil
import rasterio
from rasterio.shutil import copy as rio_copy

def to_cog(src_path: str, dst_path: str | None = None) -> str:
    """Best-effort convert to Cloud-Optimized GeoTIFF."""
    if dst_path is None:
        dst_path = src_path.replace(".tif", "_cog.tif")
    try:
        rio_copy(src_path, dst_path, driver="COG", compress="DEFLATE")
        return dst_path
    except Exception:
        # fallback to original
        return src_path
