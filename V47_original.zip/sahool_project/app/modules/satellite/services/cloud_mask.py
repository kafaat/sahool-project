import numpy as np

def simple_cloud_mask(blue: np.ndarray, swir1: np.ndarray | None = None, threshold: float = 0.2) -> np.ndarray:
    """Very simple cloud mask: high blue reflectance (+ optional swir) => cloud.
    Returns boolean mask where True=clear, False=cloud.
    Assumes bands normalized 0..1.
    """
    mask = blue < threshold
    if swir1 is not None:
        mask = mask & (swir1 < threshold)
    return mask
