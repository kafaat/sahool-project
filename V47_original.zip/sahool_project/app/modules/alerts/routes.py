from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import datetime

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.core.pagination import Page
from app.modules.alerts.models import Alert

router = APIRouter()


class AlertOut(BaseModel):
    id: int
    field_id: int
    type: str
    severity: str
    message: str
    created_at: datetime

    class Config:
        from_attributes = True


@router.get("/", response_model=Page[AlertOut])
def list_alerts(
    field_id: int,
    sort: str = Query("desc", pattern="^(asc|desc)$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    db: Session = Depends(get_db),
):
    q = db.query(Alert).filter(Alert.tenant_id == tenant_id).filter(Alert.field_id == field_id)
    total = q.count()
    order = Alert.created_at.asc() if sort == "asc" else Alert.created_at.desc()
    q = q.order_by(order)
    items = q.offset((page - 1) * page_size).limit(page_size).all()
    pages = (total + page_size - 1) // page_size
    return Page(items=items, total=total, page=page, page_size=page_size, pages=pages)


@router.get("/{alert_id}", response_model=AlertOut)
def get_alert(alert_id: int, tenant_id: int = Depends(get_tenant_id_open), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    if not a:
        raise HTTPException(404, "Alert not found")
    return a

@router.get(
    "/dashboard",
    summary="Alerts for dashboard (latest 50)"
)
def alerts_dashboard(
    tenant_id: int = Depends(get_tenant_id_open),
    db: Session = Depends(get_db),
):
    q = (db.query(Alert)
            .filter(Alert.tenant_id == tenant_id)
            .order_by(Alert.created_at.desc())
            .limit(50))
    items = [{
        "id": a.id,
        "field_id": a.field_id,
        "type": a.type,
        "severity": a.severity,
        "message": a.message,
        "created_at": a.created_at.isoformat()
    } for a in q.all()]
    return {"tenant_id": tenant_id, "items": items}
