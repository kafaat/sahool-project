from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from .service import disease_risk

router = APIRouter(
    prefix="/disease",
    tags=["Disease-Risk"],
    dependencies=[Depends(require_tenant), Depends(require_role("agro.read"))],
)

@router.get("/risk", summary="Disease risk", description="Estimate crop disease risks using weather, NDVI anomalies, and soil salinity.")
async def risk(field_id: int, crop: str, days: int = 365, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    return await disease_risk(field_id, crop, db, tenant["tenant_id"], days=days)
