from __future__ import annotations
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from app.modules.weather.service import get_agro_summary
from app.modules.ndvi.timeseries import build_timeseries, monthly_climatology, anomaly_series
from app.modules.soil.service import list_profiles
from app.modules.fields.models import Field
from .rules import CROP_RULES

def _level(score: float) -> str:
    if score >= 0.7: return "high"
    if score >= 0.4: return "moderate"
    return "low"

async def disease_risk(field_id: int, crop: str, db: Session, tenant_id: int, days:int=365) -> Dict[str,Any]:
    field: Field|None = db.get(Field, field_id)
    if not field:
        return {"error":"field_not_found"}
    lat=float(field.latitude); lon=float(field.longitude)

    # weather daily forecast/history from agro_summary
    agro = await get_agro_summary(lat, lon, crop=crop, stage="mid")
    daily = agro.get("daily") or []

    rules_fn = CROP_RULES.get(crop.lower())
    if not rules_fn:
        return {"field_id": field_id, "crop": crop, "risk": [], "note":"no rules for this crop yet"}

    disease_list = rules_fn(daily)
    for d in disease_list:
        d["level"] = _level(float(d.get("score") or 0.0))

    # ndvi anomalies as stress driver
    ts=build_timeseries(db, field_id, tenant_id, days=days)
    baseline=monthly_climatology(ts["points"])
    anom=anomaly_series(ts["points"], baseline)
    recent_anom=[p["anomaly"] for p in anom[-4:] if p.get("anomaly") is not None]
    ndvi_driver=None
    if recent_anom:
        ndvi_driver=float(sum(recent_anom)/len(recent_anom))
    # soil salinity driver
    profiles=list_profiles(db, tenant_id)
    prof=next((p for p in profiles if p.field_id==field_id), None)
    salinity=(prof.ec_ds_m if prof else None)

    overall_score=float(max(d["score"] for d in disease_list)) if disease_list else 0.0
    # adjust overall by ndvi anomaly negative (stress)
    if ndvi_driver is not None and ndvi_driver < -0.05:
        overall_score=min(1.0, overall_score+0.1)
    if salinity is not None and salinity >= 4:
        overall_score=min(1.0, overall_score+0.1)

    return {
        "field": {"id": field.id, "name": field.name, "lat": lat, "lon": lon},
        "crop": crop,
        "overall_score": round(overall_score,3),
        "overall_level": _level(overall_score),
        "diseases": disease_list,
        "drivers": {
            "ndvi_recent_anomaly": ndvi_driver,
            "soil_ec_ds_m": salinity,
            "weather_days": len(daily)
        }
    }
