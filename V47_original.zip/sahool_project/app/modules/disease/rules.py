from __future__ import annotations
from typing import Dict, Any, List

# Each rule returns a risk score 0..1 and drivers.
# We use weather daily points and optional soil/stress info.

def _avg(points: List[Dict[str,Any]], key: str) -> float|None:
    vals=[p.get(key) for p in points if p.get(key) is not None]
    if not vals: return None
    return float(sum(vals)/len(vals))

def _sum(points: List[Dict[str,Any]], key: str) -> float:
    return float(sum(float(p.get(key) or 0.0) for p in points))

def wheat_rules(daily: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    tmean=_avg(daily[:7],"tmean") or _avg(daily[:7],"temp_mean")
    rain=_sum(daily[:7],"rain_sum")
    rh=_avg(daily[:7],"rh_mean") or _avg(daily[:7],"humidity_mean")
    rules=[]
    # Rust risk: mild temps + humidity
    score=0.0; drivers=[]
    if tmean is not None and 12<=tmean<=22: score+=0.4; drivers.append("mild_temp")
    if rh is not None and rh>=70: score+=0.4; drivers.append("high_humidity")
    if rain>=5: score+=0.2; drivers.append("rain_events")
    rules.append({"disease":"rust", "score": min(1.0,score), "drivers": drivers, "advice": [
        "Scout for pustules on leaves",
        "Avoid overhead irrigation at night",
        "If symptoms appear, consult local extension for fungicide choice"
    ]})
    # Powdery mildew: moderate temp + low rain but high humidity
    score=0.0; drivers=[]
    if tmean is not None and 15<=tmean<=25: score+=0.5; drivers.append("moderate_temp")
    if rh is not None and rh>=75: score+=0.4; drivers.append("very_humid")
    if rain<=2: score+=0.1; drivers.append("low_rain")
    rules.append({"disease":"powdery_mildew","score":min(1.0,score),"drivers":drivers,"advice":[
        "Increase air flow if possible",
        "Scout shaded areas first"
    ]})
    return rules

def corn_rules(daily: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    tmean=_avg(daily[:7],"tmean") or _avg(daily[:7],"temp_mean")
    rain=_sum(daily[:7],"rain_sum")
    rules=[]
    # Leaf blight: warm + wet
    score=0.0; drivers=[]
    if tmean is not None and tmean>=20: score+=0.4; drivers.append("warm_temp")
    if rain>=8: score+=0.6; drivers.append("wet_week")
    rules.append({"disease":"leaf_blight","score":min(1.0,score),"drivers":drivers,"advice":[
        "Scout lower leaves for lesions",
        "Avoid crowding; keep spacing"
    ]})
    return rules

def tomato_rules(daily: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    tmean=_avg(daily[:7],"tmean") or _avg(daily[:7],"temp_mean")
    rain=_sum(daily[:7],"rain_sum")
    rh=_avg(daily[:7],"rh_mean") or _avg(daily[:7],"humidity_mean")
    rules=[]
    # Late blight: cool + very wet
    score=0.0; drivers=[]
    if tmean is not None and 10<=tmean<=20: score+=0.4; drivers.append("cool_temp")
    if rain>=10: score+=0.4; drivers.append("heavy_rain")
    if rh is not None and rh>=85: score+=0.2; drivers.append("very_humid")
    rules.append({"disease":"late_blight","score":min(1.0,score),"drivers":drivers,"advice":[
        "Remove infected leaves promptly",
        "Avoid leaf wetness overnight"
    ]})
    # Early blight: warm + humid
    score=0.0; drivers=[]
    if tmean is not None and 18<=tmean<=28: score+=0.5; drivers.append("warm_temp")
    if rh is not None and rh>=75: score+=0.3; drivers.append("humid")
    if rain>=5: score+=0.2; drivers.append("rain_events")
    rules.append({"disease":"early_blight","score":min(1.0,score),"drivers":drivers,"advice":[
        "Mulch to reduce soil splash",
        "Rotate crops yearly"
    ]})
    return rules

CROP_RULES = {
    "wheat": wheat_rules,
    "corn": corn_rules,
    "maize": corn_rules,
    "tomato": tomato_rules,
}
