import datetime as dt
from sqlalchemy import Column, Integer, Date, Float, ForeignKey, UniqueConstraint, DateTime, JSON
from app.core.db import Base
from app.core.tenant_mixin import TenantMixin

class SoilWaterBalance(TenantMixin, Base):
    __tablename__="soil_water_balances"
    __table_args__=(UniqueConstraint("tenant_id","field_id","date", name="uq_swb_field_date"),)

    id=Column(Integer, primary_key=True)
    field_id=Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)
    date=Column(Date, index=True, nullable=False)
    created_at=Column(DateTime, default=dt.datetime.utcnow)

    et0_mm=Column(Float)
    kc=Column(Float)
    crop_et_mm=Column(Float)
    rain_mm=Column(Float)
    irrigation_mm=Column(Float)

    soil_moisture_mm=Column(Float)
    soil_moisture_frac=Column(Float)

    raw=Column(JSON, default=dict)
