import datetime as dt
from sqlalchemy import Column, Integer, Date, String, Float, ForeignKey, JSON, UniqueConstraint
from sqlalchemy.orm import relationship
from app.core.db import Base
from app.core.tenant_mixin import TenantMixin

class CropCalendar(TenantMixin, Base):
    __tablename__="crop_calendars"
    __table_args__=(UniqueConstraint("tenant_id","field_id","season_start", name="uq_crop_calendar_season"),)

    id=Column(Integer, primary_key=True)
    field_id=Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)

    crop_name=Column(String, nullable=False)
    variety=Column(String)

    season_start=Column(Date, nullable=False)
    season_end=Column(Date)
    planting_date=Column(Date)
    harvest_date=Column(Date)

    # day-based fallback
    stage_0_days=Column(Integer, default=0)
    stage_1_days=Column(Integer, default=20)
    stage_2_days=Column(Integer, default=50)
    stage_3_days=Column(Integer, default=80)
    stage_4_days=Column(Integer, default=110)

    # GDD params
    base_temp_c=Column(Float, default=10.0)
    gdd_stage_1=Column(Float, default=250.0)
    gdd_stage_2=Column(Float, default=600.0)
    gdd_stage_3=Column(Float, default=900.0)
    gdd_stage_4=Column(Float, default=1200.0)

    notes=Column(JSON, default=dict)

    field=relationship("Field", back_populates="crop_calendars")


class SoilProfile(TenantMixin, Base):
    __tablename__="soil_profiles"
    __table_args__=(UniqueConstraint("tenant_id","field_id", name="uq_soil_profile_field"),)

    id=Column(Integer, primary_key=True)
    field_id=Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)

    texture=Column(String)
    depth_cm=Column(Float)
    awc_mm=Column(Float)     # available water capacity (mm bucket)
    organic_matter_pct=Column(Float)
    ph=Column(Float)

    field=relationship("Field", back_populates="soil_profile")
