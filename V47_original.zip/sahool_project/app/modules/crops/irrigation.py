import datetime as dt
from sqlalchemy import Column, Integer, Date, Float, ForeignKey, UniqueConstraint, DateTime, JSON, String
from app.core.db import Base
from app.core.tenant_mixin import TenantMixin

class IrrigationEvent(TenantMixin, Base):
    __tablename__="irrigation_events"
    __table_args__=(UniqueConstraint("tenant_id","field_id","date", name="uq_irrig_event_field_date"),)

    id=Column(Integer, primary_key=True)
    field_id=Column(Integer, ForeignKey("fields.id"), index=True, nullable=False)
    date=Column(Date, index=True, nullable=False)
    amount_mm=Column(Float, nullable=False)
    method=Column(String)
    created_at=Column(DateTime, default=dt.datetime.utcnow)
    meta=Column(JSON, default=dict)
