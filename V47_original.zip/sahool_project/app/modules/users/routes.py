from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import hash_password, create_access_token
from app.modules.tenants.models import Tenant
from .models import User, Membership
from .schemas import UserCreate, UserOut

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/", response_model=UserOut, summary="Register a new user")
def register(data: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(400, "Email already registered")

    user = User(
        email=data.email,
        full_name=data.full_name,
        hashed_password=hash_password(data.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # if no tenants exist, auto-create a personal tenant and make user owner
    tenant = db.query(Tenant).filter(Tenant.slug == f"user-{user.id}").first()
    if not tenant:
        tenant = Tenant(name=f"{user.full_name or user.email}'s Farm", slug=f"user-{user.id}")
        db.add(tenant)
        db.commit()
        db.refresh(tenant)

    mem = Membership(tenant_id=tenant.id, user_id=user.id, role="owner")
    db.add(mem)
    db.commit()

    return user
