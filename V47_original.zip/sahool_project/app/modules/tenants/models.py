from sqlalchemy import Column, BigInteger, Text, Boolean, DateTime
from sqlalchemy.sql import func
from app.core.db import Base

class Tenant(Base):
    __tablename__ = "tenants"
    id = Column(BigInteger, primary_key=True)
    name = Column(Text, nullable=False)
    slug = Column(Text, unique=True, nullable=False)
    plan = Column(Text, default="free")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
