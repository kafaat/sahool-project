from pydantic import BaseModel
from typing import Optional, Dict, Any

class SoilProfileIn(BaseModel):
    field_id: int
    sand_pct: Optional[float]=None
    silt_pct: Optional[float]=None
    clay_pct: Optional[float]=None
    bulk_density: Optional[float]=None
    porosity_pct: Optional[float]=None
    color: Optional[str]=None
    ph: Optional[float]=None
    ec_ds_m: Optional[float]=None
    som_pct: Optional[float]=None
    n_ppm: Optional[float]=None
    p_ppm: Optional[float]=None
    k_ppm: Optional[float]=None
    micronutrients: Optional[Dict[str,Any]]=None
    cec_cmol_kg: Optional[float]=None
    soc_pct: Optional[float]=None
    soil_respiration: Optional[float]=None
    microbial_biomass: Optional[float]=None
    meta: Optional[Dict[str,Any]]=None
