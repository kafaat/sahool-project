from fastapi import APIRouter, Depends, Response
from app.modules.auth.deps import require_tenant, require_role
from .tile_render import render_ph_tile, render_ec_tile, render_som_tile

router = APIRouter(prefix="/soil/tiles", tags=["soil-tiles"], dependencies=[Depends(require_tenant), Depends(require_role("soil.read"))])

@router.get("/ph/{z}/{x}/{y}.png")
async def ph_tile(z:int,x:int,y:int, tenant=Depends(require_tenant)):
    return Response(content=await render_ph_tile(z,x,y,tenant["tenant_id"]), media_type="image/png")

@router.get("/ec/{z}/{x}/{y}.png")
async def ec_tile(z:int,x:int,y:int, tenant=Depends(require_tenant)):
    return Response(content=await render_ec_tile(z,x,y,tenant["tenant_id"]), media_type="image/png")

@router.get("/som/{z}/{x}/{y}.png")
async def som_tile(z:int,x:int,y:int, tenant=Depends(require_tenant)):
    return Response(content=await render_som_tile(z,x,y,tenant["tenant_id"]), media_type="image/png")


@router.get("/tiles/{metric}/{depth}/{z}/{x}/{y}.png")
async def soil_tile_depth(metric: str, depth: str, z: int, x: int, y: int, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    return await _tile(metric, z, x, y, db, tenant["tenant_id"], depth=depth)
