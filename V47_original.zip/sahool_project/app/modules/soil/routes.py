from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from app.modules.soil.schemas import SoilProfileIn
from app.modules.soil.service import upsert_profile, list_profiles

router = APIRouter(prefix="/soil", tags=["soil"], dependencies=[Depends(require_tenant), Depends(require_role("soil.read"))])

@router.get("")
def list_soil(db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    rows = list_profiles(db, tenant["tenant_id"])
    return {"items": [r.__dict__ for r in rows]}

@router.post("")
def save_soil(body: SoilProfileIn, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    row = upsert_profile(db, tenant["tenant_id"], body.model_dump())
    if not row:
        raise HTTPException(404, "field not found")
    return {"item": row.__dict__}
