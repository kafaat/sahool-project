from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from .service import list_profiles
from .suitability import suitability_report

router = APIRouter(prefix="/soil", tags=["soil-suitability"], dependencies=[Depends(require_tenant), Depends(require_role("soil.read"))])

@router.get("/suitability")
def get_suitability(field_id: int, crop: str|None=None, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    profiles = list_profiles(db, tenant["tenant_id"])
    prof = next((p for p in profiles if p.field_id==field_id), None)
    if not prof:
        raise HTTPException(404, "soil profile not found")
    return suitability_report(prof, crop)


@router.get("/fertility")
def get_fertility(field_id: int, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    profiles = list_profiles(db, tenant["tenant_id"])
    prof = next((p for p in profiles if p.field_id==field_id), None)
    if not prof:
        raise HTTPException(404, "soil profile not found")
    from .suitability import fertility_index, fertilizer_hints
    return {"field_id": field_id, "fertility_index": fertility_index(prof), "fertilizer_hints": fertilizer_hints(prof)}


@router.get("/analysis")
def get_analysis(field_id: int, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    profiles = list_profiles(db, tenant["tenant_id"])
    prof = next((p for p in profiles if p.field_id==field_id), None)
    if not prof:
        raise HTTPException(404, "soil profile not found")
    from .analysis import analysis_report
    return analysis_report(prof)

@router.get("/recommendations")
def get_soil_recommendations(field_id: int, db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    profiles = list_profiles(db, tenant["tenant_id"])
    prof = next((p for p in profiles if p.field_id==field_id), None)
    if not prof:
        raise HTTPException(404, "soil profile not found")
    from .analysis import irrigation_recommendation_from_soil
    from .suitability import fertilizer_hints
    return {
        "field_id": field_id,
        "fertilizer_hints": fertilizer_hints(prof),
        "irrigation_from_soil": irrigation_recommendation_from_soil(prof)
    }
