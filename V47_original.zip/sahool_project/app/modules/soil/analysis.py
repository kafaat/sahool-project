from __future__ import annotations
from typing import Dict, Any, Tuple, List
from .models import SoilProfile
import math

def texture_class(sand: float|None, silt: float|None, clay: float|None) -> str:
    if sand is None or silt is None or clay is None:
        return "unknown"
    if clay >= 40: return "clay"
    if sand >= 70: return "sandy"
    if 20 <= clay <= 35 and sand <= 45: return "loam"
    return "balanced"

def awc_mm_per_m(profile: SoilProfile) -> float:
    # very simplified AWC based on texture + SOM
    sand = profile.sand_pct or 0
    clay = profile.clay_pct or 0
    som = profile.som_pct or 0
    base = 80 + clay*1.0 - sand*0.4  # mm/m
    base += som*8
    return float(max(30, min(220, base)))

def salinity_class(ec: float|None) -> str:
    if ec is None: return "unknown"
    if ec < 2: return "low"
    if ec < 4: return "moderate"
    if ec < 8: return "high"
    return "extreme"

def infiltration_risk(profile: SoilProfile) -> str:
    tex = texture_class(profile.sand_pct, profile.silt_pct, profile.clay_pct)
    if tex=="clay": return "low"
    if tex=="sandy": return "high"
    return "moderate"

def soil_health_score(profile: SoilProfile) -> int:
    score=0
    # SOM
    som=profile.som_pct or 0
    score += 30 if som>=3 else 20 if som>=1.5 else 10
    # pH
    ph=profile.ph
    if ph is not None:
        score += 30 if 6<=ph<=7.5 else 20 if 5.5<=ph<=8.0 else 10
    # EC
    ec=profile.ec_ds_m
    if ec is not None:
        score += 25 if ec<2 else 15 if ec<4 else 5
    # texture bonus
    tex=texture_class(profile.sand_pct, profile.silt_pct, profile.clay_pct)
    score += 10 if tex=="loam" else 5 if tex=="balanced" else 0
    return int(max(0,min(100,score)))

def analysis_report(profile: SoilProfile) -> Dict[str,Any]:
    return {
        "texture_class": texture_class(profile.sand_pct, profile.silt_pct, profile.clay_pct),
        "awc_mm_per_m": awc_mm_per_m(profile),
        "salinity_class": salinity_class(profile.ec_ds_m),
        "infiltration_risk": infiltration_risk(profile),
        "soil_health_score": soil_health_score(profile),
    }

def irrigation_recommendation_from_soil(profile: SoilProfile) -> Dict[str,Any]:
    awc = awc_mm_per_m(profile)
    risk = infiltration_risk(profile)
    # default root depth 0.6 m
    total_awc = awc * 0.6
    freq_days = 2 if risk=="high" else 5 if risk=="low" else 3
    return {
        "available_water_mm": round(total_awc,2),
        "suggested_frequency_days": freq_days,
        "notes": "Adjust by crop stage and ET₀"
    }
