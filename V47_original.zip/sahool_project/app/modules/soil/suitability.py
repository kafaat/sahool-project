
def select_depth_profile(profile: SoilProfile, depth: str="surface") -> SoilProfile:
    # create a lightweight view using depth-specific values if available
    if depth=="surface" or profile is None:
        return profile
    clone = profile
    if depth=="0-30":
        clone.ph = profile.ph_0_30 or profile.ph
        clone.ec_ds_m = profile.ec_0_30 or profile.ec_ds_m
        clone.som_pct = profile.som_0_30 or profile.som_pct
    elif depth=="30-60":
        clone.ph = profile.ph_30_60 or profile.ph
        clone.ec_ds_m = profile.ec_30_60 or profile.ec_ds_m
        clone.som_pct = profile.som_30_60 or profile.som_pct
    elif depth=="60-100":
        clone.ph = profile.ph_60_100 or profile.ph
        clone.ec_ds_m = profile.ec_60_100 or profile.ec_ds_m
        clone.som_pct = profile.som_60_100 or profile.som_pct
    return clone

from __future__ import annotations
from typing import Dict, Any, List, Tuple
from .models import SoilProfile

def _score_ph(ph: float|None)->int:
    if ph is None: return 0
    if 6.0 <= ph <= 7.5: return 30
    if 5.5 <= ph < 6.0 or 7.5 < ph <= 8.0: return 20
    return 10

def _score_ec(ec: float|None)->int:
    if ec is None: return 0
    if ec < 2: return 25
    if ec < 4: return 15
    return 5

def _score_som(som: float|None)->int:
    if som is None: return 0
    if som >= 3: return 25
    if som >= 1.5: return 15
    return 8

def _score_texture(sand: float|None, silt: float|None, clay: float|None) -> Tuple[int,str]:
    if sand is None or silt is None or clay is None:
        return 0, "unknown"
    # basic USDA-like heuristic classes
    if clay >= 40:
        return -5, "clay"
    if sand >= 70:
        return -3, "sandy"
    if 20 <= clay <= 35 and sand <= 45:
        return 5, "loam"
    return 2, "balanced"

def suitability_score(profile: SoilProfile)->int:
    s=0
    s+=_score_ph(profile.ph)
    s+=_score_ec(profile.ec_ds_m)
    s+=_score_som(profile.som_pct)
    tex_score,_=_score_texture(profile.sand_pct, profile.silt_pct, profile.clay_pct)
    s+=tex_score
    return max(0, min(100, s))

CROP_PREFS = {
    "wheat": {"ph": (6.0,7.5), "ec_max": 6, "texture": ("balanced","loam")},
    "corn": {"ph": (5.8,7.5), "ec_max": 4, "texture": ("loam","balanced")},
    "tomato": {"ph": (6.0,7.2), "ec_max": 3, "texture": ("loam","balanced")},
    "cotton": {"ph": (5.5,8.0), "ec_max": 7, "texture": ("balanced","clay")},
    "rice": {"ph": (5.5,7.5), "ec_max": 5, "texture": ("clay","balanced")},
}

def crop_score(profile: SoilProfile, crop: str)->int:
    base=suitability_score(profile)
    pref=CROP_PREFS.get(crop.lower())
    if not pref: return base
    # ph
    if profile.ph is not None:
        lo,hi=pref["ph"]
        if not (lo<=profile.ph<=hi): base-=10
    # salinity
    if profile.ec_ds_m is not None and profile.ec_ds_m>pref["ec_max"]:
        base-=10
    # texture
    _,tex=_score_texture(profile.sand_pct, profile.silt_pct, profile.clay_pct)
    if tex!="unknown" and tex not in pref["texture"]:
        base-=5
    return max(0,min(100,base))

def best_crops(profile: SoilProfile)->List[str]:
    scores=[(c,crop_score(profile,c)) for c in CROP_PREFS.keys()]
    scores.sort(key=lambda x:x[1], reverse=True)
    return [c for c,_ in scores[:3]]

def fertility_index(profile: SoilProfile)->int:
    # simple NPK + SOM + CEC composite 0-100
    score=0
    if profile.som_pct is not None:
        score += min(30, profile.som_pct*10)
    if profile.cec_cmol_kg is not None:
        score += min(20, profile.cec_cmol_kg)
    for v in [profile.n_ppm, profile.p_ppm, profile.k_ppm]:
        if v is not None:
            score += min(50/3, float(v)/10)
    return int(max(0,min(100,score)))

def fertilizer_hints(profile: SoilProfile)->List[str]:
    hints=[]
    if profile.n_ppm is not None and profile.n_ppm < 20:
        hints.append("Nitrogen low: add N fertilizer or compost")
    if profile.p_ppm is not None and profile.p_ppm < 10:
        hints.append("Phosphorus low: add P source (e.g., MAP/DAP)")
    if profile.k_ppm is not None and profile.k_ppm < 120:
        hints.append("Potassium low: add K source (e.g., SOP/MOP)")
    if profile.som_pct is not None and profile.som_pct < 1.5:
        hints.append("Organic matter low: add manure/cover crops")
    return hints

def suitability_report(profile: SoilProfile, crop: str|None=None)->Dict[str,Any]:
    _,tex=_score_texture(profile.sand_pct, profile.silt_pct, profile.clay_pct)
    rep={
        "score": suitability_score(profile),
        "texture_class": tex,
        "fertility_index": fertility_index(profile),
        "best_crops": best_crops(profile),
        "fertilizer_hints": fertilizer_hints(profile),
    }
    if crop:
        rep["crop"]=crop
        rep["crop_score"]=crop_score(profile,crop)
    warnings=[]
    if profile.ec_ds_m is not None and profile.ec_ds_m>=4: warnings.append("High salinity (EC)")
    if profile.ph is not None and (profile.ph<5.5 or profile.ph>8.0): warnings.append("pH out of optimal range")
    if tex=="clay": warnings.append("Heavy clay may reduce infiltration")
    if tex=="sandy": warnings.append("Sandy soil may need frequent irrigation")
    rep["warnings"]=warnings
    return rep
