
DEPTH_KEYS = {
    "0-30": {"ph":"ph_0_30", "ec_ds_m":"ec_0_30", "som_pct":"som_0_30"},
    "30-60": {"ph":"ph_30_60", "ec_ds_m":"ec_30_60", "som_pct":"som_30_60"},
    "60-100": {"ph":"ph_60_100", "ec_ds_m":"ec_60_100", "som_pct":"som_60_100"},
    "surface": {"ph":"ph", "ec_ds_m":"ec_ds_m", "som_pct":"som_pct"},
}

from __future__ import annotations
import io, math, time
from typing import Tuple, List
import numpy as np
from PIL import Image
from redis import Redis
from app.core.config import settings
from .service import list_profiles

redis = Redis.from_url(settings.redis_url)
TILE_SIZE=256

def _tile_bounds(z:int,x:int,y:int)->Tuple[float,float,float,float]:
    n=2.0**z
    lon_min=x/n*360.0-180.0
    lon_max=(x+1)/n*360.0-180.0
    def lat_from_y(yy):
        lat_rad=math.atan(math.sinh(math.pi*(1-2*yy/n)))
        return math.degrees(lat_rad)
    lat_max=lat_from_y(y); lat_min=lat_from_y(y+1)
    return lat_min, lat_max, lon_min, lon_max

METRIC_RANGES = {'ph': (4.5, 9.0), 'ec_ds_m': (0.0, 8.0), 'som_pct': (0.0, 5.0)}

def _colorize(val: float, vmin: float, vmax: float, metric: str):
    if val is None or math.isnan(val): return (0,0,0,0)
    if vmax<=vmin: vmax=vmin+1
    t=max(0,min(1,(val-vmin)/(vmax-vmin)))
    r=int(255*t); g=int(255*(1-t)); b=50
    return (r,g,b,170)

def _idw(lat_grid, lon_grid, pts):
    # pts: list of (lat,lon,val)
    out=np.zeros((len(lat_grid),len(lon_grid)),dtype=float)
    for i,la in enumerate(lat_grid):
        for j,lo in enumerate(lon_grid):
            num=0.0; den=0.0
            for pla,plo,v in pts:
                d=((pla-la)**2 + (plo-lo)**2)**0.5 + 1e-6
                w=1.0/(d*d)
                num+=w*v; den+=w
            out[i,j]=num/den if den else float("nan")
    return out

async def render_soil_tile(metric:str, z:int,x:int,y:int, tenant_id:int)->bytes:
    day=int(time.time()//86400)
    key=f"soil_tile:{metric}:{tenant_id}:{z}:{x}:{y}:{day}"
    c=redis.get(key)
    if c: return c

    lat_min,lat_max,lon_min,lon_max=_tile_bounds(z,x,y)
    lat_grid=np.linspace(lat_min,lat_max,20)
    lon_grid=np.linspace(lon_min,lon_max,20)

    # gather active profiles with coords
    from app.core.db import SessionLocal
    db=SessionLocal()
    profiles=list_profiles(db, tenant_id)
    pts=[]
    for p in profiles:
        try:
            la=float(p.field.latitude); lo=float(p.field.longitude)
            v=getattr(p, metric)
            if v is None: continue
            pts.append((la,lo,float(v)))
        except Exception:
            continue
    db.close()

    if not pts:
        img=Image.new("RGBA",(TILE_SIZE,TILE_SIZE),(0,0,0,0))
    else:
        arr=_idw(lat_grid,lon_grid,pts)
        mr=METRIC_RANGES.get(metric)
        vmin,vmax = mr if mr else (float(np.nanmin(arr)), float(np.nanmax(arr)))
        h,w=arr.shape
        img=Image.new("RGBA",(TILE_SIZE,TILE_SIZE)); px=img.load()
        for iy in range(TILE_SIZE):
            for ix in range(TILE_SIZE):
                gy=int(iy/(TILE_SIZE-1)*(h-1)) if h>1 else 0
                gx=int(ix/(TILE_SIZE-1)*(w-1)) if w>1 else 0
                px[ix,iy]=_colorize(float(arr[gy,gx]),vmin,vmax,metric)

    buf=io.BytesIO(); img.save(buf, format="PNG", optimize=True)
    out=buf.getvalue()
    redis.setex(key, 3600, out)
    return out

async def render_ph_tile(z,x,y,tenant_id): return await render_soil_tile("ph",z,x,y,tenant_id)
async def render_ec_tile(z,x,y,tenant_id): return await render_soil_tile("ec_ds_m",z,x,y,tenant_id)
async def render_som_tile(z,x,y,tenant_id): return await render_soil_tile("som_pct",z,x,y,tenant_id)
