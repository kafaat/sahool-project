from __future__ import annotations
import datetime
from sqlalchemy import Column, Integer, Float, String, DateTime, ForeignKey, JSON, Boolean
from sqlalchemy.orm import relationship
from app.core.db import Base

class SoilProfile(Base):
    __tablename__="soil_profiles"
    id=Column(Integer, primary_key=True)
    tenant_id=Column(Integer, ForeignKey("tenants.id"), nullable=False)
    field_id=Column(Integer, ForeignKey("fields.id"), nullable=False)

    sand_pct=Column(Float, nullable=True)
    silt_pct=Column(Float, nullable=True)
    clay_pct=Column(Float, nullable=True)
    bulk_density=Column(Float, nullable=True)
    porosity_pct=Column(Float, nullable=True)
    color=Column(String(32), nullable=True)

    ph=Column(Float, nullable=True)
    ec_ds_m=Column(Float, nullable=True)
    som_pct=Column(Float, nullable=True)
    n_ppm=Column(Float, nullable=True)
    p_ppm=Column(Float, nullable=True)
    k_ppm=Column(Float, nullable=True)
    micronutrients=Column(JSON, nullable=True)
    cec_cmol_kg=Column(Float, nullable=True)

    soc_pct=Column(Float, nullable=True)
    soil_respiration=Column(Float, nullable=True)
    microbial_biomass=Column(Float, nullable=True)

    is_active=Column(Boolean, default=True)
    meta=Column(JSON, nullable=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

    field=relationship("Field")


# depth layers (0-30,30-60,60-100 cm). Optional.
ph_0_30 = Column(Float, nullable=True)
ph_30_60 = Column(Float, nullable=True)
ph_60_100 = Column(Float, nullable=True)

ec_0_30 = Column(Float, nullable=True)
ec_30_60 = Column(Float, nullable=True)
ec_60_100 = Column(Float, nullable=True)

som_0_30 = Column(Float, nullable=True)
som_30_60 = Column(Float, nullable=True)
som_60_100 = Column(Float, nullable=True)
