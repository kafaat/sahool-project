from sqlalchemy.orm import Session
from app.modules.soil.models import SoilProfile
from app.modules.fields.models import Field

def upsert_profile(db: Session, tenant_id: int, data: dict):
    field = db.get(Field, data["field_id"])
    if not field or field.tenant_id != tenant_id:
        return None
    row = db.query(SoilProfile).filter_by(field_id=field.id, tenant_id=tenant_id, is_active=True).first()
    if row:
        for k,v in data.items():
            if hasattr(row,k):
                setattr(row,k,v)
    else:
        row = SoilProfile(tenant_id=tenant_id, **data)
        db.add(row)
    db.commit(); db.refresh(row)
    return row

def list_profiles(db: Session, tenant_id: int):
    return db.query(SoilProfile).filter_by(tenant_id=tenant_id, is_active=True).order_by(SoilProfile.id.desc()).all()
