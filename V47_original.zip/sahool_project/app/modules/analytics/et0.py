from typing import Optional
import math, datetime as dt

def extraterrestrial_radiation_MJ_m2_day(lat_deg: float, day_of_year: int) -> float:
    lat = math.radians(lat_deg)
    dr = 1 + 0.033 * math.cos(2 * math.pi / 365 * day_of_year)
    delta = 0.409 * math.sin(2 * math.pi / 365 * day_of_year - 1.39)
    ws = math.acos(max(-1.0, min(1.0, -math.tan(lat) * math.tan(delta))))
    Gsc = 0.0820
    Ra = (24 * 60 / math.pi) * Gsc * dr * (
        ws * math.sin(lat) * math.sin(delta) + math.cos(lat) * math.cos(delta) * math.sin(ws)
    )
    return Ra

def et0_hargreaves(lat_deg: float, date: dt.date, tmax_c: Optional[float], tmin_c: Optional[float]) -> float:
    if tmax_c is None and tmin_c is None:
        return 0.0
    if tmax_c is None: tmax_c = tmin_c
    if tmin_c is None: tmin_c = tmax_c
    tmean=(tmax_c+tmin_c)/2.0
    td=max(0.0, tmax_c-tmin_c)
    Ra=extraterrestrial_radiation_MJ_m2_day(lat_deg, date.timetuple().tm_yday)
    et0=0.0023*Ra*(tmean+17.8)*math.sqrt(td)
    return max(0.0, et0)
