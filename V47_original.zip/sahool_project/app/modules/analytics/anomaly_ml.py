import math
DEFAULT_WEIGHTS = {"bias": -1.0, "water_stress": 2.0, "heat_stress": 1.5, "ndvi_drop": 2.5, "rain_spike": 1.0}
def sigmoid(x: float)->float: return 1/(1+math.exp(-x))
def build_features(ndvi_today, ndvi_baseline, water_stress, heat_stress, rain_mm):
    feats={}
    if ndvi_today is not None and ndvi_baseline is not None and ndvi_baseline>1e-6:
        feats["ndvi_drop"]=max(0.0,(ndvi_baseline-ndvi_today)/ndvi_baseline)
    if water_stress is not None: feats["water_stress"]=water_stress
    if heat_stress is not None: feats["heat_stress"]=heat_stress
    if rain_mm is not None: feats["rain_spike"]=min(1.0, rain_mm/30.0)
    return feats
def classify_anomaly(features, weights=DEFAULT_WEIGHTS):
    if not features: return None
    z=weights.get("bias",0.0)
    for k,v in features.items():
        if v is None: continue
        z+=weights.get(k,0.0)*float(v)
    return sigmoid(z)
