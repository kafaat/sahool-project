from app.modules.auth.deps import require_tenant
import datetime as dt
from typing import Dict, Any
from fastapi import APIRouter, Depends, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.core.security import get_tenant_id_open
from app.modules.fields.models import Field
from app.modules.analytics.yield_model import calibrate_yield_model
from app.modules.analytics.anomaly_ml import DEFAULT_WEIGHTS


class YieldCalibrationIn(BaseModel):
    field_id: int
    season_start: dt.date
    season_end: dt.date
    actual_yield_kg_per_ha: float

class AnomalyWeightsIn(BaseModel):
    weights: Dict[str, Any]

@router.post("/yield/calibrate")
def yield_calibrate(payload: YieldCalibrationIn, db: Session = Depends(get_db), tenant_id: int = Depends(get_tenant_id_open)):
    field = db.query(Field).filter(Field.id == payload.field_id, Field.tenant_id == tenant_id).first()
    if not field:
        raise HTTPException(404, "Field not found")
    res = calibrate_yield_model(db, field, payload.season_start, payload.season_end, payload.actual_yield_kg_per_ha)
    if not res:
        raise HTTPException(400, "Calibration failed")
    return {"status": "ok", "calibration": res}

@router.get("/anomaly/weights")
def get_weights():
    return {"weights": DEFAULT_WEIGHTS}

@router.post("/anomaly/weights")
def update_weights(payload: AnomalyWeightsIn):
    DEFAULT_WEIGHTS.update(payload.weights or {})
    return {"status": "ok", "weights": DEFAULT_WEIGHTS}


@router.post("/anomalies/ndvi/latest")
def anomalies_latest(field_id: int):
    from app.workers.tasks import anomaly_ndvi_task
    task = anomaly_ndvi_task.delay(field_id)
    return {"task_id": task.id}


@router.post("/anomalies/index/latest")
def anomalies_index_latest(field_id: int, index_name: str="ndvi"):
    from app.workers.tasks import anomaly_index_task
    task = anomaly_index_task.delay(field_id, index_name)
    return {"task_id": task.id}


@router.get("/crop-type/latest")
def crop_type_latest(field_id: int, db: Session = Depends(get_db)):
    from app.modules.satellite.models import NDVIResult
    r = db.query(NDVIResult).filter_by(field_id=field_id).order_by(NDVIResult.processed_at.desc()).first()
    if not r:
        raise HTTPException(404, "No results")
    feats = {
        "ndvi_mean": (r.stats or {}).get("ndvi_stats", {}).get("mean") or (r.stats or {}).get("mean_ndvi"),
        "ndre_mean": (r.stats or {}).get("ndre_stats", {}).get("mean")
    }
    return classify_crop(feats)
