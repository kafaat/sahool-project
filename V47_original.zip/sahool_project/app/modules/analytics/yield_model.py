import datetime as dt
from sqlalchemy.orm import Session
from app.modules.satellite.fused_models import SatelliteIndexRecord
from app.modules.crops.models import CropCalendar

def estimate_yield_kg_per_ha(db: Session, field, date: dt.date, window_days: int=60):
    start=date-dt.timedelta(days=window_days)
    series=(db.query(SatelliteIndexRecord.ndvi_mean)
              .filter(SatelliteIndexRecord.field_id==field.id,
                      SatelliteIndexRecord.tenant_id==field.tenant_id,
                      SatelliteIndexRecord.date>=start,
                      SatelliteIndexRecord.date<=date)
              .all())
    vals=[v[0] for v in series if v and v[0] is not None]
    if len(vals)<5: return None
    integral=sum(vals)
    A,B=800.0,0.0
    cal=(db.query(CropCalendar)
           .filter(CropCalendar.field_id==field.id,
                   CropCalendar.tenant_id==field.tenant_id)
           .order_by(CropCalendar.season_start.desc()).first())
    if cal and cal.notes:
        A=float(cal.notes.get("yield_A",A)); B=float(cal.notes.get("yield_B",B))
    return round(A*integral+B,2)

def calibrate_yield_model(db: Session, field, season_start: dt.date, season_end: dt.date, actual_yield_kg_per_ha: float):
    series=(db.query(SatelliteIndexRecord.ndvi_mean)
              .filter(SatelliteIndexRecord.field_id==field.id,
                      SatelliteIndexRecord.tenant_id==field.tenant_id,
                      SatelliteIndexRecord.date>=season_start,
                      SatelliteIndexRecord.date<=season_end)
              .all())
    vals=[v[0] for v in series if v and v[0] is not None]
    if not vals: return None
    integral=sum(vals)
    if integral<=1e-6: return None
    A=actual_yield_kg_per_ha/integral
    cal=(db.query(CropCalendar)
           .filter(CropCalendar.field_id==field.id,
                   CropCalendar.tenant_id==field.tenant_id,
                   CropCalendar.season_start==season_start).first())
    if not cal:
        cal=CropCalendar(field_id=field.id, tenant_id=field.tenant_id, crop_name="unknown", season_start=season_start)
        db.add(cal)
    cal.notes=cal.notes or {}
    cal.notes["yield_A"]=float(A); cal.notes["yield_B"]=0.0
    db.commit()
    return {"yield_A":A}
