from __future__ import annotations
from typing import Dict, Any

def classify_crop(features: Dict[str, Any]) -> Dict[str, Any]:
    """Simple heuristic stub. Replace with ML later."""
    ndvi_mean = features.get("ndvi_mean", 0)
    ndre_mean = features.get("ndre_mean", 0)
    if ndvi_mean > 0.6 and ndre_mean > 0.4:
        crop="dense_vegetation"
    elif ndvi_mean > 0.3:
        crop="moderate_crop"
    else:
        crop="sparse_or_bare"
    return {"crop_type": crop, "confidence": 0.55}
