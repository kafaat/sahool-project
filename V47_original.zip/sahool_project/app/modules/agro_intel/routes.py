from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from .service import build_agro_ai
from .report_pdf import build_zones_report

router = APIRouter(
    prefix="/agro",
    tags=["Agro-Intel"],
    dependencies=[Depends(require_tenant), Depends(require_role("agro.read"))],
)

@router.get("/ai")
async def agro_ai(field_id: int, crop: str, stage: str = "mid", db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    return await build_agro_ai(field_id, crop, stage, db, tenant["tenant_id"])


@router.get("/report.pdf")
async def agro_report(field_id: int, crop: str, stage: str = "mid", db: Session = Depends(get_db), tenant=Depends(require_tenant)):
    data = await build_agro_ai(field_id, crop, stage, db, tenant["tenant_id"])
    if "error" in data:
        return data
    pdf = build_zones_report(data)
    from fastapi import Response
    return Response(content=pdf, media_type="application/pdf")
