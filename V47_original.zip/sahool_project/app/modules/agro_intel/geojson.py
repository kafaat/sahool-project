from __future__ import annotations
from typing import Dict, Any, List, Tuple

def bbox_to_polygon(bbox: Tuple[float,float,float,float]) -> Dict[str,Any]:
    # bbox = (lat_min, lat_max, lon_min, lon_max)
    lat_min, lat_max, lon_min, lon_max = bbox
    coords = [
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]
    return {"type": "Polygon", "coordinates": [coords]}

def zones_to_feature_collection(zone_polys: List[Dict[str,Any]]) -> Dict[str,Any]:
    feats=[]
    for z in zone_polys:
        poly=bbox_to_polygon(tuple(z["bbox"]))
        feats.append({
            "type":"Feature",
            "properties": {
                "level": z["level"],
                "area_fraction": z.get("area_fraction",0),
            },
            "geometry": poly
        })
    return {"type":"FeatureCollection","features":feats}
