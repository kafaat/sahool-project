from __future__ import annotations
from typing import Dict, Any, List

def pest_risk_from_weather(daily_points: List[Dict[str,Any]]) -> Dict[str,Any]:
    # Simple heuristic:
    # high risk if humid & warm with rain in next days
    if not daily_points:
        return {"level":"unknown","drivers":[]}
    warm_days=sum(1 for p in daily_points[:5] if (p.get("tmax") or 0) >= 28)
    humid_proxy=sum(1 for p in daily_points[:5] if (p.get("rain_sum") or 0) >= 1.0)
    drivers=[]
    level="low"
    if warm_days>=3: drivers.append("warm_days")
    if humid_proxy>=2: drivers.append("humid_rainy")
    if warm_days>=3 and humid_proxy>=2:
        level="high"
    elif warm_days>=2 and humid_proxy>=1:
        level="moderate"
    return {"level": level, "drivers": drivers}

def disease_notes(level:str)->List[str]:
    if level=="high":
        return ["Increase scouting frequency", "Consider preventive fungicide if crop susceptible"]
    if level=="moderate":
        return ["Scout field", "Avoid overhead irrigation at night"]
    return ["No special actions"]
