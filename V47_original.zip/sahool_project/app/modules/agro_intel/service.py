from __future__ import annotations
from typing import Dict, Any, List, Tuple
import io, math
import numpy as np
from PIL import Image
from sqlalchemy.orm import Session

from app.modules.fields.models import Field
from app.modules.soil.service import list_profiles
from app.modules.soil.suitability import suitability_report
from app.modules.soil.analysis import analysis_report, irrigation_recommendation_from_soil
from app.modules.weather.service import get_agro_summary, get_agro_alerts, get_irrigation_plan
from app.modules.weather.kc import get_kc
from app.modules.disease.service import disease_risk
from app.modules.ndvi.stress_tiles import render_ndvi_stress_tile
from .zones import grid_zones
from .geojson import zones_to_feature_collection
from .vectorize import vectorize_stress, feature_collection
from .yield_zones import yield_per_zone
from .soil_zone_stats import zone_stats
from .soil_spatial import sample_soil_at
from .pest_risk import pest_risk_from_weather, disease_notes
from .yield_model import predict_yield

def _stress_from_tile_png(png: bytes) -> Dict[str,float]:
    # classify stress by pixel colors produced in stress_worker
    im = Image.open(io.BytesIO(png)).convert("RGBA")
    arr = np.array(im)
    alpha = arr[...,3] > 0
    if not alpha.any():
        return {"high":0.0,"moderate":0.0,"low":0.0}
    red = (arr[...,0] > 200) & (arr[...,1] < 80) & alpha
    yellow = (arr[...,0] > 200) & (arr[...,1] > 150) & alpha
    green = (arr[...,1] > 150) & (arr[...,0] < 120) & alpha
    total = alpha.sum()
    return {
        "high": float(red.sum()/total),
        "moderate": float(yellow.sum()/total),
        "low": float(green.sum()/total),
    }

def _zone_recommendations(stress_frac: Dict[str,float], soil_rec: Dict[str,Any], weather_plan: List[Dict[str,Any]], kc: float) -> List[Dict[str,Any]]:
    # build 3 zones based on stress levels and adjust irrigation net
    zones=[]
    base_freq = soil_rec.get("suggested_frequency_days", 3)
    for level, mult in [("high",1.3), ("moderate",1.15), ("low",1.0)]:
        frac = stress_frac.get(level, 0.0)
        if frac <= 0.01:
            continue
        plan=[]
        for p in weather_plan:
            net=float(p.get("net_irrigation_mm") or 0.0)
            plan.append({**p, "net_zone_mm": net*mult, "gross_zone_mm": float(p.get("gross_irrigation_mm") or 0.0)*mult})
        zones.append({
            "level": level,
            "area_fraction": frac,
            "irrigation_multiplier": mult,
            "suggested_frequency_days": max(1, round(base_freq/(mult if mult>0 else 1))),
            "plan": plan
        })
    return zones

async def build_agro_ai(field_id: int, crop: str, stage: str, db: Session, tenant_id: int) -> Dict[str,Any]:
    field: Field | None = db.get(Field, field_id)
    if not field:
        return {"error":"field_not_found"}

    lat=float(field.latitude); lon=float(field.longitude)
    kc=get_kc(crop, stage)

    # weather layer
    agro_summary = await get_agro_summary(lat, lon, crop, stage)
    alerts = await get_agro_alerts(lat, lon, crop, stage)
    plan_out = await get_irrigation_plan(lat, lon, crop, stage, days=7)
    weather_plan = plan_out.get("plan", [])

    # soil layer (take profile for this field if exists)
    profiles = list_profiles(db, tenant_id)
    prof = next((p for p in profiles if p.field_id==field_id), None)
    soil_suit = suitability_report(prof, crop) if prof else None
    soil_analysis = analysis_report(prof) if prof else None
    soil_irrig = irrigation_recommendation_from_soil(prof) if prof else None

    # ndvi stress tile at z=14 center
    stress_frac={"high":0.0,"moderate":0.0,"low":0.0}
    try:
        import mercantile
        t = mercantile.tile(lon, lat, 14)
        png = await render_ndvi_stress_tile(t.z, t.x, t.y)
        stress_frac = _stress_from_tile_png(png)
    except Exception:
        pass

    zones = _zone_recommendations(stress_frac, soil_irrig or {}, weather_plan, kc)

    # disease risk
    disease = await disease_risk(field_id, crop, db, tenant_id)

    # field summary
    overall_health = 100.0
    if soil_analysis:
        overall_health = (overall_health*0.5 + soil_analysis.get("soil_health_score",70)*0.5)
    if soil_suit:
        overall_health = (overall_health*0.5 + soil_suit.get("score",70)*0.5)
    overall_health = max(0,min(100,overall_health))

    return {
        "field": {"id": field.id, "name": field.name, "lat": lat, "lon": lon},
        "crop": crop, "stage": stage, "kc": kc,
        "ndvi_stress": stress_frac,
        "zones": zones,
        "soil": {
            "suitability": soil_suit,
            "analysis": soil_analysis,
            "irrigation_from_soil": soil_irrig
        },
        "weather": {
            "live": agro_summary.get("live"),
            "daily": agro_summary.get("daily"),
            "irrigation_base": agro_summary.get("irrigation"),
            "alerts": alerts.get("alerts"),
            "deficit": alerts.get("deficit"),
            "plan": weather_plan
        },
        "field_summary": {
            "overall_health": overall_health,
            "salinity_risk": (soil_analysis or {}).get("salinity_class","unknown"),
            "water_deficit_mm_7d": (alerts.get("deficit") or {}).get("deficit_mm") if isinstance(alerts,dict) else None,
        }
    }
