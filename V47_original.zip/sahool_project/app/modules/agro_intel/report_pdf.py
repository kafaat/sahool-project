from __future__ import annotations
from typing import Dict, Any
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def build_zones_report(data: Dict[str,Any]) -> bytes:
    buf=BytesIO()
    c=canvas.Canvas(buf, pagesize=A4)
    w,h=A4
    y=h-60
    c.setFont("Helvetica-Bold", 16)
    c.drawString(40,y,"Agro Zones Report")
    y-=30
    field=data.get("field",{})
    c.setFont("Helvetica", 11)
    c.drawString(40,y,f"Field: {field.get('name')} (ID {field.get('id')})")
    y-=18
    c.drawString(40,y,f"Crop: {data.get('crop')}  Stage: {data.get('stage')}  Kc: {data.get('kc')}")
    y-=25

    fs=data.get("field_summary",{})
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40,y,"Field Summary")
    y-=16
    c.setFont("Helvetica", 10)
    for k in ["overall_health","salinity_risk","water_deficit_mm_7d"]:
        c.drawString(50,y,f"{k}: {fs.get(k)}")
        y-=14

    y-=8
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40,y,"Zones")
    y-=18
    c.setFont("Helvetica", 10)
    zones=data.get("zones_yield",[]) or []
    for z in zones:
        c.drawString(50,y,f"{z['level']}  area {z['area_fraction']*100:.1f}%  factor {z['factor']}  pred {z['predicted_t_ha']} t/ha")
        y-=14
        if y<80:
            c.showPage()
            y=h-60

    c.showPage()
    c.save()
    return buf.getvalue()
