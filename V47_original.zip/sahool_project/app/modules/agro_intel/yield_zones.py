from __future__ import annotations
from typing import Dict, Any, List

def zone_yield_factor(level: str, soil_health: float|None, salinity_class: str|None) -> float:
    f=1.0
    if level=="high": f*=0.75
    elif level=="moderate": f*=0.9
    else: f*=1.0
    if soil_health is not None:
        f*= (0.8 + 0.2*(soil_health/100.0))
    if salinity_class in ("high","extreme"):
        f*=0.9
    return f

def yield_per_zone(base_t_ha: float, zones_stats: List[Dict[str,Any]], soil_health: float|None, salinity_class: str|None) -> List[Dict[str,Any]]:
    out=[]
    for z in zones_stats:
        level=z.get("level")
        frac=float(z.get("area_fraction") or 0)
        f=zone_yield_factor(level, soil_health, salinity_class)
        out.append({
            "level": level,
            "area_fraction": frac,
            "factor": round(f,3),
            "predicted_t_ha": round(base_t_ha*f,2),
            "weighted_t_ha": round(base_t_ha*f*frac,2)
        })
    return out
