from __future__ import annotations
from typing import List, Dict, Any, Tuple
import numpy as np
from skimage import measure

def _contours_for_level(stress_arr: np.ndarray, level: int) -> List[np.ndarray]:
    mask = (stress_arr == level).astype(np.uint8)
    if mask.sum() < 10:
        return []
    # find contours at 0.5 boundary
    contours = measure.find_contours(mask, 0.5)
    return contours

def _pix_to_lonlat(poly: np.ndarray, bbox: Tuple[float,float,float,float]) -> List[List[float]]:
    lat_min, lat_max, lon_min, lon_max = bbox
    h = bbox_meta_h = None
    # poly is (N,2) in [y,x]
    ys = poly[:,0]; xs = poly[:,1]
    # infer grid size: use max as size-1
    h = float(max(ys.max(),1.0))
    w = float(max(xs.max(),1.0))
    coords=[]
    for y,x in zip(ys,xs):
        lat = lat_max - (y/(h))*(lat_max-lat_min)
        lon = lon_min + (x/(w))*(lon_max-lon_min)
        coords.append([float(lon), float(lat)])
    # close polygon
    if coords and coords[0]!=coords[-1]:
        coords.append(coords[0])
    return coords

def vectorize_stress(stress_arr: np.ndarray, bbox: Tuple[float,float,float,float]) -> List[Dict[str,Any]]:
    features=[]
    for level,name in [(3,"high"),(2,"moderate"),(1,"low")]:
        contours=_contours_for_level(stress_arr, level)
        for c in contours:
            coords=_pix_to_lonlat(c, bbox)
            if len(coords) < 4:
                continue
            features.append({
                "type":"Feature",
                "properties":{"level":name},
                "geometry":{"type":"Polygon","coordinates":[coords]}
            })
    return features

def feature_collection(features: List[Dict[str,Any]]) -> Dict[str,Any]:
    return {"type":"FeatureCollection","features":features}
