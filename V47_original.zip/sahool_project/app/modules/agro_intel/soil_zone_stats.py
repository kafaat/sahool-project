from __future__ import annotations
from typing import Dict, Any, Tuple
import numpy as np, io, math
from PIL import Image
import mercantile
from app.modules.soil.tile_render import render_soil_tile

async def _tile_array(metric: str, z:int,x:int,y:int, tenant_id:int) -> np.ndarray:
    png = await render_soil_tile(metric, z, x, y, tenant_id)
    im = Image.open(io.BytesIO(png)).convert("RGBA")
    arr = np.array(im)
    return arr

def _color_to_value(metric: str, r:int,g:int,b:int,a:int) -> float|None:
    if a==0: return None
    tnorm=r/255.0
    ranges={'ph':(4.5,9.0),'ec_ds_m':(0.0,8.0),'som_pct':(0.0,5.0)}
    vmin,vmax=ranges.get(metric,(0.0,1.0))
    return float(vmin + tnorm*(vmax-vmin))

async def zone_mean(metric: str, zone_bbox: Tuple[float,float,float,float], tenant_id:int, z:int=14) -> float|None:
    # mean of metric over rectangle by sampling tiles that intersect bbox
    lat_min,lat_max,lon_min,lon_max=zone_bbox
    tiles=list(mercantile.tiles(lon_min,lat_min,lon_max,lat_max,z))
    vals=[]
    for t in tiles:
        arr=await _tile_array(metric, t.z, t.x, t.y, tenant_id)
        alpha=arr[...,3]>0
        if not alpha.any(): 
            continue
        rs=arr[...,0][alpha]; gs=arr[...,1][alpha]; bs=arr[...,2][alpha]; al=arr[...,3][alpha]
        for r,g,b,a in zip(rs,gs,bs,al):
            v=_color_to_value(metric,int(r),int(g),int(b),int(a))
            if v is not None: vals.append(v)
    if not vals:
        return None
    return float(np.mean(vals))

async def zone_stats(zone_bbox, tenant_id:int)->Dict[str,Any]:
    ph=await zone_mean("ph", zone_bbox, tenant_id)
    ec=await zone_mean("ec_ds_m", zone_bbox, tenant_id)
    som=await zone_mean("som_pct", zone_bbox, tenant_id)
    # variability proxy
    var_idx=None
    if any(v is not None for v in [ph,ec,som]):
        vals=[v for v in [ph,ec,som] if v is not None]
        var_idx=float(np.std(vals)/ (np.mean(vals) if np.mean(vals)!=0 else 1))
    return {"ph_mean": ph, "ec_mean": ec, "som_mean": som, "variability_index": var_idx}
