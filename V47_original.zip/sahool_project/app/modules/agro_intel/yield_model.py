from __future__ import annotations
from typing import Dict, Any, List

BASE_YIELD_T_HA = {
    "wheat": 6.0,
    "corn": 9.0,
    "tomato": 60.0,
    "cotton": 3.5,
    "rice": 7.0,
}

def predict_yield(crop: str, soil_health: float|None, stress_high_frac: float, deficit_mm_7d: float|None) -> Dict[str,Any]:
    base=BASE_YIELD_T_HA.get(crop.lower(), 5.0)
    factor=1.0
    if soil_health is not None:
        factor *= (0.7 + 0.3*(soil_health/100.0))
    factor *= (1.0 - 0.5*min(1.0, stress_high_frac*2))  # high stress hurts
    if deficit_mm_7d is not None:
        factor *= (1.0 - min(0.25, deficit_mm_7d/100.0))
    pred=base*factor
    return {"crop": crop, "base_t_ha": base, "factor": round(factor,3), "predicted_t_ha": round(pred,2)}
