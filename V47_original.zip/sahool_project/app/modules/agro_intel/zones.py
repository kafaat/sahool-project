from __future__ import annotations
from typing import List, Dict, Any, Tuple
import numpy as np

def classify_stress(arr: np.ndarray) -> np.ndarray:
    # arr uint8 0..3 -> 0 nodata, 1 low, 2 moderate, 3 high
    return arr

def grid_zones(stress_arr: np.ndarray, bbox: Tuple[float,float,float,float], cell: int = 16) -> List[Dict[str,Any]]:
    '''
    Make coarse zone "polygons" as rectangles in lat/lon grid.
    Returns list of {level, bbox, area_fraction}
    '''
    lat_min, lat_max, lon_min, lon_max = bbox
    h,w = stress_arr.shape
    zones=[]
    total=np.count_nonzero(stress_arr)
    if total==0:
        return zones
    for level,name in [(3,"high"),(2,"moderate"),(1,"low")]:
        mask=(stress_arr==level)
        if not mask.any(): 
            continue
        frac=float(mask.sum()/total)
        ys,xs=np.where(mask)
        y0,y1=ys.min(),ys.max()
        x0,x1=xs.min(),xs.max()
        # convert to lat/lon bbox
        def to_lat(y): return lat_max - (y/(h-1 if h>1 else 1))*(lat_max-lat_min)
        def to_lon(x): return lon_min + (x/(w-1 if w>1 else 1))*(lon_max-lon_min)
        zbbox=(to_lat(y1), to_lat(y0), to_lon(x0), to_lon(x1))
        zones.append({"level": name, "bbox": zbbox, "area_fraction": frac})
    return zones
