from __future__ import annotations
from typing import Dict, Any, Tuple
import io, math
import numpy as np
from PIL import Image
from app.modules.soil.tile_render import render_soil_tile

async def _sample_metric(lat: float, lon: float, metric: str, tenant_id:int, z:int=14) -> float|None:
    import mercantile
    t = mercantile.tile(lon, lat, z)
    png = await render_soil_tile(metric, t.z, t.x, t.y, tenant_id)
    im = Image.open(io.BytesIO(png)).convert("RGBA")
    arr = np.array(im)
    # take center pixel and map color back to relative value 0..1, then to metric range
    cy,cx=arr.shape[0]//2, arr.shape[1]//2
    r,g,b,a = arr[cy,cx]
    if a==0:
        return None
    # r increases with value in tile_render
    tnorm = r/255.0
    ranges={'ph':(4.5,9.0),'ec_ds_m':(0.0,8.0),'som_pct':(0.0,5.0)}
    vmin,vmax=ranges.get(metric,(0.0,1.0))
    return float(vmin + tnorm*(vmax-vmin))

async def sample_soil_at(lat: float, lon: float, tenant_id:int) -> Dict[str,Any]:
    ph = await _sample_metric(lat, lon, "ph", tenant_id)
    ec = await _sample_metric(lat, lon, "ec_ds_m", tenant_id)
    som = await _sample_metric(lat, lon, "som_pct", tenant_id)
    return {"ph": ph, "ec_ds_m": ec, "som_pct": som}
