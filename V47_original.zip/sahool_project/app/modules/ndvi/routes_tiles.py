from fastapi import APIRouter, Depends, Response
from app.modules.auth.deps import require_tenant, require_role
from app.modules.ndvi.stress_tiles import render_ndvi_stress_tile

router = APIRouter(prefix="/ndvi/tiles", tags=["ndvi-tiles"], dependencies=[Depends(require_tenant), Depends(require_role("satellite.read"))])

@router.get("/stress/{z}/{x}/{y}.png")
async def stress_tile(z:int,x:int,y:int, fmt: str = 'png'):
    return Response(content=await render_ndvi_stress_tile(z,x,y), media_type="image/png")
