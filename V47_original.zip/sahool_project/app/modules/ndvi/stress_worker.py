from __future__ import annotations
import os, io, math
import numpy as np
from PIL import Image
from redis import Redis
from app.core.config import settings
from .stress_pipeline import ndvi_to_stress

redis = Redis.from_url(settings.redis_url)
TILE_SIZE=256

def _ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

def _tile_bounds(z:int,x:int,y:int):
    n=2.0**z
    lon_min=x/n*360.0-180.0
    lon_max=(x+1)/n*360.0-180.0
    def lat_from_y(yy):
        lat_rad=math.atan(math.sinh(math.pi*(1-2*yy/n)))
        return math.degrees(lat_rad)
    lat_max=lat_from_y(y); lat_min=lat_from_y(y+1)
    return lat_min,lat_max,lon_min,lon_max

def _colorize_stress(stress: np.ndarray) -> Image.Image:
    # stress values 0..3
    img = Image.new("RGBA",(TILE_SIZE,TILE_SIZE))
    px=img.load()
    h,w=stress.shape
    for iy in range(TILE_SIZE):
        for ix in range(TILE_SIZE):
            gy=int(iy/(TILE_SIZE-1)*(h-1)) if h>1 else 0
            gx=int(ix/(TILE_SIZE-1)*(w-1)) if w>1 else 0
            v=int(stress[gy,gx])
            if v==0:
                px[ix,iy]=(0,0,0,0)
            elif v==1:
                px[ix,iy]=(0,200,0,180)
            elif v==2:
                px[ix,iy]=(255,200,0,200)
            else:
                px[ix,iy]=(255,0,0,210)
    return img

async def generate_stress_tiles_for_field(field_bbox, delta_ndvi: np.ndarray, z_min:int=8, z_max:int=14):
    # field_bbox = (lat_min, lat_max, lon_min, lon_max)
    lat_min, lat_max, lon_min, lon_max = field_bbox
    stress = ndvi_to_stress(delta_ndvi)

    for z in range(z_min, z_max+1):
        try:
            import mercantile
            tiles = list(mercantile.tiles(lon_min, lat_min, lon_max, lat_max, z))
        except Exception:
            # fallback: single tile covering center
            tiles = []
        for t in tiles:
            x,y = t.x, t.y
            out_dir=os.path.join(settings.storage_root,"ndvi_stress",str(z),str(x))
            _ensure_dir(out_dir)
            img=_colorize_stress(stress)
            path=os.path.join(out_dir,f"{y}.png")
            img.save(path, "PNG", optimize=True)
            # warm cache
            day=int(__import__("time").time()//86400)
            key=f"ndvi_tile:stress:{z}:{x}:{y}:{day}"
            with open(path,"rb") as f:
                redis.setex(key, 1800, f.read())

async def run_daily_stress_job(db):
    # This job expects existing NDVI delta arrays from satellite pipeline.
    # If missing, it will skip.
    from app.modules.fields.models import Field
    from app.modules.satellite.service_ndvi import load_latest_delta_ndvi  # should exist in project
    fields = db.query(Field).all()
    for f in fields:
        try:
            delta, bbox = await load_latest_delta_ndvi(f.id)
            if delta is None or bbox is None:
                continue
            await generate_stress_tiles_for_field(bbox, delta)
        except Exception:
            continue
