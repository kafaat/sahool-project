from __future__ import annotations
import numpy as np

def ndvi_to_stress(delta: np.ndarray) -> np.ndarray:
    # 0 transparent/no data, 1 low, 2 moderate, 3 high
    out = np.zeros_like(delta, dtype=np.uint8)
    out[delta < -0.10] = 3
    out[(delta >= -0.10) & (delta < -0.03)] = 2
    out[delta >= -0.03] = 1
    return out
