from __future__ import annotations
import io, os, time
from PIL import Image
from redis import Redis
from app.core.config import settings

redis = Redis.from_url(settings.redis_url)
TILE_SIZE=256

def _blank():
    img=Image.new("RGBA",(TILE_SIZE,TILE_SIZE),(0,0,0,0))
    buf=io.BytesIO(); img.save(buf, format="PNG"); return buf.getvalue()

async def render_ndvi_stress_tile(z:int,x:int,y:int)->bytes:
    day=int(time.time()//86400)
    k=f"ndvi_tile:stress:{z}:{x}:{y}:{day}"
    c=redis.get(k)
    if c: return c
    path=os.path.join(settings.storage_root, "ndvi_stress", str(z), str(x), f"{y}.png")
    if not os.path.exists(path):
        out=_blank(); redis.setex(k,1800,out); return out
    out=open(path,"rb").read()
    redis.setex(k,1800,out); return out
