from fastapi import APIRouter, Depends, Response, HTTPException
from sqlalchemy.orm import Session
import numpy as np
import asyncio

from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from app.modules.satellite.services.tiles import render_index_tile_array
from app.modules.satellite.services.heatmap import heatmap_rgba
from app.core.cache import cache_key, get_or_set_bytes
from app.core.image_fmt import png_to_webp

router = APIRouter(
    prefix="/ndvi",
    tags=["NDVI-Heatmap"],
    dependencies=[Depends(require_tenant), Depends(require_role("ndvi.read"))],
)

@router.get("/heatmap/tiles/{result_id}/{z}/{x}/{y}.png", summary="NDVI stress heatmap tile", description="Return XYZ tile colored as stress heatmap from raw NDVI values.")
async def heatmap_tile(result_id: int, z:int, x:int, y:int, fmt: str='png', db: Session=Depends(get_db), tenant=Depends(require_tenant)):
    tenant_id = tenant["tenant_id"]
    key = cache_key("heatmap", result_id, z, x, y, tenant_id)
    disk_dir = "/mnt/data/tile_cache/heatmap"
    def producer():
        arr = asyncio.get_event_loop().run_until_complete(
            render_index_tile_array("ndvi", result_id, z, x, y, tenant_id)
        )
        rgba = heatmap_rgba(arr, vmin=-1, vmax=1)
        # to png bytes using existing helper
        from app.modules.satellite.services.tiles import rgba_to_png_bytes
        return rgba_to_png_bytes(rgba)
    png = get_or_set_bytes(key, disk_dir, "png", producer)
    if fmt.lower()=="webp":
        return Response(content=png_to_webp(png), media_type="image/webp")
    return Response(content=png, media_type="image/png")
