from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.modules.auth.deps import require_tenant, require_role
from .timeseries import build_timeseries, monthly_climatology, anomaly_series, seasonal_curve, timelapse_manifest

router = APIRouter(
    prefix="/ndvi",
    tags=["NDVI-TimeSeries"],
    dependencies=[Depends(require_tenant), Depends(require_role("ndvi.read"))],
)

@router.get("/timeseries")
def ndvi_timeseries(field_id: int, days: int=365, db: Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], days=days)
    baseline=monthly_climatology(ts["points"])
    return {**ts, "baseline": baseline}

@router.get("/anomaly")
def ndvi_anomaly(field_id: int, days: int=365, db: Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], days=days)
    baseline=monthly_climatology(ts["points"])
    return {"field_id": field_id, "points": anomaly_series(ts["points"], baseline), "baseline": baseline}

@router.get("/seasonal-curve")
def ndvi_seasonal_curve(field_id: int, days: int=365, db: Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], days=days)
    return {"field_id": field_id, "curve": seasonal_curve(ts["points"])}

@router.get("/timelapse")
def ndvi_timelapse(field_id: int, days: int=365, db: Session=Depends(get_db), tenant=Depends(require_tenant)):
    ts=build_timeseries(db, field_id, tenant["tenant_id"], days=days)
    return {"field_id": field_id, "frames": timelapse_manifest(ts["points"])}
