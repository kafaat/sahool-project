from __future__ import annotations
import aiosmtplib
from email.message import EmailMessage
from app.core.config import settings

async def send_email(to: str, subject: str, body: str):
    if not settings.smtp_host or not settings.smtp_from:
        # email disabled
        return
    msg = EmailMessage()
    msg["From"] = settings.smtp_from
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)

    await aiosmtplib.send(
        msg,
        hostname=settings.smtp_host,
        port=settings.smtp_port,
        username=settings.smtp_user,
        password=settings.smtp_pass,
        start_tls=True,
    )
