from __future__ import annotations
def tenant_prefix(tenant_id: int | None) -> str:
    return f"tenants/{tenant_id}" if tenant_id is not None else "tenants/default"
