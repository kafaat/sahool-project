from __future__ import annotations
import boto3
from botocore.client import Config
from typing import Optional
from app.core.config import settings

def _client():
    if not settings.s3_access_key or not settings.s3_secret_key or not settings.s3_bucket:
        raise ValueError("S3 settings missing")
    return boto3.client(
        "s3",
        aws_access_key_id=settings.s3_access_key,
        aws_secret_access_key=settings.s3_secret_key,
        region_name=settings.s3_region or "us-east-1",
        endpoint_url=settings.s3_endpoint_url,
        config=Config(signature_version="s3v4"),
    )

def upload_file(local_path: str, key: str, content_type: Optional[str]=None) -> str:
    c=_client()
    extra={}
    if content_type:
        extra["ContentType"]=content_type
    c.upload_file(local_path, settings.s3_bucket, key, ExtraArgs=extra)
    return key

def presign_get(key: str, expires: int=604800) -> str:
    c=_client()
    return c.generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.s3_bucket, "Key": key},
        ExpiresIn=expires,
    )

def public_url(key: str) -> str:
    if settings.s3_public_base:
        return f"{settings.s3_public_base.rstrip('/')}/{key}"
    return presign_get(key)
