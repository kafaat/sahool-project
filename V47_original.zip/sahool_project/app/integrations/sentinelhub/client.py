from __future__ import annotations
import requests, datetime, time
from typing import Dict, Any, Optional
from app.core.config import settings
from app.integrations.sentinelhub.quota import breaker, quota_allow

TOKEN_URL = "https://services.sentinel-hub.com/oauth/token"
PROCESS_URL = "https://services.sentinel-hub.com/api/v1/process"

class SentinelHubClient:
    def __init__(self, client_id: str, client_secret: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self._token: Optional[str] = None
        self._token_exp: Optional[datetime.datetime] = None

    def _get_token(self) -> str:
        now = datetime.datetime.utcnow()
        if self._token and self._token_exp and now < self._token_exp:
            return self._token
        resp = requests.post(
            TOKEN_URL,
            data={"grant_type":"client_credentials"},
            auth=(self.client_id, self.client_secret),
            timeout=30
        )
        resp.raise_for_status()
        data = resp.json()
        self._token = data["access_token"]
        self._token_exp = now + datetime.timedelta(seconds=int(data.get("expires_in", 3600)) - 60)
        return self._token

    def process(self, payload: Dict[str, Any]) -> bytes:
        tenant = payload.get('input', {}).get('data', [{}])[0].get('tenant') or 'public'
        if not breaker.allow(tenant):
            raise RuntimeError('SentinelHub circuit open')
        if not quota_allow(tenant, daily_limit=int(getattr(settings,'sentinel_daily_limit',200))):
            raise RuntimeError('SentinelHub quota exceeded')
        token = self._get_token()
        headers = {"Authorization": f"Bearer {token}", "Content-Type":"application/json"}
        last_err=None
        for attempt in range(4):
            try:
                r = requests.post(PROCESS_URL, headers=headers, json=payload, timeout=300)
                r.raise_for_status()
                breaker.record_success(tenant)
                return r.content
            except Exception as e:
                last_err=e
                breaker.record_failure(tenant)
                time.sleep(2**attempt)
        raise last_err

def get_client() -> SentinelHubClient:
    if not settings.sentinelhub_client_id or not settings.sentinelhub_client_secret:
        raise ValueError("SentinelHub credentials missing")
    return SentinelHubClient(settings.sentinelhub_client_id, settings.sentinelhub_client_secret)
