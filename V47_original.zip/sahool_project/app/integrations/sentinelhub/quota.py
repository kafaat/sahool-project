from __future__ import annotations
import time
from redis import Redis
from app.core.config import settings

redis = Redis.from_url(settings.redis_url)

class CircuitBreaker:
    def __init__(self, fail_threshold: int = 5, reset_sec: int = 300):
        self.fail_threshold = fail_threshold
        self.reset_sec = reset_sec

    def allow(self, key: str) -> bool:
        return redis.get(f"cb:{key}:open") is None

    def record_success(self, key: str):
        redis.delete(f"cb:{key}:fails")

    def record_failure(self, key: str):
        fails = redis.incr(f"cb:{key}:fails")
        if fails >= self.fail_threshold:
            redis.setex(f"cb:{key}:open", self.reset_sec, "1")

breaker = CircuitBreaker()

def quota_allow(tenant_id: str, daily_limit: int = 200) -> bool:
    day = int(time.time()//86400)
    k = f"quota:{tenant_id}:{day}"
    n = redis.incr(k)
    if n == 1:
        redis.expire(k, 86400+60)
    return n <= daily_limit
