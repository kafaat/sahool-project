from __future__ import annotations
import requests, datetime
from typing import Dict, Any, List, Optional
from app.integrations.sentinelhub.client import SentinelHubClient
from app.core.config import settings

CATALOG_URL = "https://services.sentinel-hub.com/api/v1/catalog/search"

def search_best_acquisition(client: SentinelHubClient, geometry_geojson: Dict[str, Any],
                            date_from: str, date_to: str, max_cloud: float = 60.0) -> Optional[Dict[str, Any]]:
    token = client._get_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type":"application/json"}
    payload = {
        "bbox": None,
        "geometry": geometry_geojson,
        "timeRange": {"from": date_from, "to": date_to},
        "collections": ["sentinel-2-l2a"],
        "limit": 10,
        "query": {
            "eo:cloud_cover": {"lt": max_cloud}
        },
        "sortby": [{"field":"eo:cloud_cover","direction":"ASC"}]
    }
    r = requests.post(CATALOG_URL, headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    data = r.json()
    feats = data.get("features") or []
    return feats[0] if feats else None
