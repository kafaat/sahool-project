from sqlalchemy import Column, BigInteger, ForeignKey

class TenantMixin:
    tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=False, index=True)
