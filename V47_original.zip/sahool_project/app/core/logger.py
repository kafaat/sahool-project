import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sahool")

def get_logger(name: str = "sahool"):
    return logging.getLogger(name)
