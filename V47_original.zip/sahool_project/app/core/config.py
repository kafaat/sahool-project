import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    jwt_secret: str | None = None
    rate_limit_rpm: int = 120
    sentinel_daily_limit: int = 200

    sentinelhub_client_id: str | None = None
    sentinelhub_client_secret: str | None = None
    s3_endpoint_url: str | None = None
    s3_access_key: str | None = None
    s3_secret_key: str | None = None
    s3_bucket: str | None = None
    s3_region: str | None = None
    s3_public_base: str | None = None

    # Email (optional)
    smtp_host: str = os.getenv('SMTP_HOST', '')
    smtp_port: int = int(os.getenv('SMTP_PORT', '587'))
    smtp_user: str = os.getenv('SMTP_USER', '')
    smtp_pass: str = os.getenv('SMTP_PASS', '')
    smtp_from: str = os.getenv('SMTP_FROM', smtp_user)
    report_recipients: str = os.getenv('REPORT_RECIPIENTS', '')  # comma-separated

    database_url: str = os.getenv("DATABASE_URL")
    redis_url: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
    cdse_user: str = os.getenv("CDSE_USER", "")
    cdse_pass: str = os.getenv("CDSE_PASS", "")
    storage_root: str = os.getenv("STORAGE_ROOT", "storage")

    # Auth-related settings (kept for future, even if open mode now)
    secret_key: str = os.getenv("SECRET_KEY", "change-me-please")
    algorithm: str = os.getenv("ALGORITHM", "HS256")
    access_token_expire_minutes: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))

settings = Settings()
