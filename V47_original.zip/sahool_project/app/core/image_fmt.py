from __future__ import annotations
from typing import Literal
from io import BytesIO
from PIL import Image

def png_to_webp(png_bytes: bytes, quality:int=80)->bytes:
    im=Image.open(BytesIO(png_bytes)).convert("RGBA")
    out=BytesIO()
    im.save(out, format="WEBP", quality=quality, method=6)
    return out.getvalue()
