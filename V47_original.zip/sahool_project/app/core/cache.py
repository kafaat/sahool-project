from __future__ import annotations
from typing import Optional, Callable, Any, Dict, Tuple
import os, time, hashlib, threading

# simple LRU-ish in-memory cache with TTL
class MemoryCache:
    def __init__(self, max_items:int=512, ttl_s:int=3600):
        self.max_items=max_items
        self.ttl_s=ttl_s
        self._lock=threading.Lock()
        self._store: Dict[str, Tuple[float, bytes]] = {}

    def get(self, key:str)->Optional[bytes]:
        with self._lock:
            v=self._store.get(key)
            if not v: return None
            ts,data=v
            if time.time()-ts > self.ttl_s:
                self._store.pop(key,None)
                return None
            return data

    def set(self, key:str, data:bytes):
        with self._lock:
            if len(self._store) >= self.max_items:
                # drop oldest
                oldest=min(self._store.items(), key=lambda kv: kv[1][0])[0]
                self._store.pop(oldest,None)
            self._store[key]=(time.time(), data)

mem_cache = MemoryCache()

def cache_key(*parts: Any)->str:
    raw="|".join(map(str,parts))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()

def disk_cache_path(root_dir:str, key:str, ext:str)->str:
    os.makedirs(root_dir, exist_ok=True)
    return os.path.join(root_dir, f"{key}.{ext}")

def get_or_set_bytes(key:str, disk_dir:str, ext:str, producer: Callable[[], bytes])->bytes:
    # memory first
    data=mem_cache.get(key)
    if data is not None:
        return data
    # disk next
    path=disk_cache_path(disk_dir, key, ext)
    if os.path.exists(path):
        with open(path,"rb") as f:
            data=f.read()
        mem_cache.set(key,data)
        return data
    # produce
    data=producer()
    with open(path,"wb") as f:
        f.write(data)
    mem_cache.set(key,data)
    return data
