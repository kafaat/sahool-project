from __future__ import annotations
import time
from redis import Redis
from app.core.config import settings

class RateLimiter:
    def __init__(self, redis: Redis, max_requests: int = 120, window_sec: int = 60):
        self.redis = redis
        self.max_requests = max_requests
        self.window_sec = window_sec

    def allow(self, key: str) -> bool:
        now = int(time.time())
        window = now // self.window_sec
        rkey = f"rl:{key}:{window}"
        count = self.redis.incr(rkey)
        if count == 1:
            self.redis.expire(rkey, self.window_sec + 1)
        return count <= self.max_requests

def get_redis() -> Redis:
    return Redis.from_url(settings.redis_url)

limiter = RateLimiter(get_redis(), max_requests=int(getattr(settings, "rate_limit_rpm", 120)), window_sec=60)
