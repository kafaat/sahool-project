import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from typing import Iterable, Optional
from app.core.config import settings

def send_email(subject: str, html_body: str, to_emails: Iterable[str], attachments: Optional[list[tuple[str, bytes]]] = None):
    """Send email via SMTP if configured. Attachments are (filename, bytes)."""
    if not settings.smtp_host or not settings.smtp_user:
        return False

    msg = MIMEMultipart()
    msg["From"] = settings.smtp_from or settings.smtp_user
    msg["To"] = ", ".join(to_emails)
    msg["Subject"] = subject
    msg.attach(MIMEText(html_body, "html"))

    attachments = attachments or []
    for name, data in attachments:
        part = MIMEApplication(data, Name=name)
        part["Content-Disposition"] = f'attachment; filename="{name}"'
        msg.attach(part)

    with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as s:
        s.starttls()
        s.login(settings.smtp_user, settings.smtp_pass)
        s.send_message(msg)
    return True
