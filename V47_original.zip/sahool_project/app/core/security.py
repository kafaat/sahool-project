from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, Any

from fastapi import Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordBearer
from jose import jwt, JWTError
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.db import get_db
from app.modules.users.models import User, Membership

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)

def create_access_token(data: Dict[str, Any], expires_minutes: Optional[int] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=expires_minutes or settings.access_token_expire_minutes
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)

def decode_token(token: str) -> Dict[str, Any]:
    try:
        return jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    payload = decode_token(token)
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(401, "Invalid token payload")
    user = db.get(User, int(user_id))
    if not user:
        raise HTTPException(401, "User not found")
    return user

def get_tenant_id(
    request: Request,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> int:
    # tenant_id can be in token, or via header X-Tenant-Id if user has membership
    tenant_id = getattr(request.state, "tenant_id", None)
    if tenant_id:
        return int(tenant_id)

    header_tid = request.headers.get("x-tenant-id")
    if header_tid:
        mem = db.query(Membership).filter(
            Membership.user_id == user.id,
            Membership.tenant_id == int(header_tid)
        ).first()
        if not mem:
            raise HTTPException(403, "No access to this tenant")
        return int(header_tid)

    # fall back: use user's first membership
    mem = db.query(Membership).filter(Membership.user_id == user.id).first()
    if not mem:
        raise HTTPException(403, "User has no tenant")
    return int(mem.tenant_id)


# --- Open multi-tenant mode (no auth) ---
from fastapi import Request

def get_tenant_id_open(request: Request) -> int:
    """Resolve tenant_id without any authentication.
    Priority:
    1) X-Tenant-Id header
    2) tenant_id query param
    3) default tenant_id=1 (dev only)
    """
    header_tid = request.headers.get("x-tenant-id")
    if header_tid is not None:
        try:
            return int(header_tid)
        except Exception:
            raise HTTPException(400, "Invalid tenant id")

    qp_tid = request.query_params.get("tenant_id")
    if qp_tid is not None:
        try:
            return int(qp_tid)
        except Exception:
            raise HTTPException(400, "Invalid tenant id")

    return 1
