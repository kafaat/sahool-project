from __future__ import annotations

import uuid
from pathlib import Path
from dataclasses import dataclass

from app.core.config import settings


@dataclass(frozen=True)
class FileManager:
    """Central place to create/validate storage paths."""

    root: Path = Path(settings.storage_root)

    def ensure_root(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)

    def _mk(self, *parts: str, suffix: str) -> Path:
        self.ensure_root()
        folder = self.root.joinpath(*parts)
        folder.mkdir(parents=True, exist_ok=True)
        name = f"{uuid.uuid4().hex}{suffix}"
        return folder / name

    def sentinel_zip(self, product_id: str) -> Path:
        folder = self.root / "sentinel" / product_id
        folder.mkdir(parents=True, exist_ok=True)
        return folder / f"{product_id}.zip"

    def ndvi_tif(self, field_id: int, image_id: int) -> Path:
        return self._mk("ndvi", str(field_id), str(image_id), suffix=".tif")

    def ndvi_png(self, field_id: int, image_id: int) -> Path:
        return self._mk("ndvi", str(field_id), str(image_id), suffix=".png")

    def delta_tif(field_id: int, old_result_id: int, new_result_id: int, index_name: str="ndvi"):
        d = os.path.join(settings.storage_root, "deltas", index_name, f"field_{field_id}")
        FileManager.ensure_dir(d)
        return os.path.join(d, f"delta_{old_result_id}_{new_result_id}.tif")

    @staticmethod
    def tile_path(result_id: int, z: int, x: int, y: int):
        d = os.path.join(FileManager.tiles_dir(result_id), str(z), str(x))
        FileManager.ensure_dir(d)
        return os.path.join(d, f"{y}.png")


    @staticmethod
    def tiles_dir_index(index_name: str, result_id: int):
        p = os.path.join(settings.storage_root, "tiles", index_name.lower(), str(result_id))
        FileManager.ensure_dir(p)
        return p

    @staticmethod
    def tile_path_index(index_name: str, result_id: int, z: int, x: int, y: int):
        d = os.path.join(FileManager.tiles_dir_index(index_name, result_id), str(z), str(x))
        FileManager.ensure_dir(d)
        return os.path.join(d, f"{y}.png")
