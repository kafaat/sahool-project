from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

REQUEST_COUNT = Counter("request_count", "Total HTTP requests", ["method", "endpoint", "status"])
REQUEST_LATENCY = Histogram("request_latency_seconds", "Request latency", ["endpoint"])

def metrics_response():
    return generate_latest(), CONTENT_TYPE_LATEST
