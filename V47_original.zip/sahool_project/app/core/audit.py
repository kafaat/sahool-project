from __future__ import annotations
import datetime
from sqlalchemy.orm import Session
from app.core.db import SessionLocal

def audit(event: str, tenant_id: int | None, user_id: str | None, meta: dict):
    db: Session = SessionLocal()
    try:
        from app.modules.system.models import AuditLog
        log = AuditLog(
            event=event,
            tenant_id=tenant_id,
            user_id=user_id,
            meta=meta,
            created_at=datetime.datetime.utcnow(),
        )
        db.add(log); db.commit()
    except Exception:
        pass
    finally:
        db.close()
