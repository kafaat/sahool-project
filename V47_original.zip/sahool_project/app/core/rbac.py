from __future__ import annotations
from fastapi import Depends, HTTPException, Request
from typing import Optional

def get_tenant_id(request: Request) -> Optional[int]:
    t = request.headers.get("x-tenant-id")
    return int(t) if t else None

def require_tenant(tenant_id: Optional[int] = Depends(get_tenant_id)) -> int:
    if tenant_id is None:
        raise HTTPException(401, "Tenant header required")
    return tenant_id

def require_role(role: str):
    def dep(request: Request):
        roles = [r.strip() for r in request.headers.get("x-roles","").split(",") if r.strip()]
        if role not in roles:
            raise HTTPException(403, "Forbidden")
        return True
    return dep
