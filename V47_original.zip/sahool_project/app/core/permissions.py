from __future__ import annotations
from typing import Dict, Set

ROLE_PERMS: Dict[str, Set[str]] = {
    "superadmin": {"*"},
    "admin": {
        "admin.tenants.read","admin.tenants.write",
        "admin.users.read","admin.users.write",
        "admin.apikeys.read","admin.apikeys.write",
        "admin.audit.read","admin.usage.read",
        "fields.read","fields.write",
        "satellite.read","satellite.write",
        "analytics.read","weather.read","weather.write","soil.read","soil.write"
    },
    "user": {"fields.read","satellite.read","analytics.read","weather.read","weather.write","soil.read","soil.write"},
    "device": {"satellite.read"}
}

def has_perm(roles_csv: str, perm: str) -> bool:
    roles = [r.strip() for r in roles_csv.split(",") if r.strip()]
    for r in roles:
        ps = ROLE_PERMS.get(r, set())
        if "*" in ps or perm in ps:
            return True
    return False
