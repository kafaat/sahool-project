"""Prerender tiles for faster first load.

Usage:
python -m app.scripts.prerender_tiles --field_id 3 --index ndvi --z 10 11 12
"""
from __future__ import annotations
import argparse, asyncio
from sqlalchemy.orm import Session

from app.core.db import SessionLocal
from app.core.cache import cache_key, get_or_set_bytes
from app.modules.satellite.services.tiles import render_index_tile
from app.modules.ndvi.tiles import render_ndvi_tile

async def _render_sat(index_name, result_id, z, x, y, tenant_id):
    key=cache_key('sat', index_name, result_id, z, x, y, tenant_id)
    disk_dir=f"/mnt/data/tile_cache/satellite/{index_name}"
    get_or_set_bytes(key, disk_dir, 'png', lambda: asyncio.get_event_loop().run_until_complete(
        render_index_tile(index_name, result_id, z, x, y, tenant_id)
    ))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--result_id", type=int, required=True)
    ap.add_argument("--index", default="ndvi")
    ap.add_argument("--tenant_id", type=int, default=1)
    ap.add_argument("--z", nargs="+", type=int, default=[12])
    ap.add_argument("--x_range", nargs=2, type=int, default=[0, 4096])
    ap.add_argument("--y_range", nargs=2, type=int, default=[0, 4096])
    args=ap.parse_args()

    async def runner():
        for z in args.z:
            for x in range(args.x_range[0], args.x_range[1]+1):
                for y in range(args.y_range[0], args.y_range[1]+1):
                    await _render_sat(args.index, args.result_id, z, x, y, args.tenant_id)
    asyncio.run(runner())

if __name__ == "__main__":
    main()
