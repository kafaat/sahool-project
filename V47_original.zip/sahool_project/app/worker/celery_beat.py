CELERYBEAT_SCHEDULE = {
    'ndvi_stress_daily': {'task': 'app.worker.tasks.ndvi_stress_daily', 'schedule': 86400.0},
    'weekly_irrigation': {'task': 'app.worker.tasks.weekly_irrigation', 'schedule': 604800.0},
}
