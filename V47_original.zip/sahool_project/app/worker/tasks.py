from app.worker.celery_app import celery


@celery.task(name="app.worker.tasks.ndvi_stress_daily")
def ndvi_stress_daily():
    from app.core.db import SessionLocal
    from app.modules.ndvi.stress_worker import run_daily_stress_job
    db=SessionLocal()
    import asyncio
    asyncio.run(run_daily_stress_job(db))
    db.close()
    return True

@celery.task(name="app.worker.tasks.weekly_irrigation")
def weekly_irrigation():
    from app.core.db import SessionLocal
    from app.modules.weather.scheduler import run_weekly_irrigation
    db=SessionLocal()
    import asyncio
    asyncio.run(run_weekly_irrigation(db))
    db.close()
    return True
