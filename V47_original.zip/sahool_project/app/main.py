from app.modules.auth.mfa_routes import router as mfa_router
from app.modules.auth.email_mfa_routes import router as email_mfa_router
from app.modules.auth.bootstrap import ensure_bootstrap
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import time
import logging

from app.core.file_manager import FileManager

from app.modules.fields.routes import router as fields_router
from app.modules.satellite.routes_images import router as images_router
from app.modules.satellite.routes_ndvi import router as ndvi_router
from app.modules.satellite.routes_ndvi_tiles import router as tiles_router
from app.modules.satellite.routes_legend import router as legend_router
from app.modules.satellite.routes_change import router as change_router
from app.modules.satellite.routes_timeline import router as timeline_router
from app.modules.reports.routes import router as reports_router
from app.modules.alerts.routes import router as alerts_router
from app.modules.system.routes_usage_history import router as usage_history_router
from app.modules.weather.routes_tiles import router as weather_tiles_router
from app.modules.soil.routes import router as soil_router
from app.modules.soil.routes_tiles import router as soil_tiles_router
from app.modules.soil.routes_suitability import router as soil_suitability_router
from app.modules.ndvi.routes_tiles import router as ndvi_tiles_router
from app.modules.ndvi.routes_heatmap import router as ndvi_heatmap_router
from app.modules.ndvi.routes_timeseries import router as ndvi_ts_router
from app.modules.agro_intel.routes import router as agro_router
from app.modules.disease.routes import router as disease_router
from app.modules.weather.routes import router as weather_router
from app.modules.analytics.routes import router as analytics_router
from app.modules.compare.routes import router as compare_router
from app.modules.training.routes import router as training_router
from app.modules.fields.routes import router as fields_router
from app.modules.system.routes import router as system_router
from app.modules.system.dashboard_data import router as dashboard_data_router


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sahool")

tags_metadata = [
    {'name':'Auth','description':'Authentication, tenants, users, MFA, API keys.'},
    {'name':'Fields','description':'Field CRUD and geometry.'},
    {'name':'Satellite','description':'Sentinel images, indices processing, tiles and legends.'},
    {'name':'NDVI-TimeSeries','description':'NDVI timeseries, anomaly, seasonal curves, timelapse.'},
    {'name':'Timeline','description':'Generic multi-index timeline for NDVI/NDRE/GNDVI/EVI/etc.'},
    {'name':'NDVI-Heatmap','description':'Stress heatmap tiles.'},
    {'name':'Soil','description':'Soil suitability, analysis, and depth tiles.'},
    {'name':'Weather','description':'Live/history forecasts, irrigation and agro summary.'},
    {'name':'Disease-Risk','description':'Rule-based disease risk engine.'},
    {'name':'Reports','description':'Advanced multi-page PDF reports.'},
    {'name':'Video','description':'GIF/MP4 timelapse export.'},
    {'name':'System','description':'Health, queue, usage and admin stats.'},
]

app = FastAPI(
    title='Sahool Farmonaut Agro Platform API',
    description='Backend API for satellite, soil, weather, agro-AI, risk engines, and exports.',
    version='47.0.0',
    openapi_tags=tags_metadata,
)

# CORS for React dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Storage
fm = FileManager()
fm.ensure_root()
app.mount("/storage", StaticFiles(directory=str(fm.root)), name="storage")

@app.middleware("http")
async def log_requests(request, call_next):
    start = time.time()
    resp = await call_next(request)
    ms = int((time.time() - start) * 1000)
    logger.info("request", extra={
        "method": request.method,
        "path": request.url.path,
        "status": resp.status_code,
        "ms": ms,
    })
    return resp

# Routers
app.include_router(system_router)
app.include_router(dashboard_data_router)

app.include_router(fields_router, prefix="/fields", tags=["Fields"])
app.include_router(images_router, prefix="/satellite/images", tags=["Satellite Images"])
app.include_router(ndvi_router, prefix="/satellite/ndvi", tags=["NDVI"])
app.include_router(tiles_router, prefix="/satellite/ndvi", tags=["NDVI Tiles"])
app.include_router(legend_router, prefix=settings.api_prefix)
app.include_router(change_router, prefix="/satellite/change", tags=["Change Detection"])
app.include_router(timeline_router, prefix="/satellite/ndvi", tags=["NDVI Timeline"])
app.include_router(alerts_router, prefix="/alerts", tags=["Alerts"])
app.include_router(weather_router, tags=["Weather"])
app.include_router(weather_tiles_router)
app.include_router(soil_router, tags=["Soil"])
app.include_router(soil_tiles_router)
app.include_router(soil_suitability_router)
app.include_router(ndvi_tiles_router)
app.include_router(ndvi_heatmap_router)
from app.modules.video.routes import router as video_router
app.include_router(video_router)
app.include_router(usage_history_router)
app.include_router(agro_router)
app.include_router(disease_router)
app.include_router(reports_router, prefix="/reports", tags=["Reports"])
app.include_router(weather_router, prefix="/weather", tags=["Weather"])

app.include_router(fields_router)
app.include_router(analytics_router)
app.include_router(training_router)
from fastapi import Request
from app.core.metrics import REQUEST_COUNT, REQUEST_LATENCY, metrics_response
from starlette.responses import Response as StarletteResponse

@app.middleware("http")
async def prom_mw(request: Request, call_next):
    endpoint = request.url.path
    method = request.method
    with REQUEST_LATENCY.labels(endpoint=endpoint).time():
        resp = await call_next(request)
    REQUEST_COUNT.labels(method=method, endpoint=endpoint, status=resp.status_code).inc()
    return resp

@app.get("/metrics")
def metrics():
    data, ctype = metrics_response()
    return StarletteResponse(content=data, media_type=ctype)


from fastapi import Request, HTTPException
from app.core.rate_limit import limiter

@app.middleware("http")
async def rate_limit_mw(request: Request, call_next):
    tenant = request.headers.get("x-tenant-id") or "public"
    ip = request.client.host if request.client else "unknown"
    key = f"{tenant}:{ip}"
    if not limiter.allow(key):
        raise HTTPException(429, "Rate limit exceeded")
    return await call_next(request)


@app.on_event("startup")
def _bootstrap():
    db = SessionLocal()
    try:
        ensure_bootstrap(db)
    finally:
        db.close()

from app.modules.auth.admin_routes import router as admin_router

app.include_router(admin_router, prefix=settings.api_prefix)

app.include_router(mfa_router, prefix=settings.api_prefix)
app.include_router(email_mfa_router, prefix=settings.api_prefix)
