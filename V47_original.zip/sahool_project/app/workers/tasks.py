from app.integrations.storage.s3 import upload_file, public_url
from app.modules.satellite.services.cog import to_cog
from app.integrations.storage.prefix import tenant_prefix
from typing import Optional
import datetime as dt
import zipfile
from pathlib import Path
from celery import shared_task
from sqlalchemy.orm import Session

from geoalchemy2.shape import to_shape

from app.core.db import SessionLocal
from app.core.logger import logger
from app.modules.fields.models import Field
from app.modules.weather.models import WeatherRecord
from app.modules.satellite.models import SatelliteImage, NDVIResult
from app.modules.satellite.fused_models import SatelliteIndexRecord, FieldDailyState
from app.modules.satellite.services.sentinel_api import SentinelAPIService
from app.modules.satellite.services.indices_large import compute_indices
from app.modules.crops.models import CropCalendar, SoilProfile
from app.modules.crops.soil_water import SoilWaterBalance
from app.modules.crops.irrigation import IrrigationEvent
from app.modules.analytics.et0 import et0_hargreaves
from app.modules.analytics.yield_model import estimate_yield_kg_per_ha
from app.modules.analytics.anomaly_ml import build_features, classify_anomaly
from app.modules.alerts.service import create_alert
from app.modules.training.loader import load_anomaly_model, load_yield_model


def _clamp(x, lo=0.0, hi=1.0):
    if x is None:
        return None
    try:
        x=float(x)
    except Exception:
        return None
    return max(lo, min(hi, x))


def calc_vigor_score(db: Session, field: Field, date: dt.date, ndvi_today: Optional[float]):
    if ndvi_today is None:
        return None
    hist = (db.query(SatelliteIndexRecord.ndvi_mean)
              .filter(SatelliteIndexRecord.field_id==field.id,
                      SatelliteIndexRecord.tenant_id==field.tenant_id,
                      SatelliteIndexRecord.date>=date-dt.timedelta(days=365))
              .order_by(SatelliteIndexRecord.date.desc())
              .limit(120).all())
    vals=[h[0] for h in hist if h and h[0] is not None]
    if len(vals)<5:
        return None
    mn=min(vals); mx=max(vals)
    if mx-mn<1e-6:
        return None
    return _clamp((ndvi_today-mn)/(mx-mn))


def calc_water_stress(ndwi, rain, tmax):
    ndwi = ndwi if ndwi is not None else 0.0
    rain = rain if rain is not None else 0.0
    tmax = tmax if tmax is not None else 0.0
    dryness=_clamp(1-(ndwi+1)/2)
    no_rain=_clamp(1-min(rain,5.0)/5.0)
    heat=_clamp((tmax-25.0)/15.0)
    if dryness is None or no_rain is None or heat is None:
        return None
    return _clamp(0.5*dryness+0.3*no_rain+0.2*heat)


def calc_heat_stress(tmax):
    tmax=tmax if tmax is not None else 0.0
    return _clamp((tmax-32.0)/10.0)


def calc_rule_anomaly(db: Session, field: Field, date: dt.date, ndvi_today):
    if ndvi_today is None:
        return None, None
    last = (db.query(SatelliteIndexRecord.ndvi_mean)
              .filter(SatelliteIndexRecord.field_id==field.id,
                      SatelliteIndexRecord.tenant_id==field.tenant_id,
                      SatelliteIndexRecord.date<=date)
              .order_by(SatelliteIndexRecord.date.desc())
              .limit(4).all())
    vals=[x[0] for x in last if x and x[0] is not None]
    if len(vals)<4:
        return None, None
    baseline=sum(vals[1:])/3
    if baseline<=1e-6:
        return None, baseline
    drop=(baseline-ndvi_today)/baseline
    return _clamp(drop), baseline


def get_crop_stage(db: Session, field: Field, date: dt.date):
    cal=(db.query(CropCalendar)
           .filter(CropCalendar.field_id==field.id,
                   CropCalendar.tenant_id==field.tenant_id,
                   CropCalendar.season_start<=date)
           .order_by(CropCalendar.season_start.desc())
           .first())
    if not cal or not cal.planting_date:
        return None

    base_t=cal.base_temp_c or 10.0
    w_hist=(db.query(WeatherRecord.date, WeatherRecord.temp_max_c, WeatherRecord.temp_min_c)
              .filter(WeatherRecord.field_id==field.id,
                      WeatherRecord.tenant_id==field.tenant_id,
                      WeatherRecord.date>=cal.planting_date,
                      WeatherRecord.date<=date)
              .order_by(WeatherRecord.date.asc()).all())
    gdd=0.0
    for _,tmax,tmin in w_hist:
        if tmax is None and tmin is None:
            continue
        if tmax is None: tmax=tmin
        if tmin is None: tmin=tmax
        gdd += max(0.0, ((tmax+tmin)/2.0)-base_t)

    if gdd < (cal.gdd_stage_1 or 250.0): return "emergence"
    if gdd < (cal.gdd_stage_2 or 600.0): return "vegetative"
    if gdd < (cal.gdd_stage_3 or 900.0): return "flowering"
    if gdd < (cal.gdd_stage_4 or 1200.0): return "filling"
    return "maturity"


def update_soil_water_balance(db: Session, field: Field, day: dt.date, w: WeatherRecord, stage: Optional[str]):
    soil=(db.query(SoilProfile)
            .filter(SoilProfile.field_id==field.id,
                    SoilProfile.tenant_id==field.tenant_id).first())
    awc=soil.awc_mm if soil and soil.awc_mm else 120.0

    prev=(db.query(SoilWaterBalance)
            .filter(SoilWaterBalance.field_id==field.id,
                    SoilWaterBalance.tenant_id==field.tenant_id,
                    SoilWaterBalance.date==day-dt.timedelta(days=1)).first())
    storage=prev.soil_moisture_mm if prev and prev.soil_moisture_mm is not None else awc/2

    try:
        lat_deg=to_shape(field.boundary).centroid.y
    except Exception:
        lat_deg=0.0

    et0=et0_hargreaves(lat_deg, day, w.temp_max_c, w.temp_min_c)

    kc={"emergence":0.6,"vegetative":1.05,"flowering":1.2,"filling":1.1,"maturity":0.7}.get(stage or "vegetative",1.0)
    crop_et=et0*kc
    rain=w.precip_sum_mm or 0.0
    irrigation=sum(e.amount_mm for e in db.query(IrrigationEvent).filter(
        IrrigationEvent.field_id==field.id,
        IrrigationEvent.tenant_id==field.tenant_id,
        IrrigationEvent.date==day).all()) or 0.0

    storage=_clamp(storage+rain+irrigation-crop_et,0.0,awc)
    frac=storage/awc if awc>1e-6 else None

    rec=(db.query(SoilWaterBalance)
           .filter(SoilWaterBalance.field_id==field.id,
                   SoilWaterBalance.tenant_id==field.tenant_id,
                   SoilWaterBalance.date==day).first())
    if rec is None:
        rec=SoilWaterBalance(field_id=field.id, tenant_id=field.tenant_id, date=day)
        db.add(rec)

    rec.et0_mm=et0; rec.kc=kc; rec.crop_et_mm=crop_et
    rec.rain_mm=rain; rec.irrigation_mm=irrigation
    rec.soil_moisture_mm=storage; rec.soil_moisture_frac=frac
    rec.raw={"awc_mm":awc}
    return rec


def estimate_irrigation_liters_per_ha(db: Session, field: Field, stage: str, tmax, tmin, rain):
    soil=(db.query(SoilProfile)
            .filter(SoilProfile.field_id==field.id,
                    SoilProfile.tenant_id==field.tenant_id).first())
    awc=soil.awc_mm if soil and soil.awc_mm else 120.0
    kc={"emergence":0.6,"vegetative":1.05,"flowering":1.2,"filling":1.1,"maturity":0.7}.get(stage or "vegetative",1.0)
    try:
        lat_deg=to_shape(field.boundary).centroid.y
    except Exception:
        lat_deg=0.0
    et0=et0_hargreaves(lat_deg, dt.date.today(), tmax, tmin)
    need_mm=max(0.0, et0*kc-(rain or 0.0))
    need_mm=min(need_mm, awc/10.0)
    return round(need_mm*10000)


def make_recommendations(db: Session, field: Field, state: FieldDailyState):
    recos=[]
    if state.water_stress is not None and state.water_stress>0.6:
        liters=estimate_irrigation_liters_per_ha(db, field, state.stage, state.temp_max_c, state.temp_min_c, state.precip_sum_mm)
        recos.append({"type":"irrigation","amount_liters_per_ha":liters,"reason":"high_water_stress"})
    if state.heat_stress is not None and state.heat_stress>0.7:
        recos.append({"type":"heat_warning","reason":"high_temp"})
    if state.vigor_score is not None and state.vigor_score<0.4 and (state.water_stress or 0)<0.4:
        recos.append({"type":"fertilization_check","reason":"low_vigor_without_water_stress"})
    return recos


@shared_task(bind=True)
def fetch_weather_stats_task(self):
    db: Session = SessionLocal()
    try:
        fields=db.query(Field).all()
        stored=0
        for f in fields:
            svc = f.get_weather_service()  # existing helper in your code
            stats = svc.get_current_and_forecast()
            if not stats: 
                continue
            day=dt.date.today()
            rec=db.query(WeatherRecord).filter_by(field_id=f.id, tenant_id=f.tenant_id, date=day).first()
            if rec is None:
                rec=WeatherRecord(field_id=f.id, tenant_id=f.tenant_id, date=day)
                db.add(rec)
            rec.temp_max_c=stats.get("temp_max_c")
            rec.temp_min_c=stats.get("temp_min_c")
            rec.precip_sum_mm=stats.get("precip_sum_mm")
            rec.wind_max_kmh=stats.get("wind_max_kmh")
            rec.uv_max=stats.get("uv_max")
            rec.temp_current_c=stats.get("temp_current_c")
            rec.humidity_current_pct=stats.get("humidity_current_pct")
            rec.wind_current_kmh=stats.get("wind_current_kmh")
            rec.precip_current_mm=stats.get("precip_current_mm")
            rec.cloud_cover_current_pct=stats.get("cloud_cover_current_pct")
            rec.raw=stats
            stored += 1
        db.commit()
        try:
            precompute_tiles_task.delay(result.id)
        except Exception:
            pass
        return {"stored": stored}
    finally:
        db.close()


@shared_task(bind=True)
def fetch_sentinel_image_task(self, field_id: int):
    """Download latest Sentinel product zip and persist SatelliteImage with band paths."""
    db: Session = SessionLocal()
    try:
        field=db.query(Field).filter(Field.id==field_id).first()
        if not field:
            return {"error":"Field not found"}

        poly=to_shape(field.boundary)
        api=SentinelAPIService()
        product=api.search_latest_product(poly)
        if not product:
            return {"error":"No product"}

        zip_path = api.download_product(product["id"])
        if not zip_path:
            return {"error":"Download failed"}
        zip_path=Path(zip_path)

        red_path=nir_path=blue_path=swir1_path=None
        with zipfile.ZipFile(zip_path,"r") as z:
            for name in z.namelist():
                low=name.lower()
                if name.endswith(".jp2") and "b04" in low and red_path is None:
                    red_path=str(Path(z.extract(name, path=zip_path.parent)))
                if name.endswith(".jp2") and "b08" in low and nir_path is None:
                    nir_path=str(Path(z.extract(name, path=zip_path.parent)))
                if name.endswith(".jp2") and "b02" in low and blue_path is None:
                    blue_path=str(Path(z.extract(name, path=zip_path.parent)))
                if name.endswith(".jp2") and ("b11" in low or "b12" in low) and swir1_path is None:
                    swir1_path=str(Path(z.extract(name, path=zip_path.parent)))

        if not red_path or not nir_path:
            return {"error":"Required bands missing"}

        img=SatelliteImage(field_id=field.id, tenant_id=field.tenant_id,
                           product_id=product["id"], red_path=red_path, nir_path=nir_path,
                           processed_at=dt.datetime.utcnow(),
                           meta={**product, "blue_path":blue_path, "swir1_path":swir1_path})
        db.add(img); db.commit()
        return {"image_id": img.id}
    finally:
        db.close()


@shared_task(bind=True)

def compute_ndvi_task(self, image_id: int):
    """Compute NDVI + extra indices (NDRE/GNDVI/SAVI/EVI/NDWI) and store in NDVIResult.stats.
    After compute, precompute tiles for each index (Mode B).
    """
    db: Session = SessionLocal()
    try:
        image = db.query(SatelliteImage).filter(SatelliteImage.id==image_id).first()
        if not image:
            return {"error": "Image not found"}
        field = db.query(Field).filter(Field.id==image.field_id).first()
        if not field:
            return {"error": "Field not found"}
        poly = to_shape(field.boundary)

        arrays, transform, profile, stats = compute_indices(
            image.red_path, image.nir_path, poly,
            blue_path=(image.meta or {}).get("blue_path"),
            swir1_path=(image.meta or {}).get("swir1_path"),
            green_path=(image.meta or {}).get("green_path"),
            rededge_path=(image.meta or {}).get("rededge_path"),
        )

        import rasterio
        storage_root = Path("/code/storage/indices")
        storage_root.mkdir(parents=True, exist_ok=True)

        tif_paths = {}
        for name, arr in arrays.items():
            if arr is None:
                continue
            out_path = storage_root / name / f"{name}_{image_id}.tif"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            with rasterio.open(out_path, "w", **profile) as dst:
                dst.write(arr.astype("float32"), 1)
            tif_paths[name] = str(out_path)
            stats[f"{name}_tif_path"] = str(out_path)

        ndvi_path = tif_paths.get("ndvi")

        res = NDVIResult(
            image_id=image.id,
            field_id=image.field_id,
            tenant_id=image.tenant_id,
            processed_at=dt.datetime.utcnow(),
            mean_ndvi=stats.get("ndvi_mean"),
            min_ndvi=stats.get("ndvi_min"),
            max_ndvi=stats.get("ndvi_max"),
            ndvi_tif_path=ndvi_path,
            stats=stats,
        )
        db.add(res); db.commit(); db.refresh(res)

        # precompute tiles for all available indices
        try:
            precompute_tiles_task.delay(res.id)
        except Exception:
            pass
        for name, path in tif_paths.items():
            if name == "ndvi":
                continue
            try:
                precompute_index_tiles_task.delay(name, res.id, path)
            except Exception:
                pass

        return {"result_id": res.id, "indices": list(tif_paths.keys()), "stats": stats}
    finally:
        db.close()


@shared_task(bind=True)
def fetch_sentinel_and_indices_task(self):
    """Store latest Sentinel indices per field."""
    db: Session = SessionLocal()
    try:
        fields=db.query(Field).all()
        stored=0
        for f in fields:
            latest=(db.query(NDVIResult)
                      .filter(NDVIResult.field_id==f.id, NDVIResult.tenant_id==f.tenant_id)
                      .order_by(NDVIResult.processed_at.desc()).first())
            if not latest:
                continue
            day=latest.processed_at.date()
            rec=(db.query(SatelliteIndexRecord)
                   .filter_by(field_id=f.id, tenant_id=f.tenant_id, date=day).first())
            if rec is None:
                rec=SatelliteIndexRecord(field_id=f.id, tenant_id=f.tenant_id, date=day)
                db.add(rec)
            s=latest.stats or {}
            rec.ndvi_mean=latest.mean_ndvi
            rec.ndvi_min=s.get("ndvi_min"); rec.ndvi_max=s.get("ndvi_max")
            rec.ndwi_mean=s.get("ndwi_mean"); rec.evi_mean=s.get("evi_mean"); rec.savi_mean=s.get("savi_mean")
            rec.cloud_pct=s.get("cloud_pct")
            rec.raw={"ndvi_result_id": latest.id, "stats": s}
            stored += 1
        db.commit()
        return {"stored": stored}
    finally:
        db.close()


@shared_task(bind=True)
def build_daily_field_state_task(self, days_back: int=7):
    db: Session = SessionLocal()
    try:
        fields=db.query(Field).all()
        today=dt.date.today()
        built=0
        for f in fields:
            for d in range(days_back):
                day=today-dt.timedelta(days=d)
                w=(db.query(WeatherRecord)
                     .filter_by(field_id=f.id, tenant_id=f.tenant_id, date=day).first())
                s=(db.query(SatelliteIndexRecord)
                     .filter(SatelliteIndexRecord.field_id==f.id,
                             SatelliteIndexRecord.tenant_id==f.tenant_id,
                             SatelliteIndexRecord.date<=day)
                     .order_by(SatelliteIndexRecord.date.desc()).first())
                if not w and not s:
                    continue
                state=(db.query(FieldDailyState)
                         .filter_by(field_id=f.id, tenant_id=f.tenant_id, date=day).first())
                if state is None:
                    state=FieldDailyState(field_id=f.id, tenant_id=f.tenant_id, date=day)
                    db.add(state)

                ndvi_today=s.ndvi_mean if s else None
                ndwi_today=s.ndwi_mean if s else None

                state.ndvi=ndvi_today; state.ndwi=ndwi_today
                state.evi=s.evi_mean if s else None
                state.savi=s.savi_mean if s else None

                if w:
                    state.temp_max_c=w.temp_max_c
                    state.temp_min_c=w.temp_min_c
                    state.precip_sum_mm=w.precip_sum_mm
                    state.humidity_current_pct=w.humidity_current_pct

                state.stage=get_crop_stage(db, f, day)
                state.vigor_score=calc_vigor_score(db, f, day, ndvi_today)
                state.water_stress=calc_water_stress(ndwi_today, w.precip_sum_mm if w else None, w.temp_max_c if w else None)
                state.heat_stress=calc_heat_stress(w.temp_max_c if w else None)

                rule_anom, baseline = calc_rule_anomaly(db, f, day, ndvi_today)
                feats=build_features(ndvi_today, baseline, state.water_stress, state.heat_stress, state.precip_sum_mm)
                trained=load_anomaly_model()
                if trained is not None:
                    try:
                        Xp=[[state.ndvi or 0.0, state.ndwi or 0.0, state.precip_sum_mm or 0.0, state.temp_max_c or 0.0, state.water_stress or 0.0, state.heat_stress or 0.0]]
                        ml_score=float(trained.predict_proba(Xp)[:,1][0])
                    except Exception:
                        ml_score=classify_anomaly(feats)
                else:
                    ml_score=classify_anomaly(feats)
                state.anomaly_score=ml_score if ml_score is not None else rule_anom

                trained_y=load_yield_model()
                if trained_y is not None:
                    try:
                        from app.modules.training.yield_train import build_yield_features
                        feat=build_yield_features(db, f.id, f.tenant_id, day-dt.timedelta(days=60), day)
                        yield_pred=float(trained_y.predict([feat])[0])
                    except Exception:
                        yield_pred=estimate_yield_kg_per_ha(db, f, day)
                else:
                    yield_pred=estimate_yield_kg_per_ha(db, f, day)

                if yield_pred is not None:
                    state.raw=(state.raw or {})
                    state.raw["yield_pred_kg_ha"]=yield_pred

                state.recommendation=make_recommendations(db, f, state)
                if yield_pred is not None:
                    state.recommendation.append({"type":"yield_prediction","value_kg_per_ha":yield_pred})

                if w:
                    update_soil_water_balance(db, f, day, w, state.stage)

                # alerts
                if state.water_stress is not None and state.water_stress>0.75:
                    create_alert(db, f, "drought_risk", f"High water stress on {day.isoformat()}")
                if state.heat_stress is not None and state.heat_stress>0.8:
                    create_alert(db, f, "heat_stress", f"High heat stress on {day.isoformat()}")
                if state.anomaly_score is not None and state.anomaly_score>0.6 and (state.water_stress or 0)<0.4:
                    create_alert(db, f, "veg_anomaly", f"Vegetation anomaly on {day.isoformat()}")

                built += 1
        db.commit()
        return {"built": built}
    finally:
        db.close()
@shared_task(name="app.workers.tasks.change_detection_task", bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_kwargs={"max_retries":2})
def change_detection_task(self, field_id: int, old_result_id: int, new_result_id: int):
    db: Session = SessionLocal()
    try:
        old_r = db.query(IndexResult).filter_by(id=old_result_id, field_id=field_id).first()
        new_r = db.query(IndexResult).filter_by(id=new_result_id, field_id=field_id).first()
        if not old_r or not new_r:
            raise ValueError("Index results not found")
        from app.services.change_detection import compute_delta_tif
        delta_path, delta_stats = compute_delta_tif(old_r.tif_path, new_r.tif_path)
        out_path = FileManager.delta_tif(field_id, old_result_id, new_result_id)
        FileManager.copy(delta_path, out_path)
        rec = ChangeDetectionResult(
            field_id=field_id, old_result_id=old_result_id, new_result_id=new_result_id,
            delta_tif_path=out_path, stats=delta_stats, tenant_id=old_r.tenant_id
        )
        db.add(rec); db.commit(); db.refresh(rec)
        return {"id": rec.id, "stats": delta_stats}
    finally:
        db.close()


from app.modules.satellite.services.tiler import precompute_tiles
from app.core.file_manager import FileManager
import os
import numpy as np

@shared_task(name="app.workers.tasks.precompute_tiles_task", bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_kwargs={"max_retries":2})
def precompute_tiles_task(self, result_id: int, zoom_min: int=10, zoom_max: int=16):
    db = SessionLocal()
    try:
        res = db.query(NDVIResult).filter_by(id=result_id).first()
        if not res or not os.path.exists(res.ndvi_tif_path):
            raise ValueError("NDVIResult not found")
        out_root = FileManager.tiles_dir(result_id)
        stats = precompute_tiles(res.ndvi_tif_path, out_root, zoom_min, zoom_max)
        return {"result_id": result_id, **stats}
    finally:
        db.close()

@shared_task(name="app.workers.tasks.anomaly_ndvi_task", bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_kwargs={"max_retries":2})
def anomaly_ndvi_task(self, field_id: int):
    """Balanced anomaly map based on last two NDVI results."""
    db = SessionLocal()
    try:
        rows = db.query(NDVIResult).filter_by(field_id=field_id).order_by(NDVIResult.processed_at.desc()).limit(2).all()
        if len(rows) < 2:
            raise ValueError("Need two results")
        new_r, old_r = rows[0], rows[1]
        from app.modules.satellite.services.indices_large import read_tif, write_tif
        new_arr, prof = read_tif(new_r.ndvi_tif_path)
        old_arr, _ = read_tif(old_r.ndvi_tif_path)
        delta = new_arr - old_arr
        mu = float(np.nanmean(delta))
        sigma = float(np.nanstd(delta)) or 1.0
        z = (delta - mu) / sigma
        mask = (z < -2.0).astype("float32")
        out_path = os.path.join(FileManager.field_dir(field_id), "anomalies", f"anomaly_ndvi_{new_r.id}.tif")
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        write_tif(out_path, mask, prof)

        # attach anomaly path to latest NDVIResult stats so tiles/png can serve it
        new_r.stats = new_r.stats or {}
        new_r.stats["anomaly_ndvi_tif_path"] = out_path
        db.add(new_r); db.commit()

        # save as NDVIResult-like record? use ChangeDetectionResult table if exists
        return {"anomaly_tif_path": out_path, "mean": float(mask.mean())}
    finally:
        db.close()


@shared_task(name="app.workers.tasks.precompute_index_tiles_task", bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_kwargs={"max_retries":2})
def precompute_index_tiles_task(self, index_name: str, result_id: int, tif_path: str, zoom_min: int=10, zoom_max: int=16):
    """Precompute tiles for any index tif and store under /storage/tiles/{index}/{result_id}."""
    from app.modules.satellite.services.tiler import precompute_tiles
    if not os.path.exists(tif_path):
        raise ValueError("tif_path not found")
    out_root = FileManager.tiles_dir_index(index_name, result_id)
    stats = precompute_tiles(tif_path, out_root, zoom_min, zoom_max)
    return {"index": index_name, "result_id": result_id, **stats}


@shared_task(name="app.workers.tasks.change_detection_task", bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_kwargs={"max_retries":2})
def change_detection_task(self, field_id: int, old_result_id: int, new_result_id: int, index_name: str="ndvi"):
    db = SessionLocal()
    try:
        old_r = db.get(NDVIResult, old_result_id)
        new_r = db.get(NDVIResult, new_result_id)
        if not old_r or not new_r or old_r.field_id!=field_id or new_r.field_id!=field_id:
            raise ValueError("Results not found")
        name=index_name.lower()
        def tif_for(r):
            if name=="ndvi":
                return r.ndvi_tif_path
            return (r.stats or {}).get(f"{name}_tif_path")
        old_tif=tif_for(old_r); new_tif=tif_for(new_r)
        if not old_tif or not new_tif:
            raise ValueError("TIF missing for index")
        from app.modules.satellite.services.change_detection import compute_delta_tif
        delta_path, delta_stats = compute_delta_tif(old_tif, new_tif)
        out_path = FileManager.delta_tif(field_id, old_result_id, new_result_id, name)
        FileManager.copy(delta_path, out_path)
        new_r.stats = new_r.stats or {}
        new_r.stats[f"delta_{name}_tif_path"] = out_path
        db.add(new_r); db.commit()
        # precompute tiles for delta layer
        try:
            precompute_index_tiles_task.delay(name=f"delta_{name}", tif_path=out_path, result_id=new_result_id)
        except Exception:
            pass
        return {"delta_tif_path": out_path, "stats": delta_stats}
    finally:
        db.close()


@shared_task(name="app.workers.tasks.precompute_index_tiles_task", bind=True)
def precompute_index_tiles_task(self, name: str, tif_path: str, result_id: int, zoom_min: int=10, zoom_max: int=16):
    from app.modules.satellite.services.tiler import precompute_tiles
    out_root = FileManager.tiles_dir_index(name, result_id)
    return precompute_tiles(tif_path, out_root, zoom_min, zoom_max)


@shared_task(name="app.workers.tasks.anomaly_index_task", bind=True, autoretry_for=(Exception,), retry_backoff=True, retry_kwargs={"max_retries":2})
def anomaly_index_task(self, field_id: int, index_name: str="ndvi"):
    db = SessionLocal()
    try:
        name=index_name.lower()
        rows = db.query(NDVIResult).filter_by(field_id=field_id).order_by(NDVIResult.processed_at.desc()).limit(2).all()
        if len(rows) < 2:
            raise ValueError("Need two results")
        new_r, old_r = rows[0], rows[1]
        def tif_for(r):
            if name=="ndvi": return r.ndvi_tif_path
            return (r.stats or {}).get(f"{name}_tif_path")
        new_tif=tif_for(new_r); old_tif=tif_for(old_r)
        if not new_tif or not old_tif:
            raise ValueError("Missing TIF")
        from app.modules.satellite.services.indices_large import read_tif, write_tif
        new_arr, prof = read_tif(new_tif)
        old_arr, _ = read_tif(old_tif)
        delta = new_arr - old_arr
        mu = float(np.nanmean(delta))
        sigma = float(np.nanstd(delta)) or 1.0
        z = (delta - mu) / sigma
        mask = (z < -2.0).astype("float32")
        out_path = os.path.join(FileManager.field_dir(field_id), "anomalies", f"anomaly_{name}_{new_r.id}.tif")
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        write_tif(out_path, mask, prof)
        new_r.stats = new_r.stats or {}
        new_r.stats[f"anomaly_{name}_tif_path"] = out_path
        db.add(new_r); db.commit()
        precompute_index_tiles_task.delay(name=f"anomaly_{name}", tif_path=out_path, result_id=new_r.id)
        return {"anomaly_tif_path": out_path}
    finally:
        db.close()


# Phase8 QA helper inside compute task(s)
def _qa_reject_if_cloudy(cloud_pct: float, threshold: float = 60.0):
    if cloud_pct >= threshold:
        raise ValueError(f"Image too cloudy ({cloud_pct:.1f}%)")


@shared_task(name="app.workers.tasks.nightly_sentinel_pull_task", bind=True)
def nightly_sentinel_pull_task(self):
    """Pull latest Sentinel imagery for all fields (best-effort)."""
    db = SessionLocal()
    try:
        from app.modules.fields.models import Field
        from app.modules.satellite.services.sentinelhub_service import fetch_best_image_for_field as fetch_latest_for_field
        fields = db.query(Field).all()
        pulled=0
        for f in fields:
            try:
                fetch_latest_for_field(db, f.id)
                pulled += 1
            except Exception:
                continue
        return {"pulled_fields": pulled}
    finally:
        db.close()




def _upload_indices_to_s3(result: NDVIResult):
    """Convert computed TIFFs to COG, upload to S3, store urls, and remove local files."""
    try:
        stats = result.stats or {}
        pref = tenant_prefix(getattr(result, "tenant_id", None))
        index_paths = {
            "ndvi": result.ndvi_tif_path,
            "ndre": stats.get("ndre_tif_path"),
            "gndvi": stats.get("gndvi_tif_path"),
            "savi": stats.get("savi_tif_path"),
            "evi": stats.get("evi_tif_path"),
            "ndwi": stats.get("ndwi_tif_path"),
        }
        for name, path in index_paths.items():
            if not path or not os.path.exists(path):
                continue
            cog_path = to_cog(path)
            key = f"{pref}/indices/{name}/{result.id}.tif"
            upload_file(cog_path, key, content_type="image/tiff")
            stats[f"{name}_url"] = public_url(key)
            stats[f"{name}_cog_path"] = key
            # cleanup local
            for lp in {path, cog_path}:
                try:
                    if os.path.exists(lp):
                        os.remove(lp)
                except Exception:
                    pass
        result.stats = stats
    except Exception:
        pass
