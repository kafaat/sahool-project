from celery import Celery
from app.core.config import settings

celery = Celery("sahool", broker=settings.redis_url, backend=settings.redis_url)
celery.conf.task_routes = {
    "app.workers.tasks.precompute_tiles_task": {"queue": "satellite"},
    "app.workers.tasks.precompute_index_tiles_task": {"queue":"satellite"},
    "app.workers.tasks.anomaly_ndvi_task": {"queue": "satellite"},
    "app.workers.tasks.fetch_sentinel_image_task": {"queue": "satellite"},
    "app.workers.tasks.compute_ndvi_task": {"queue": "satellite"},
    "app.workers.tasks.change_detection_task": {"queue": "satellite"},
}

celery.conf.beat_schedule = {
    "nightly-sentinel-pull": {"task": "app.workers.tasks.nightly_sentinel_pull_task", "schedule": 60*60*24},
  "daily-weather-refresh": {"task": "app.workers.tasks.fetch_weather_stats_task", "schedule": 60*60*6},
  "monthly-reports": {"task": "app.workers.tasks.send_monthly_reports", "schedule": 60*60*24*30},
}
