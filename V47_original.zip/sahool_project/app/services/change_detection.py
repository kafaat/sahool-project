# Legacy alias for worker imports.
from app.modules.satellite.services.change_detection import *  # noqa
